"""Offline reproduction of the limited retrospective audit, Python 3 only.

Inputs are saved extracts, not new observations. This does not verify the
reported location or rerun the entire regional screening or flight model.
"""
from pathlib import Path
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent
inputs = json.loads((ROOT / "audit/audit_inputs.json").read_text(encoding="utf-8"))
expected = json.loads((ROOT / "audit/coverage_audit.json").read_text(encoding="utf-8"))
point = inputs["reported_coordinate"]


def distance(other):
    p, q = map(math.radians, (point[0], other[0]))
    dl = math.radians(other[1] - point[1])
    a = math.sin((q - p) / 2)**2 + math.cos(p)*math.cos(q)*math.sin(dl / 2)**2
    return 6371000 * 2 * math.asin(math.sqrt(min(1, max(0, a))))


def close(actual, wanted, tolerance=0.001):
    assert abs(actual - wanted) <= tolerance, (actual, wanted, tolerance)


# Verify archive integrity first, excluding MANIFEST.json's self-reference.
manifest_path = ROOT / "MANIFEST.json"
if manifest_path.exists():
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for entry in manifest["files"]:
        data = (ROOT / entry["file"]).read_bytes()
        assert len(data) == entry["bytes"], entry["file"]
        assert hashlib.sha256(data).hexdigest() == entry["sha256"], entry["file"]

result = {"notice": inputs["notice"]}
box, n = inputs["bbox3857"], inputs["size"]
x = 6378137 * math.radians(point[1])
y = 6378137 * math.log(math.tan(math.pi / 4 + math.radians(point[0]) / 2))
result["inside_regional_raster"] = box[0] <= x <= box[2] and box[1] <= y <= box[3]
assert result["inside_regional_raster"] == expected["inside_27sep_regional_raster"]

for name, patch in inputs["patches"].items():
    z, surface = patch["dtm"], patch["dom"]
    valid_count = tall_count = 0
    for r in range(5):
        for c in range(5):
            height = surface[r][c] - z[r][c]
            valid = math.isfinite(height) and -10 <= height <= 70 and 0 <= z[r][c] < 2000
            valid_count += int(valid)
            tall_count += int(valid and height > 12)
    centre = [z[r][c] for r in range(1, 4) for c in range(1, 4)]
    relief = max(centre) - min(centre)
    coverage, fraction = valid_count / 25, tall_count / 25
    row, col = patch["row"], patch["col"]
    px = box[0] + (col + .5) * (box[2] - box[0]) / n
    py = box[3] - (row + .5) * (box[3] - box[1]) / n
    lon = math.degrees(px / 6378137)
    lat = math.degrees(2 * math.atan(math.exp(py / 6378137)) - math.pi / 2)
    measured = dict(distance_m=distance([lat, lon]), height_m=z[2][2],
                    tall_fraction=fraction, coverage=coverage, relief_m=relief,
                    passes_height_forest_terrain=coverage > .99 and fraction >= .4
                    and relief <= 20 and z[2][2] < 1100)
    for field, value in measured.items():
        if isinstance(value, bool):
            assert value == expected[name][field], (name, field)
        else:
            close(value, expected[name][field])
    result[name] = measured

distances = [distance(p) for p in inputs["surviving_points"]]
result["surviving_samples_within_3km"] = sum(d < 3000 for d in distances)
assert result["surviving_samples_within_3km"] == expected["surviving_samples_within_3km"] == 65
result["nearest_surviving_sample_m"] = min(distances)
close(min(distances), expected["nearest_surviving_regional_sample"]["distance_m"])
assert len(distances) == 8135

weather = next(p for p in inputs["representatives"] if p["id"] == "weather_3")
result["weather_3_distance_m"] = distance([weather["lat"], weather["lon"]])
weather_expected = next(p for p in expected["nearest_documented_points"]
                        ["broad_27sep/region_results.json"] if p["id"] == "weather_3")
close(result["weather_3_distance_m"], weather_expected["distance_m"])
result["weather_3_in_detail_manifest"] = "weather_3" in inputs["detail_ids"]
assert not result["weather_3_in_detail_manifest"]
assert len(inputs["representatives"]) == 22 and len(inputs["detail_ids"]) == 10

result["S03_distance_m"] = distance(inputs["S03"])
close(result["S03_distance_m"], expected["S03_distance_m"])
result["inside_later_novelty_exclusion"] = result["S03_distance_m"] < inputs["novelty_exclusion_m"]
assert result["inside_later_novelty_exclusion"]
# This is one later pass's exclusion, not a claim about every search.
result["status"] = "PASS: compact audit reproduced; reported location remains unverified"
print(json.dumps(result, indent=2))
