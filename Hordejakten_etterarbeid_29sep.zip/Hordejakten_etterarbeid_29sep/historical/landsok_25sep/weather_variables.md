# MET-felter og tidsreferanser

`weather_input.npz`: lat, lon, mask, wide, strict, values. De gamle wide/strict-resultatene er bevart i kildefilen, men brukes ikke av den nye kjøringen.

`values` har rekkefølgen:

0. Skyandel 21.09 kl. 17 UTC / 19 norsk tid.
1. Skyandel 21.09 kl. 18 UTC / 20 norsk tid.
2. Gjennomsnittlig modelltemperatur kl. 19 og 20 norsk tid 21.09, °C. Dette er ikke presis interpolasjon til 19.35.
3. Høyeste modelltemperatur av timeprøvene 12–16 norsk tid 21.09, °C. Ikke døgnmaksimum.
4. Gjennomsnittlig modellsky kl. 17 og 18 norsk tid 23.09.
5. Gjennomsnittlig modellvind 10 m over bakken kl. 17 og 18 norsk tid 23.09, m/s. Ikke lokal vind inne i skogen.
6. Maksimum av nedbørmengdene ved 09 og 10 UTC 24.09, mm i foregående time. Ikke brukt i den nye testen.

De demonstrerte gamle temperaturintervallene er 6–13 °C for punkt 2 og 8–16 °C for punkt 3.

Landmasken er det tidligere uttaket av Natural Earth Norge, kombinert med MET landfraksjon over 0,5 og breddegrad under 72. Småøyer og grensesteder kan falle bort; dette er ikke et uttømmende sett mulige plasseringer. Originale OPeNDAP-adresser og nedlastingstidspunkter følger i `met_sources/`.
