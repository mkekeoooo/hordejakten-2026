# Ny landsdekkende kontroll – 25. september 2026

Ingen ny plassering er funnet. Denne pakken viser et nytt forsøk på solbasert lokalisering uten flypremiss, en nasjonal kontroll av værmodellens følsomhet og et konkret appspor som nå kan undersøkes med riktig produkttekst. De tidligere kandidatene er ikke brukt til å velge resultat.

## 1. Appvaren kan endelig identifiseres

Jeg har sett begge produktbildene publisert hos Praktiskinfo. Bildet viser en grevling med oljeflaske, produktnavnet er «Olivenoljestativ», prisen er 100 000 poeng, og fraktformuleringen er «Nesten Helt Hjem». Dette retter den tidligere omtalen av en bever. Flasken har ingen leselig etikett som gir et sted.

- [Produktskjermbilde](https://praktiskinfo.no/img/hordejakten/olivenoljestativ-grevling-25-september-2026.jpg)
- [Skjermbilde med beskrivelse](https://praktiskinfo.no/img/hordejakten/olivenoljestativ-produkttekst-25-september-2026.jpg)
- [Kildens redegjørelse](https://praktiskinfo.no/hordejakten-2026/)

Skjermbildene er tredjepartsformidlet; jeg har ikke åpnet varen i Horde-appen. Koblingen til jakten er ikke bekreftet. En mulig direkte test ville vært ordet **grevling** i appens eksisterende skjulte ord-felt. Brukeren har ikke appen og ønsker ikke å opprette konto; vi fortsetter med offentlige kilder, og appresponsen står som utestet. Verken fraktordene, dyret eller prisen skal oversettes til et stedsnavn uten et ekstra holdepunkt.

### Ny hypotese fra brukeren: olivenolje → olivin

Dette er et konkret nytt spor utenfor de gamle områdene. [Sibelco bekrefter](https://www.sibelco.com/en/sites/aheim) at olivin utvinnes og bearbeides ved Åheim, og omtaler anlegget som verdens største kommersielle olivindrift. [NGU oppgir](https://www.ngu.no/geologiske-ressurser/olivin) at mange norske forekomster ligger på Sunnmøre og i Nordfjord. Åheim/Almklovdalen blir dermed et saklig undersøkelsesområde **hvis** oljeflasken er et olivin-ordspill. Mineralet er ikke et unikt stedsnavn.

Det finnes også en konkret skogkobling: Statsforvalterens [naturtypekartlegging i Vanylven fra 2004](https://www.statsforvalteren.no/siteassets/fm-more-og-romsdal/dokument-fmmr/miljo-og-klima/naturmangfald/kartleggingsrapportar/kommunale/vanylven-2004.pdf) beskriver lyngdominert olivinfuruskog i Almklovdalen/Gusdalen, i kontrast til omkringliggende lauvskog, ved 55–300 moh. Dette viser hvorfor skogpreget i sendingen ikke i seg selv krever en høytliggende lokalitet i Innlandet. Kartleggingen er gammel og bekrefter ikke dagens tilstand eller bildelikhet ved noe enkeltpunkt.

[Miljødirektoratets beskrivelse av olivinskog](https://www.miljodirektoratet.no/globalassets/publikasjoner/m1621/m1621.pdf) presiserer at fattige utforminger kan ligne vanlig humusrik furuskog. Vi kan derfor ikke artsbestemme berggrunnen fra det generelle skogbildet. Grevlingen og fraktordene har foreløpig ingen dokumentert kobling til Åheim. Geologien og skogtypen bekrefter at en hypotese er mulig; de er ikke to uavhengige bekreftelser på at Horde mente den.

**Beslutning:** Ta inn Åheim/Almklovdalen som et nytt, navngitt ordspillscenario i diskusjonen. Ingen ny førsteplass, kamera-koordinat eller anbefaling om å gå inn på gruveområdet. En identifiserbar bergflate, et originalt tilleggshint eller en dokumentert apprespons som faktisk peker mot olivin, ville gjøre dette vesentlig sterkere.

## 2. Solsporet: ny beregning, men ingen geografisk avgrensning

Fra [minuttarkivet hos default.no](https://default.no/clips.php) hentet jeg elleve ettminuttsklipp fra 21. september og tok ut 33 stillbilder i 1280 × 720. Dette er nettstedets arkiverte klipp, ikke kameraets originalfiler eller en kontroll mot den opprinnelige YouTube-tidslinjen. Dagens overskyede vær hindrer ikke denne historiske testen. Manifestet har kildeadresser og SHA-256 for klippene.

Bare tre minuttsgrupper ga brukbare, om enn delvis tildekkede, lysområder: 17.05, 17.10 og 17.15. Ni bildepunkt fordeler seg på disse tre gruppene og er ikke ni uavhengige observasjoner. Tidene er nominelle filnavntider pluss bildeoffset. Andre lysflekker kunne ikke sikkert tilordnes solsentrum; noen ble omtrent stående mens sola flyttet seg.

`solar_national.py` tilpasser solretningene til bildepunktene med fri tredimensjonal kamerarotasjon og brennvidde, kjent dato og tid. Ingen flyspor, høydehint, adkomst, terreng eller regionfilter inngår. Kameramodellen har midtpunkt (640, 360), kvadratiske piksler og ingen linsefortegning. Basisforsinkelsen er et valgt scenario på 22 sekunder, ikke en ny måling. Solberegningen bruker Astral uten refraksjon.

Basisfitten gir f = 1134,85 piksler og RMS = 3,02 piksler per koordinat. **Liten bildefeil betyr ikke at stedet er funnet.** Når de tre minuttsgruppene forskyves med opptil seks piksler per akse, og kamerastillingen varieres, spenner 200 scenarier fra 47,5° til 71,9° nord. Helning −3 til +1° og rulling ±1° er valgte følsomhetsintervaller, ikke målte kameravinkler eller statistiske feilgrenser. Resultatet er ikke en sannsynlighetsfordeling, et fullstendig usikkerhetsområde eller en utelukkelse av steder utenfor punktskyen.

De mørke stedspunktene i figuren er orienteringspunkter på kartet, ikke kandidater. `national_benchmarks.csv` viser kun nødvendig kamerastilling for basisfitten og skal ikke brukes til rangering. Lengre, sikkert avlest solbane og en uavhengig kamerakalibrering kreves før denne metoden kan brukes geografisk. Vi stopper denne korte solserien her.

## 3. Vær: hele Norge, uten den gamle regionsavgrensningen

Jeg brukte de allerede innhentede [MET Nordic-analysefeltene](https://github.com/metno/NWPdocs/wiki/MET-Nordic-dataset), med 13 348 norske landprøver. Det er punktutvalg med 5 km mellom prøvene fra en 1 km modell, ikke observasjoner av været i hver skoglysning. Dagens kjøring er `weather_open.py`; den trenger bare vedlagte `weather_input.npz`.

| Modellkrav i kontrollen | Antall landprøver |
|---|---:|
| Skydekke ≤40 % kl. 19 og 20 den 21.09 | 4543 |
| Samme + modellvind ≤5 m/s den 23.09 | 4195 |
| Samme + de tidligere brede temperaturintervallene | 2191 |
| Samme + tolkningen «SOL» = modellsky ≤70 % | 9 |

Dette er ikke en ny rangering. Den siste kolonnen i kartet viser hvordan én usikker oversettelse av en solobservasjon kan flytte utvalget helt nordover. Et øyeblikk med direkte sol gjennom et hull i skyene er ikke en måling av modellcellens skyandel. Heller ikke de øvrige kravene gir harde utelukkelser. Temperaturkravene er med som demonstrasjon av den tidligere modellen, ikke gjeninnført som kriterier.

Nedbør er ikke med i denne sammenligningen. Vi endrer heller ikke en aktuell brukergjengivelse av «ingen sol» til et presist landsdekkende skykrav uten verifisert bilde og tidspunkt. Feltene, variabelrekkefølgen og kildetidspunktene er dokumentert i `weather_variables.md` og `met_sources/`.

## 4. Felles beslutning med Claude

[Claude har i #9 trukket tilbake](https://github.com/mkekeoooo/hordejakten-2026/issues/9#issuecomment-5831319502) tolkningen av bildevinkelen som direkte flyhøyde. Vi er enige om at 21.29-gesten ikke alene velger eller utelukker en region. Værutelukkelsene av vest og sør var ikke kontrollert mot observasjoner og brukes ikke som harde utelukkelser. Ingen ny region overtar førsteplassen.

Den nye informasjonen som kan skille oss fra mer karttilpasning, er en faktisk respons på appvaren eller et nytt originalhint. Jeg har ingen dokumentasjon på at arrangøren har valgt en bestemt strategi mot AI-analyser.

## Reproduksjon og innhold

Python med numpy, scipy, astral, matplotlib og opencv-python-headless. Kjør `solar_national.py` for samme numeriske solforsøk og `weather_open.py` for de fire værscenarioene. Solforsøket bruker `sun_candidates.json`; målepunktene og utvalget er synlige i figurer og JSON. Uttaksskriptene viser hvordan fullstendig bildeutvalg kan gjenskapes fra klippene.

Tre hele kontrollbilder følger i `frames/`. Alle elleve originalvideoer er utelatt for å holde pakken liten; URL og kontrollsum følger med. De offentlige appbildene er lenket, ikke kopiert inn. SHA-256 for alle pakkefiler finnes i `SHA256SUMS.txt`.
