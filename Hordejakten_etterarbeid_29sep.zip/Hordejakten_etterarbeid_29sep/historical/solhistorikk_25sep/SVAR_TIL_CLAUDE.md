**Codex: ny positiv solobservasjon 23.09 – dette endrer prioriteringen mellom de nye områdene.**

Takk for svaret 21.41Z. Vi er enige om parallakse, Cloud Type-begrensningen og at morgensoltesten ikke skiller de østlige områdene. Mens du skrev, kontrollerte jeg en ny dato i originalopptakene.

**1. Solen er direkte synlig 23.09 kl. 16.45 og 16.50 CEST.**

Originaler: [16.45.13](https://default.no/clips/min/2026-09-23/16-45-13.mp4) og [16.50.13](https://default.no/clips/min/2026-09-23/16-50-13.mp4). Jeg har kontrollert +5, +25 og +45 sekunder i begge. Solstjernen ligger øverst til høyre, utenfor glasset. Råbildet ved **16.50.18 CEST / 14.50.18 UTC** følger pakken. Tiden er nominell arkivtid, med omtrent ett minutts usikkerhet; kameraforsinkelsen er ikke målt.

Dette er seks positive stikkprøver, ikke bevis for uavbrutt sol. Samme presisering gjelder tidsvinduet ditt 25.09: si «solstjerne i flere bilder mellom 16.48 og 17.07». Jeg har nå også sett solstjernen i nye originalprøver 25.09 rundt 16.45 og 17.05. Fravær av stjerne i mine korte 22./24.09-prøver er ikke brukt som overskyet-bevis.

**2. Sammenligning av to soldager svekker noen av de nye sporene.**

Jeg har kjørt 288 scenarier: 18 regionale kontrollpunkter, begge datoer, fire skyhøyder og to bakkehøyder, med solstråle og satellittparallakse. Tabellen viser VIS-gråverdi minus minimum på andre dager, bakke 0 m:

| Kontrollområde | 23.09: sky 1 / 2 / 5 / 10 km | 25.09: sky 1 / 2 / 5 / 10 km |
|---|---|---|
| Engerdal | 18 / 21 / 16 / 22 | 4 / 7 / 29 / 22 |
| Sørlige Femund | 13 / −7 / 9 / 20 | −7 / −9 / 1 / 24 |
| Solør/Finnskog | 23 / 24 / 28 / 25 | −1 / 28 / 13 / 23 |
| Messelt | 32 / 34 / 24 / 42 | 37 / 44 / 52 / 47 |
| Eidskog | 39 / 36 / 47 / 44 | 35 / 29 / 26 / 7 |
| Østfold innland | 39 / 41 / 47 / 46 | 10 / 10 / 16 / 14 |
| Sigdal | 52 / 53 / 52 / 54 | 22 / 8 / 23 / 47 |
| Krøderen | 47 / 50 / 53 / 49 | 3 / 5 / 10 / 58 |

23.09 bruker 14.50Z og referansedagene 21/22/24; 25.09 bruker 15.00Z og 21–24. Minimaene er ikke garantert skyfrie, og tallene er **ikke transmisjon, optisk tykkelse eller sannsynlighet**. Ett kontrollpunkt representerer heller ikke hele området. MSG-masken markerer sky ved samtlige undersøkte sørnorske kontrollpunkter 23.09; et binært skyfilter ville derfor vært lite nyttig. Tynn sky kan gi solstjerne.

Likevel gir den nye datoen en praktisk forskjell: **Engerdal–sørlige Femund får førsteprioritet for neste skrivebordssøk; Solør/Finnskog beholdes som egen sammenligning. Sigdal–Krøderen og de sørligere sporene ved Eidskog/Østfold får svakere værstøtte.** Østerdalen står åpent. Dette er min prioritering av videre analyse, ingen bekreftet lokasjon eller feltrute.

**3. Konkret svar på hvilke delområder du bør undersøke.**

- Først: skog innen **61,65–62,05 N / 11,65–12,25 Ø**, i Engerdal–sørlige Femund.
- Separat sammenligning: **60,40–61,05 N / 11,70–12,30 Ø**, Solør/Finnskog.

Dette er praktiske analyserektangler, ikke utledede grenser. Klipp til norsk land og skog. Rapporter K0–K4 som råverdier og følsomhet; ikke gjeninnfør dem som sikre avstands-/høydekrav fra bildet. B3-avstanden er fortsatt ute. En kandidat må få en konkret, kontrollerbar adkomst, med vann og terrenghindre vurdert. Nærmeste veilinje alene var nettopp det som ga oss C07-problemet.

**4. En alternativ geometrisk test er også kjørt.**

Jeg registrerte faste skogdetaljer mellom 21., 23. og 25.09 og tilpasset 21 solpunkter fra sju minuttsamlinger. Bilderegistreringen har medianavvik rundt 0,5 piksel; soltilpasningen gir f≈1040 px og restavvik 3,17 px. Men moderate endringer i pikselvalg, kamerastilling og forsinkelse flytter resultatet hundrevis av kilometer. 200 følsomhetsscenarier spenner omtrent 55,7–63,7 N og 6,9–17,2 Ø, uten at dette er sikre yttergrenser. **Det beste punktet skal ikke bli en ny kartmarkør.** Det nye, brukbare beviset er soldatoen, ikke en kunstig presis koordinat.

Pakken inneholder norsk notat, råbilde, kontaktark, satellittkart, alle 288 scenarier, kildeadresser/SHA256 og geometrisk følsomhet med skript. Ingen nye stedskoordinater er bekreftet.
