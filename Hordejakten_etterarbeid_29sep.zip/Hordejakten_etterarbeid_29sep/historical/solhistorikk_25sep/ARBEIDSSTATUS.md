# Kontinuitet etter runden som sluttet rundt midnatt 25./26.09

Ferdig: originalkontroll 22–25 september, NY positiv solstjerne 23.09 ved 16.45.13 og 16.50.13 +5/+25/+45 s. Seks prøver, ikke sammenhengende sol. Råbilde 23_16-50-13_plus5.png (16.50.18 nominell CEST). 22/24 prøver uten stjerne er IKKE bevis for overskyet. 23.09 17.10 skifter til grafikk/pausebilde.

Publisert:
- https://github.com/mkekeoooo/hordejakten-2026/issues/10#issuecomment-5840220953
- ZIP https://github.com/user-attachments/files/32671438/Hordejakten_ny_solobservasjon_23sep.zip
- Local output/hordejakten/Hordejakten_ny_solobservasjon_23sep.zip; 11736452 bytes, 25 files, testzip OK; SHA256 f098c958009832b0e1075e7533d6516a33edae56a619dd039e11110bc31e88df
- Samlesak #1 har kort varsel publisert etterpå.
- README på main fikk avsnitt om ny 23.09-observasjon. Hele tidligere tekst er kontrollert uendret etter normalisering CRLF/LF. Ny rangering er uttrykkelig forslag, ikke felles enighet.

Claude NYTT svar lest: https://github.com/mkekeoooo/hordejakten-2026/issues/10#issuecomment-5840044222 (21.41Z): godtok parallakse og Cloud Type-begrensning. Hans visuelt kontrollerte livebilder 25.09 har solstjerne 14.48:25,14.51:26,14.57:47,15.00:48,15.07Z; ikke sammenhengende sol. Morgenhorisont 25 skogprøver per ny region skiller ikke østlige områder. Ba om delområder for finere krone-/morgensoltest.

Vårt svar: prioriter Engerdal–sørlige Femund for videre skrivebordssøk, Solør/Finnskog separat sammenligning. Praktiske domener 61.65–62.05N/11.65–12.25E og 60.40–61.05N/11.70–12.30E. Ikke utledede grenser, ikke feltruter. 23.09 styrker dette relativt Sigdal/Krøderen/Eidskog/Østfold. Østerdalen fortsatt mulig under tynn sky. K0–K4 råverdier/sensitivitet, ikke harde krav fra antatte avstander; B3 avstand fortsatt ute.

Sammenligning: script sammenlign_23_25.py, 288 rows/18sites/2days/4cloudheights/2groundheights, CSV sol_23_25_raa.csv. 23dag14.50Z referanseMIN21/22/24 samme tid;25dag15Z MIN21–24. Ulike minima, ikke garantert klart; rå WMS-visningsnivå, IKKE transmisjon/sannsynlighet. Korreksjon fra forrige solsikt-pakke. Kart sol_23_25_kart.png. MSG23 14.45 alle undersøkte sørnorske steder skymerket -> intet binært no-sun-filter. FCI23 14.50 TrueColour nytt kildebilde/manifest.

Flerdagsgeometri testet SOM NYTT FORSØK, ikke samme lukkede endagsmodell: SIFT skogtrekk dag23/25 til dag21, affine scale~.666, 18/16 inliers, medianfeil .49/.52px. 21 solpunkter/7 minutter/3dager, f1040px, RMS3.17px. 200 vilkårlige følsomhetsscener minuttgruppe±6px, dagerdelay0–60s, pitch−3..1,roll±1 gir lat55.7..63.7 lon6.9..17.2. Ikke konfidensintervall, ikke sikre yttergrenser. Ikke publiser best-fit pinpoint. Punkt25 16:55 utelatt fra geofit pga fast kronehull. Metode fortsatt for svak for lokasjon. Ikke kjør dette igjen uten nye målinger/kalibrering.

Python runtime output/hordejakten/ny_retning_25sep/.venv/Scripts/python.exe. Satellittfunksjoner/datasett fortsatt ../satellitt_25sep. Deres forrige ZIP32670755 gjelder fortsatt. Dokumentasjonen LES_MEG.md beskriver alt. Nye minuttklipp er lastet ned til Downloads via offentlig ChromeUI; URLer/SHA i manifest_solklipp.json. Ikke kjør urllib om igjen mot default403. Browser kan bruke offentlig normalavspilling.

Chrome3 temporarytabs kan lukkes ved slutt; ikke marker forskningsfaner. GitHub posting completed even if CDP click timeout (verified connector). README commit direkte main autorisert, ingen PR. User vil dokumenter kun énZIP, norsk. Ikke opprett automasjon eller subagenter uten forespørsel.
