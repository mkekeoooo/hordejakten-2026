# Codex: kontroll av hintvideo og skogmodell, 25. september 2026

Dette er ny dokumentasjon til GitHub-sakene #1 og #8, ikke en ny lokalisering.

## Hovedresultater

1. **Hintvideoens undersøkte boksbilder gir ingen brukbar stereobaseline.**
   f0001 ble sammenlignet med f0025, f0050, f0075 og f0275 fra
   https://default.no/hints/frames.php . Én skalering/rotasjon/forskyvning passer
   98,6 %, 98,3 %, 98,0 % og 94,1 % av de gjensidige SIFT-korrespondansene innen
   RANSAC-modellen (2 px). Skalaene er 1,159 / 1,324 / 1,489 / 1,730.
   Med andre 100-pikselruter holdt utenfor tilpasningen er medianfeilen
   0,36 / 0,44 / 0,48 / 0,50 px. Resultatet er forenlig med zoom/utsnitt fra
   samme synspunkt. Det beviser ikke null kamerabevegelse, men gir ikke grunnlag
   for å bestemme treavstander med parallakse. Bare de oppgitte bildene er testet.
   Sammenligningen mot dagbildet har bare 18 gjensidige korrespondanser og brukes
   derfor ikke som en sikker kameraidentifikasjon.

2. **Skogtesten avhenger av både kamerakoordinat og hvordan arealet samples.**
   `sector_audit.py` sammenligner hver rastercelle én gang med radial prøvetaking
   ved 0,5°/0,5 m. Sistnevnte gir gjentatte prøver av samme celle og større vekt
   per areal nær kameraet. Dette er ikke samme statistikk. Kameraet testes både
   i den publiserte koordinaten og 5 m mot 39°.
   Ved kandidat 1 uten kameraforskyvning er K1-medianen 5,54 m med unike celler,
   men 2,86 m med radial prøvetaking; terskelen 3 m skifter dermed utfall.
   K0 endres fra 0,08 til 11,35 m når kameraet flyttes 5 m i cellevarianten.
   Resultatene er følsomhetskontroll, ikke en full reproduksjon av rapporten.

3. **A1 ved 61.4487, 10.9775 har svak skogstøtte i de benyttede rasterne.**
   Med unike celler er K2/K3/K4 1,59/0,50/1,94 m uten forskyvning og
   5,17/0,92/2,01 m med +5 m. Ingen av de 25 testposisjonene består alle K-kravene,
   i noen av de fire kombinasjonene. Dette støtter Claudes tallmessige innvending
   ved det eksakte punktet, men dokumenterer ikke dagens skog eller hele A1-området.

4. **Modell v6 finnes, men er et eldre scenario.** Den vedlagte originale pakken
   `historikk/reproduksjon_modell_v6.zip` inneholder hj_modell.py og de faktiske
   posisjonene for de seks eldre områdene. Her er E/N i modellen kameraposisjoner;
   man skal ikke legge på fem meter enda en gang ved testing av disse radene.
   Pakken bruker fortsatt B3 = 17–44 m, som senere ble trukket tilbake. Den er ikke
   hele reproduksjonsgrunnlaget for de senere østlige kandidatene 1–5. Det siste
   publiseringsarkivet inneholdt rapporter og figurer, ingen Python-filer.

## Hva ligger i pakken?

- Kameraskript, numeriske resultater, tilbakeholdt kontroll og korrespondanser.
- `sector_audit.py` og `sector_audit_results.json` fra de opprinnelige rasterne.
- `raster_utdrag/`: små, uendrede utsnitt fra de samme GeoTIFF-ene, med opprinnelig
  celleplassering, EPSG:25833 og 1 m oppløsning. Dekker alle prøveposisjoner og sektorer.
- `historikk/reproduksjon_modell_v6.zip`: brukerens mottatte pakke, uendret.
- `adsb/`: de to originale 22.09-sporene og kildeoversikt, slik at Claude kan bruke
  de korrekte hex-identitetene videre. Ingen nye påstander om reaksjonsidentitet.
- Metadata og SHA-256 for kildedata og pakkeinnhold.

Kjør skogkontrollen med:

    python sector_audit.py --root raster_utdrag

Krever Python 3, numpy, rasterio og pyproj. Kamerakontrollen krever også
opencv-python-headless. Last de fem nevnte bildene fra kildegalleriet og legg dem
som f0001.jpg, f0025.jpg, f0050.jpg, f0075.jpg og f0275.jpg i en mappe:

    python camera_motion_audit.py --image-dir bilder
    python camera_holdout.py

Bildene er ikke redistribuert i denne pakken. Kildehashene finnes i resultatfilen.
Kartverket er kilde for DTM/DOM (CC BY 4.0); adsb.lol er kilde for flysporene (ODbL).
DOM-prosjektlisten inneholder flere årganger. Dekningsprosjekt er ikke i seg selv
bevis for hvilken årgang mosaikktjenesten valgte i hver piksel. DOM-årgang er derfor
fortsatt ikke bekreftet per prøveflate.

## Avklaringer som ikke må bli borte

- README er oppdatert: ingen region er bekreftet, og den gamle rangeringen er historisk.
- Claudes flytabell 21.09 og terrenghorisontene 5a/5b/5c er kjørt om og gjenskapt.
- 0 % direkte lys ved alle steder i en tett DOM-modell skiller ikke mellom stedene.
- Solutelukkelse trenger den belyste flatens geometri; terrengvinkelen fra markøren
  alene er ikke et selvstendig mål på høyden til kronen i bildet.
- Jeg fant ikke en verifiserbar original produkttekst for bever/olivenolje i åpne
  Horde-kilder. Dette er fortsatt et ubekreftet appspor uten geografisk utledning.
