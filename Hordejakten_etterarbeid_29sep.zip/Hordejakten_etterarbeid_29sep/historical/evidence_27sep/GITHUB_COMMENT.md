**Codex 27.09: to regntavler er nå kontrollert i originalvideo. Dette endrer kildegrunnlaget for rangeringen.**

Jeg har nå fått lest minuttarkivet i nettleseren, der de tidligere direkte nedlastingene ga 403.

- **26.09 kl. 07.45:** tavlen sier «REGNET LITT I NATT + SMÅREGN NÅ!». Dette er skrift på tavlen, ikke et lydutsagn eller bare chatreferat. [Originalminuttet](https://default.no/clips/min/2026-09-26/07-45-03.mp4), tydelig ved +30 s. SHA256 `4e1106b825ffb2fe3424ae7f9c591ac2a17f07343694c548fef7d9a20c09f7dd`.
- **26.09 kl. 10.57:** tavlen sier «REGNER BITTELITT», etterfulgt av «FORTSATT KAMERA OG SKOG FORAN MEG». [Originalminuttet](https://default.no/clips/min/2026-09-26/10-57-11.mp4), +30 s. SHA256 `fef014949d552ac53cb6c31de192cc5751ee5a46d6f182d5ffc0850e29bd2350`.

Tidene er arkivets filnavn; jeg har ikke kalibrert arkivklokken uavhengig mot UTC. Ingen lydtolkning er brukt.

**Rettelse til min egen tidligere prioritering:** S03s fordel i 17-hendelsestesten er fortsatt betinget av de andre referatenes riktighet. Jeg gjennomgikk et tre timers arkivklipp og målrettede utsnitt rundt flere oppholds-/regntider. Jeg har foreløpig ikke verifisert de oppgitte oppholdene i originalen. Deler av opptaket har nesten helt tildekket bilde. Dette falsifiserer ikke referatene, men de kan ikke gis samme kildevekt som de to lesbare tavlene. Vi bør ikke beskrive den lange sekvensen som 17 kontrollerte observasjoner, eller S03 som en unik, uavhengig bekreftet vinner.

**Ny kontroll mot MET originalradar: 3×3 celler, ±5 min, gjennomsnitt mm/t.** No-data, blokkering og ground clutter er maskert; manglende verdier er ikke satt til null.

| Punkt | 07.45 | 10.57 |
|---|---:|---:|
| S03 60.53938, 12.18334 | **0,000** | 0,091 |
| K01 60.60356, 12.14124 | 0,569 | 0,121 |
| K02 60.59997, 12.17279 | 0,316 | 0,130 |
| L07 | 0,007 | 0,001 |
| A01 | 0,003 | 0,000 |
| Nytt: Vasslia/Sollivegen 60.636415, 10.459724 | 0,297 | 0,106 |
| Nytt: Sæsetvegen/Ansetmoen 60.638249, 11.964143 | 0,171 | 0,202 |
| Nytt: Tyskebergsvegen 60.626242, 12.391561 | 0,122 | 0,144 |

Alle celler/tider er gyldige i de tre nye radarradene unntatt første Vasslia-vindu (96,3 %). Radaren kan overse yr; ingen nullverdi alene utelukker S03. «Bittelitt» er heller ikke en kalibrert mm/t-terskel. Dette er to regnobservasjoner, ikke en ny fasitmodell.

**Et separat funn: gammel DOM/ortofoto ga reelle hogstfalskpositiver.** Jeg undersøkte ti nye 2×2 km-områder. I første pulje på 13 detaljpunkter hadde sju et eksplisitt hogstår i NIBIO SR16 beta: Rogberget 2024/2020, Tyskebergsvegen 2019, og flere andre 2020–2024. Ved Tyskebergsvegen **60.639717,12.402552** viser 2017-bildet skog, men valgt **Innlandet SØ 2025 (4916)** viser en åpen flate. Ved Rogberget 60.757058,12.223976 ligger markøren på kanten av en nyere hogstflate. Ikke bruk høy DOM-minus-DTM som bevis på nåværende høye trær. Et hogstflagg for én 16 m-celle utelukker ikke hele området.

Jeg la derfor inn SR16s oppdaterte høydeklasser og treslagskart, undersøkte et nytt parti vest for Mjøsa og kjørte om alle ti detaljområdene. Den nye Vasslia-kontrollen over har bevart skog i 2024-bildet, ca. **233 m til kartlagt vei mot 145°, +32 m** fra veipunktet; Sæsetvegen har ca. **211 m / 242° / +7 m**. Det er luftlinjer i terrengmodellen, ikke feltbekreftede ruter eller verifisert offentlig veieierskap. Ingen unik lysning/stamme-/steinmatch er funnet. Flyhypotesens konflikt er ikke løst av disse værtreffene.

Jeg anbefaler at README skiller mellom **to originalkontrollerte regntavler** og den **betingede 17-referatmodellen**, og at nye skogpunkter kontrolleres mot hogstoppdateringer før de prioriteres. Dette erstatter ikke S03 med en ny «sikker» markør.

Kilder: [MET originaldata 26.09](https://thredds.met.no/thredds/dodsC/remotesensing/reflectivity-nordic/2026/09/yrwms-nordic.mos.pcappi-0-dbz.noclass-clfilter-novpr-clcorr-block.nordiclcc-1000.20260926.nc.html) · [NIBIO SR16 og produktark](https://www.nibio.no/tema/skog/kart-over-skogressurser/skogressurskart-sr16) · [Tyskebergsvegen i valgt 2025-prosjekt](https://norgeibilder.no/?wkid=25833&is3d=false&xmin=357105.5383601311&xmax=358798.0383601311&ymin=6724989.4108971&ymax=6725941.4421471&id=4916). Originaluttrekk, kontrollbilder og full metode er lagret lokalt i denne runden.
