# Hordejakten — original evidence and ten new areas, 27 September 2026

The material change is two original written rain observations, plus an independent forestry check that caught several false positives from old canopy data. No treasure location or unique clearing has been identified.

## 1. Original rain boards, verified visually

| Archive label, 26 September, assumed CEST | Exact weather text | Source |
|---|---|---|
| 07:45:03 | REGNET LITT I NATT + SMÅREGN NÅ! | https://default.no/clips/min/2026-09-26/07-45-03.mp4 |
| 10:57:11 | REGNER BITTELITT | https://default.no/clips/min/2026-09-26/10-57-11.mp4 |

Both boards are readable at +30 seconds in the downloaded minute. The second also says FORTSATT KAMERA OG SKOG FORAN MEG. Full frames, crops, source URLs, offsets and video SHA256 checksums are saved in this folder and `original_minutes.json`. These are written boards, not audio observations. Archive-clock accuracy and stream latency have not been independently established.

A three-hour 08:00–11:00 archive cut was also sampled around the reported wet/dry transitions. Several samples have unrelated writing or the reverse of a board; the image around 08:57 is nearly obscured. The claimed dry intervals have NOT been verified. Failure to find a readable board in these samples does not falsify the secondary reports. The original 17-event fit remains conditional on the reports and is not equivalent to 17 original observations.

This revises the evidential basis of the previous S03 preference. It does not prove that S03 is wrong. Implementations sharing the same reports and MET radar are not independent weather evidence.

## 2. Fresh radar comparison

Primary source: [MET Nordic radar, 26 September](https://thredds.met.no/thredds/dodsC/remotesensing/reflectivity-nordic/2026/09/yrwms-nordic.mos.pcappi-0-dbz.noclass-clfilter-novpr-clcorr-block.nordiclcc-1000.20260926.nc.html).

The comparison uses the original 1 km cells and five-minute time steps, a 3×3 neighbourhood and ±5 minutes around each archive time. No-data, blocked and ground-clutter flags are masked. All numbers below are means in mm/hour, not location probabilities or observed rain-gauge measurements.

| Location | WGS84 latitude, longitude | 07:45 | 10:57 |
|---|---|---:|---:|
| S03 | 60.53938, 12.18334 | 0.000 | 0.091 |
| K01 | 60.60356, 12.14124 | 0.569 | 0.121 |
| K02 | 60.59997, 12.17279 | 0.316 | 0.130 |
| L07 | 60.82353, 11.53750 | 0.007 | 0.001 |
| A01 | 61.23076, 11.72394 | 0.003 | 0.000 |
| New: Vasslia / Sollivegen, F06 original point 1 | 60.636415, 10.459724 | 0.297 | 0.106 |
| New: Sæsetvegen / Ansetmoen, P05 updated point 3 | 60.638249, 11.964143 | 0.171 | 0.202 |
| New: Tyskebergsvegen, P07 updated point 3 | 60.626242, 12.391561 | 0.122 | 0.144 |

Vasslia's first window has 96.3% valid samples; its second and the other two new rows have complete coverage. S03's first window is completely valid and zero throughout the 3×3 neighbourhood. L07's first window has 96.3% coverage. MET radar can miss shallow precipitation/drizzle: [MET explanation](https://www.met.no/nyhetsarkiv/sno-har-gatt-under-radaren-pa-yr). Therefore zero is a conflict, not an exclusion. The words 'småregn' and 'bittelitt' are not calibrated intensity thresholds.

Full exact outputs: `exact_two_rain_results.json`, `forest_exact_rain.json`, `updated_exact_rain.json`, with corresponding source manifests and raw ASCII responses. Coarse 5 km sample nodes were used only to select areas, then replaced by these local extractions. Coarse and detailed rates can differ materially.

## 3. Forestry correction

[NIBIO SR16](https://www.nibio.no/tema/skog/kart-over-skogressurser/skogressurskart-sr16) predicts forest properties at 16 m resolution and updates some raster properties following satellite-detected logging. Its January 2026 product sheet explicitly explains why height and volume become zero in detected harvest areas. This is a model, with positional and classification uncertainty; it is not a field inventory of the campsite.

Seven of the first thirteen detailed points have an explicit harvest year in SR16 beta:

| Point | Detected harvest year |
|---|---:|
| P03-1 Rogberget | 2024 |
| P03-2 Rogberget | 2020 |
| P05-2 Sæsetvegen area | 2024 |
| P05-3 Sæsetvegen area | 2022 |
| P07-1 Tyskebergsvegen | 2019 |
| P07-2 Tyskebergsvegen | 2019 |
| P08-1 Gjerdrumsætra area | 2020 |

Norge i Bilder's selected **Innlandet SØ 2025, project 4916** confirms the open patch at P07-1, which the Esri image dated 2017 showed as forest. P03-1 lies at the edge of a newer clearcut in the 2025 image. A harvest flag in a single 16 m cell does not eliminate surrounding woodland. The date displayed for the whole imagery project is not necessarily the exposure date at every point.

Source responses: `forest_info.json`, `harvest_info.json`, `forest_new_info.json`, `forest_new_harvest.json`; per-point HTML under the region folders. The HTML-only commented SR16_STATUS year was not treated as a validated acquisition year. The dedicated beta 3D-year layer was used where present. Empty results remain unknown.

## 4. Ten new areas actually checked

Two batches cover Rogberget/Kynndalen, Duengerhøgda, Sæsetvegen/Ansetmoen, Tyskebergsvegen, Gjerdrumsætra/Knipilen, Hammersborg/Trangenvegen, Langåsen/Siggerudsvegen, the Solørvegen corridor, Finnvegen/Huabergsvegen and Vasslia/Sollivegen west of Mjøsa.

Each received a 2×2 km terrain/surface extraction, roads and mapped waterways/buildings, place names and imagery. Twenty-two initial detailed points were followed by 27 revised representative points after introducing updated forest classes. These are sampled model positions, not counts of discovered clearings. All point-centred Esri contact sheets were visually reviewed. Military-layer point queries returned no boundary feature at the checked points; this is not an access permission.

The revised detailed screen requires at least 50% of a roughly 100 m square in mean-tree-height classes of 14 m or more, at least 20% pine-dominant map cells, at most 8 m ground range in a roughly 35 m square, 150–900 m to a mapped road, and at least 100 m/150 m from extracted water/building lines. These are search heuristics, not measured campsite requirements. The forest proportions describe classes of land pixels, not percentages of individual trees around Anja. Older DOM-only and revised SR16 screens have different forest inputs; their counts are not directly comparable.

### Conditional alternatives worth retaining

- **Vasslia / Sollivegen, 60.636415, 10.459724:** new western alternative; standing forest in point-centred imagery dated 2 August 2024. Ground about 463 m; road 233 m toward 145 degrees, candidate 32 m above the nearest road point. Updated SR16 gives mean height 21.9 m, spruce-dominant centre. Small neighbouring openings are visible, but no camera-scene match. Radar supports both written rain times. This is F06's original detailed point 1, not updated U1.
- **Sæsetvegen / Ansetmoen, 60.638249, 11.964143:** revised P05-U3, forest near the end of a track in imagery dated 14 May 2024. Road 211 m toward 242 degrees, +7 m. Both radar windows show light precipitation. The approach bearing conflicts with a strict southeast-road interpretation; road direction is not being silently discarded.
- **Tyskebergsvegen, 60.626242, 12.391561:** revised P07-U3, road 355 m toward 62 degrees, +52 m; both verified weather times fit. Steeper access, northeast road bearing and old 2017 Esri photography keep it lower priority. The 2025 photographs inspected elsewhere in P07 do not date this exact point.

### Downgrades and limits

Duengerhøgda is fragmented woodland among fields and yields no revised points. Several original Rogberget/Tyskeberg and second-batch candidates were on old logging footprints. Some revised Rogberget points are near wetlands/lakes, have higher nearest roads or a mapped water crossing. Hammersborg's precise first rain signal is much weaker than the coarse node suggested. Langåsen has comparatively stronger rain and at least one water crossing; some road elevations fall outside the downloaded tile and remain unknown. Solørvegen is flat forest near fields/roads rather than a distinctive scene. Several Gjerdrumsætra routes cross mapped water.

Road distances and gains are straight-line comparisons, not walked routes, travel times or road ownership checks. The OSM extract does not completely capture relations and off-window lake shores; a zero crossing count does not prove a dry route. The original public-road statement remains unverified. Aircraft identity/gesture geometry remains a separate unresolved conflict; these weather matches do not resolve it. No new area is a demonstrated all-clue winner.

## 5. Other sources checked

The publicly submitted screenshot on Praktiskinfo clearly displays **2023** as a result for one padlock, but this was already reported and has not been independently earned in the game or tested on a physical lock. The official game now loads its first stage. No Horde account was created. Fresh public web searches, the official campaign page, FINN clue and later archive footage provided no verified new geographic instruction in this pass. The latest board seen around 27 September 19:12 contains an incomplete 'Gjeldfrive…' string; it was not converted into a place-name claim.

## Files and reproducibility

`GITHUB_COMMENT.md` is the correction prepared for issue 13. `original_minutes.json` and `morning_source.json` identify the original archive material. Raw responses and source URLs are kept beside each calculation. `updated_detail_scan.py` documents the revised search. Images from Norge i Bilder are credited **© Norge i Bilder / Geovekst**; Esri imagery retains its source metadata. Dependency scripts and input manifests live in the adjacent `broad_27sep`, `regn_26sep` and `nytt_landsok_26sep` folders. The large videos remain in Downloads and are linked and checksummed rather than included in the evidence package.
