from pathlib import Path
import json,math,numpy as np
from PIL import Image
from scipy.ndimage import uniform_filter
from scipy.spatial import cKDTree
P=Path(__file__).parent;root=P.parent
s=np.load(P/'regional_forest_sample.npz');r,c=s['row'],s['col'];la,lo=s['lat'],s['lon'];z=np.load(root/'broad_27sep/screened_grid.npz')
spec=np.array(Image.open(P/'regional_SRRTRESLAG.png').convert('RGBA'));height=np.array(Image.open(P/'regional_SRRHOYDEM.png').convert('RGBA'))
def frac(a,colors):
 mask=np.zeros(a.shape[:2],bool)
 for color in colors:mask|=np.all(a[:,:,:3]==color,axis=2)&(a[:,:,3]>0)
 return uniform_filter(mask.astype(float),3)[r,c]
pine=frac(spec,[[205,170,101]]);spruce=frac(spec,[[82,176,56]]);decid=frac(spec,[[255,220,130]])
tall=frac(height,[[0,109,44],[0,68,27],[0,40,15]])
g=np.load(root/'nytt_landsok_26sep/wide_radar.npz');tree=cKDTree(np.c_[g['lat'].ravel()*111195,g['lon'].ravel()*111195*math.cos(math.radians(61))]);dist,k=tree.query(np.c_[la*111195,lo*111195*math.cos(math.radians(61))]);rain0=g['events'][0].ravel()[k];rain1=g['events'][10].ravel()[k]
keep=(rain0>=.05)&(rain1>=.05)&(dist<3500)&(tall>=.5)&(pine>=.3)
old=[[60.53938,12.18334],[60.60356,12.14124],[60.59997,12.17279],[60.82353,11.5375],[61.23076,11.72394]]+[a['seed'] for a in json.loads((P/'new_area_results.json').read_bytes())]+[[a['lat'],a['lon']] for a in json.loads((root/'broad_27sep/refined.json').read_bytes())]
out=[]
for i in np.argsort(tall+.2*pine-.005*z['relief'])[::-1]:
 if not keep[i]:continue
 def distance(a,b):return math.hypot((la[i]-a)*111195,(lo[i]-b)*111195*math.cos(math.radians(61)))
 if any(distance(a['lat'],a['lon'])<7000 for a in out):continue
 nearest=min(distance(a,b) for a,b in old)
 if nearest<4500:continue
 out.append(dict(id=f'F{len(out)+1:02}',lat=float(la[i]),lon=float(lo[i]),ground_m=float(z['height'][i]),relief=float(z['relief'][i]),pine_fraction=float(pine[i]),spruce_fraction=float(spruce[i]),deciduous_fraction=float(decid[i]),height_class_ge14m_fraction=float(tall[i]),rain0745=float(rain0[i]),rain1057=float(rain1[i]),nearest_previous_m=nearest))
 if len(out)==6:break
(P/'forest_aware_seeds.json').write_text(json.dumps(dict(passing_count=int(keep.sum()),selected=out),indent=2));print(json.dumps(dict(passing_count=int(keep.sum()),selected=out),indent=2))
