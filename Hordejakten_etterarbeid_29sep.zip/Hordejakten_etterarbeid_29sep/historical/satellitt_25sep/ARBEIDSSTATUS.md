# Hordejakten – siste leveranse 25.09, sen kveld

Denne arbeidsrunden er fullført: landsdekkende satellittinnhenting, 360 solstrålescenarier, to landskart, publisert svar og README.

- Ny kommentar: https://github.com/mkekeoooo/hordejakten-2026/issues/10#issuecomment-5839791607
- Claude 21.02Z: https://github.com/mkekeoooo/hordejakten-2026/issues/10#issuecomment-5839574286
- ZIP: https://github.com/user-attachments/files/32670755/Hordejakten_landsok_solsikt_25sep.zip
- Lokal ZIP: ../Hordejakten_landsok_solsikt_25sep.zip (22 797 146 byte, 37 filer, testzip OK).
- README på main oppdatert og kontrollert med connector: positiv sol rundt 17 CEST, ingen region bekreftet. Resten av README bevart.

Hovedfunn: egen solobservasjon 25.09 ca. 17.00.33 CEST bekreftet av Claude. Hans påstand om ingen sol trukket. Skyene langs solstrålen tegnes ~3/6/15/30 km VNV fra Messelt i geostasjonært kart ved 1/2/5/10 km høyde. Vi har kjørt sfærisk ray trace; dette er scenarier, ikke målt skyhøyde. Korrigerte VIS-verdier gir fortsatt mer signal over Messelt/A2/østGlomma enn flere kontrollsteder i øst/sør. Nye undersøkelsesområder Engerdal/sørlige Femund og sørøst; Sigdal/Krøderen følsom backup. Ingen ny bokskoordinat eller feltrute. Åheim svakere, ikke alle vestlige skoger utelukket. EUMETSAT Cloud Type RGB advarer lav sol/høy visningsvinkel, her 13.8° sol/70.2° satellittsenit; har korrigert Claudes for bastante faseslutning. Tynn sky kan gi direkte sol. IR alene måler ikke optisk tykkelse.

Data: satellitt_25sep/LES_MEG.md forklarer alt. EUMETSAT WMS EPSG4326 4–32E/57.8–71.5N,1680x1370. 21–25Sep VIS ved14:50/15/15:10UTC,TrueColour21&25. MSGCLM15UTC21–25. Skyklar referanse gjør nordligste Norge grått/ukjent. Ikke tolk mørkVISFinnmark som vinner. Røros har delvis dårlig klarbasis. Pixelverdier er rendering, ikke fysisk reflektans.

Kode: hent_bilder.py -> solsikt.py -> kontroller_klarbasis.py -> lag_kart.py -> sluttkart.py. Python venv ../ny_retning_25sep/.venv/Scripts/python.exe. requests mangler, urllib fungerer. Ingen subagenter tillatt uten eksplisitt bestilling.

Andre tidligere funn allerede publisert: ballongbokstavene samme 13, rekkefølge flyttes, eksakte anagrammer THE SHOPLIFTER/FILTER THE SHOP/HELHET FOR TIPS, ikke THE FOREST HILL. Hender fantes21Sep ved skilt, ny plassering25Sep; ingen dokumentert kode. Alle detaljer i forrige pakke og #1 kommentar5839240347. Ikke gjenta disse kontrollene.

Videre arbeid skal ha ny observasjon eller konkret ny geografisk test; ikke en ny runde småkorreksjoner av gamle markører. Brukeren ønsker alt på GitHub norsk, én ZIP for vedlegg, ingen Hordeapp-konto. GitHub skriv gjennom Chrome UI, connector read fungerer og write403 tidligere. Han har uttrykkelig autorisert kommentarer, filer og vesentlige READMEoppdateringer. Ikke jakt privat støtteapparat eller omgå 403.
