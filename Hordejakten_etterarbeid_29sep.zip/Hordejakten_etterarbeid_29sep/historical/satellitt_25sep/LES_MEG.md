# Hordejakten – landsøk med solstråler og satellittparallakse

Utarbeidet 25. september 2026 av Codex. Selvstendig sammenligning; ingen plassering er bekreftet.

## Hva arbeidet faktisk endrer

Vi har en positiv solobservasjon 25.09 omtrent kl. 17.00.33 CEST. Den skal erstatte antakelsen om at hele ettermiddagen var overskyet på boksstedet. Claude har bekreftet solstjernen i egne bilder og trukket den tidligere slutningen tilbake i sak 10. Hele solintervallet hans er ikke kontrollert sammenhengende av meg.

Den nye beregningen undersøker solstrålen gjennom hypotetiske skyhøyder og hvor disse skyene havner i et geostasjonært satellittkart. Rundt Messelt er den samlede forskyvningen omtrent 3,1 / 6,1 / 15,2 / 30,3 km mot 284° ved skyhøyder på 1 / 2 / 5 / 10 km. Dette gjelder bakken ved havnivå; CSV-en har også 900 m som følsomhet. Skyene ligger fysisk i solretningen; vest-nordvest er hvor disse skyene blir tegnet i satellittkartet etter parallakse. Det er ikke solas kompassretning.

Det er derfor utilstrekkelig å lese skyverdien rett over kandidatkoordinaten. Dette er en viktig geografisk forskjell, ikke en liten korreksjon på en allerede kjent lokasjon.

**Praktisk prioritering for videre skrivebordsundersøkelse:** inkluder skogområdene Engerdal–sørlige Femund og det sørøstlige grenseområdet som selvstendige spor, med Sigdal–Krøderen som en ytterligere sammenligning. Dette er værbaserte undersøkelsesområder. Veier, skog og bildegeometri er ikke kontrollert lokalt der i denne pakken. Ingen av kontrollpunktene er en anbefalt boksposisjon eller feltrute. Messelt/Østerdalen står fortsatt åpent fordi tynn sky kan slippe gjennom direkte sol.

## Observasjonen

- Original: https://default.no/cuts/202609251620_202609251703.mp4
- Offset 2400 s: solstjerne øverst til høyre, omtrent x=1605,y=80 i 1920×1080.
- Arkivtid knyttet til minuttklipp 16.40.33 gjennom en bildeidentisk prøve, omtalt i forrige pakke. Tiden er ikke en måling av kameraets forsinkelse til seeren. Bruk omtrent ett minutts usikkerhet.
- Forrige pakke med råbildet og tidskontrollen: https://github.com/user-attachments/files/32669707/Hordejakten_ballonger_hender_sol_25sep.zip
- Claude bekrefter og beskriver egne bilder: https://github.com/mkekeoooo/hordejakten-2026/issues/10#issuecomment-5839574286

En lysende solstjerne betyr ikke at hele himmelen er skyfri. Den kan ses gjennom tynn cirrus. Et fravær av solstjerne mellom trær sier heller ikke sikkert at det er skyer.

## Gjennomført beregning

1. EUMETSAT FCI VIS0.6 og True Colour for 21. og 25.09 kl. 14.50, 15.00 og 15.10 UTC. VIS0.6 fra 22.–24.09 på de samme tre klokkeslettene gir en fire dagers minimumsreferanse.
2. MSG-skyklassifikasjon kl. 15.00 UTC 21.–25.09. Ved 15.00 lages også en strengere referanse der bare piksler klassifisert som klart land i minst én av dagene 21.–24.09 brukes. Manglende dekning eller manglende klar referanse gir ingen verdi, ikke «klart».
3. Hele fastlandsutsnittet 4–32° Ø, 57,8–71,5° N undersøkes. Det nasjonale sammenligningskartet har gyldig, skykontrollert referanse for 191 810 landpiksler i 2 km-scenarioet og 180 285 i 10 km-scenarioet. Dette er pikseltall, ikke areal eller sannsynlighet. Nordligste Norge mangler referanse i MSG-produktet og er grått på kartet.
4. Detaljtabellen inneholder 15 kontrollpunkter × 3 tider × 4 skyhøyder × 2 bakkehøyder = 360 scenarier. Hvert punkt leses som median i en fysisk radius på 1 km med 250 m prøvetaking. Dette er ikke uavhengige observasjoner: mange prøver lander i samme resamplede satellittpiksel.
5. Sfærisk geometri, jordradius 6371 km og satellitt på 0° ved radius 42164 km. Solstrålen skjærer et skallsjikt, og linjen satellitt–sky forlenges til jordoverflaten. Ingen atmosfærisk brytning eller virkelig skyhøyde er estimert. Nullhøyde er kontrollert til å gi tilbake samme geografiske punkt.

WMS er hentet som EPSG:4326, 1680×1370 piksler, versjon 1.1.1 med lon/lat-akseorden. Pikselstørrelsen er 0,01667° lengde × 0,01° bredde, og er ikke instrumentets native oppløsning. FCI VIS0.6 HRFI har nominelt 0,5 km oppløsning ved nadir; geometri og resampling gir ikke 0,5 km lokasjonsnøyaktighet i Norge.

## Eksempler fra detaljtabellen

Tallene er VIS-gråverdi 25.09 minus minimum 21.–24.09 ved samme klokkeslett, i det solstrålekorrigerte området. Tabellen nedenfor gjelder 15.00 UTC og bakkehøyde 0 m. Den bruker fire dagers minimum, ikke den strengere skyklassifiserte referansen i landskartet.

| Kontrollområde | Sky 1 km | Sky 2 km | Sky 5 km | Sky 10 km |
|---|---:|---:|---:|---:|
| A2 | 32 | 37 | 40 | 43 |
| Messelt | 37 | 44 | 52 | 47 |
| Øst for Glomma | 30 | 33 | 40 | 54 |
| Trysil | 35 | 10 | 6 | 22 |
| Engerdal | 4 | 7 | 29 | 22 |
| Sørlige Femund | −7 | −9 | 1 | 24 |
| Sigdal | 22 | 8 | 23 | 47 |
| Krøderen | 3 | 5 | 10 | 58 |
| Østfold innland | 10 | 10 | 16 | 14 |
| Åheim | 41 | 48 | 56 | 41 |

**Tallene er gjengitte bildeverdier, ikke reflektans, skytykkelse, transmisjon eller sannsynlighet.** Et negativt tall viser særlig hvorfor en fire dagers minimumsreferanse ikke automatisk er en perfekt klarværsreferanse: overflaten, belysningen og tidligere skydekke varierer. Et lavt overskudd beviser ikke klarvær. Naboklokkeslett og høyder må leses samlet. Eksempelvis blir Krøderen mye lysere i 10 km-scenarioet, og området bør derfor ikke velges på grunnlag av et mørkt punkt ved bakken alene.

## Hva vi kan si geografisk

- Åheim har et høyt signal i alle de undersøkte solstrålescenarioene. Dette svekker olivinsporet i denne sammenligningen, men er ikke en generell utelukkelse av alle vestlige skogområder.
- A2, Messelt og kontrollpunktet øst for Glomma får også betydelig signal. Ingen av dem er bekreftet av været. Tynn sky gjør samtidig at den observerte solstjernen ikke sikkert utelukker dem.
- Engerdal/sørlige Femund og sørøst viser mindre signal i flere scenarioer og fortjener uavhengig undersøkelse. Røros har svakere klarværsreferanse og kan ikke automatisk slås sammen med disse som «klart».
- Sigdal–Krøderen og deler av Telemark hadde mørke felt i den første direkte pikselavlesningen. Solstrålekorreksjonen viser stor høydefølsomhet. Dette er sammenligningsområder, ikke nye vinnere.
- Finnmark skal ikke fremmes fordi VIS-bildet er mørkt. Lav sol, svært skrå satellittgeometri og manglende klar referanse begrenser sammenligningen. Den tidligere sol/kameraanalysen har dessuten egne, fortsatt usikre, begrensninger i nord.

## Avgrensning mot Claudes Cloud Type-tolkning

EUMETSATs Cloud Type RGB-guide sier eksplisitt at produktet ikke er egnet ved høye satellittsynsvinkler eller lave solhøyder. Ved Messelt kl. 17.00 er solhøyden beregnet til 13,8° og satellittens senitvinkel til omtrent 70,2°. Derfor kan cyan/hvit/rød farge ikke alene gi en hard utelukkelse eller sikker bestemmelse av skyenes transmisjon her. En IR-temperatur alene løser heller ikke optisk tykkelse for delvis gjennomsiktig eller flerlags sky.

Dette endrer ikke at de vestlige bildene er skyfulle. Det begrenser styrken i konklusjonen «vannsky som sikkert stenger sola ved akkurat denne bakken».

## Kilder

- VIS0.6-produkt: https://view.eumetsat.int/productviewer/productDetails/mtg_fd%3Avis06_hrfi
- MSG-skyklassifikasjon: https://view.eumetsat.int/productviewer/productDetails/msg_fes%3Aclm
- Cloud Type RGB og begrensninger: https://user.eumetsat.int/s3/eup-strapi-media/QG_Cloud_Type_RGB_ab06957dd1.pdf
- EUMETSAT om parallakse: https://cwg.eumetsat.int/parallax-corrections/
- EUMETSAT WMS: https://view.eumetsat.int/geoserver/wms
- Landgrenser: Natural Earth, https://www.naturalearthdata.com/downloads/50m-cultural-vectors/50m-admin-0-countries-2/
- Alle bildeadresser og SHA256 ligger i manifestfilene. Kilde for satellittbildene: EUMETSAT. Kartgrenser: Natural Earth.

## Reproduksjon og innhold

Python: numpy, Pillow, scipy, matplotlib, shapely, astral, pyproj. Ingen innlogging brukes.

Kjør `hent_bilder.py`, `solsikt.py`, `kontroller_klarbasis.py`, `lag_kart.py` og `sluttkart.py` i denne rekkefølgen. Nedlastingsskriptene gjenbruker eksisterende bilder. ZIP-en inneholder originale WMS-bilder ved 15.00 for å holde pakken håndterlig; nabotidene lastes ned ved reproduksjon. Manifestene dokumenterer også disse.

Se først `sor_norge_to_dager_solsikt.png`, deretter `landsok_med_solsikt.png`. `solsikt_scenarier.csv` har råverdier og geografiske forskyvninger for alle 360 scenarioer. `basis_kontroll.json` viser hvor en skyklassifisert referanse mangler. `landsok_solsikt_grid.npz` inneholder selve landskartets verdier. Tall med NaN betyr manglende verdi, ikke null. Modellens skyhøyder er valgt for følsomhet og skal ikke tilpasses hver enkelt kandidat som om de var målte.
