# Nye primærobservasjoner 25. september – ballonger, hender og et sikkert solglimt

Kontrollert av Codex 25.09.2026, kveld. Alle klokkeslett er norsk arkivtid (CEST). Dette er nye observasjoner, ikke en ny stedsrangering.

## 1. Ballongtavla ble skrevet om: linjeskiftet er ikke en fast kode

Kilde: https://default.no/cuts/202609251620_202609251703.mp4 – arkivtabellen viser 25.09 16.20–17.03, «Balonger». Filen varer 2640,47 sekunder. Gjennomgangen besto av ett bilde per minutt gjennom hele filen og tettere utvalgte bilder; ikke kontinuerlig visning av alle 44 minutter.

- Offset 0: tavla viser «GRATULERER», fem tellestreker, «DAGER» og et hjerte. Dette ser ut som markering av fem dager. Det skal ikke omtales som en dokumentert bursdag.
- Offset 600 s: «STLRT / OPIHH».
- Offset 840 s: «STLRT / OPIHHF / EE».
- Senere: «THILPRTE / OESHF».

De to komplette avlesningene har nøyaktig samme 13 bokstaver: E×2, H×2, T×2, F/I/L/O/P/R/S×1. Det er kontrollert maskinelt. Anja endret rekkefølgen/oppstillingen underveis. Vi bør derfor ikke behandle den senere 8+5-oppstillingen som et uforanderlig oppsett levert av arrangøren.

Tre eksakte anagrammer er THE SHOPLIFTER, FILTER THE SHOP og HELHET FOR TIPS. THE FOREST HILL er ikke eksakt: det mangler P og har en L for mye. Et eksakt anagram dokumenterer bare at bokstavene passer, ikke at løsningen er tilsiktet.

Min vurdering: THE SHOPLIFTER er en konkret hypotese fordi navnet ligner det kjente deltakeraliaset BobTheShoplifter. FILTER THE SHOP er en konkret instruksjonshypotese. Ingen av dem er et geografisk bevis. Den mest avgjørende neste testen er en reproduserbar respons fra en offentlig/tilgjengelig hintmekanisme eller arrangøren, ikke flere koordinater konstruert av bokstavene. En deltaker som allerede har appen, kan kontrollere om en av frasene gir en fast respons i den eksisterende ord-/hintmekanismen. Det er ikke testet her, og en fri AI-generert tekst vil ikke alene være bekreftelse.

Fargegruppene publisert av Pladsen er sekundærdata, ikke avlest bokstav-for-bokstav her. De må ikke gjøres til en femsifret kode uten en dokumentert fargerekkefølge. Fem gruppestørrelser 3,1,1,6,2 har 60 ulike rekkefølger. Koblingen til dartspillets fargeregler er foreløpig en antakelse, blant annet fordi ballongene også har grønt.

## 2. Den «nye» hånden har en tidligere motpart

Brukeren sendte et nattutsnitt av en oppreist hånd foran boksen. Direkte kontroll:

- 21.09 ca. 18.35, offset 10 s i https://default.no/cuts/202609211835_202609211836.mp4: to håndformede rekvisitter ses under det store Horde-logo-skiltet foran boksen.
- 25.09 16.40.33: en hånd står separat foran boksen. Den er allerede til stede under ballongsekvensen. En annen håndform er synlig langt til venstre i forgrunnen.
- 25.09 21.55.56-klippet viser hånden foran boksen i nattmodus. Brukerens utsnitt samsvarer med dette motivet.

Det er derfor ikke en helt ny type objekt introdusert i natt. Enkeltobjektenes identitet og alle tidspunkter for flytting er ikke sikkert bestemt. Arkivchatten kl. 16.39 spør også om hånden; en seer svarer at den var der de første dagene, ble borte og kom tilbake. Dette er bare en sekundær støtte til bildesammenligningen.

Relevant nytt spor er plassering/fingerstilling, ikke antakelsen «ny hånd = nytt stedsnavn». De gamle fingrene er delvis dekket av skiltet, og lys og kamerautsving er forskjellige. Vi har derfor ikke dokumentert en endring i et bestemt binærtall eller romertall. At hendene tidligere bar et skilt er også en praktisk forklaring på stillingen.

Et mulig ordspill er fem fingre → «five-finger discount» → shoplifting, men det er en hypotese med lav vekt, ikke uavhengig bekreftelse av anagrammet. Vi skal ikke bruke dette til å rangere steder.

## 3. Konkret positiv solobservasjon til satellittsaken #10

Ved offset 2400 s i ballongfilen ses en tydelig solstjerne/glans gjennom trekronene nær øvre høyre bildekant, omtrent piksel (1605,80) i 1920×1080. Det vedlagte `original_2400.png` er et direkte dekodet bilde uten lysjustering. Det er sterkere dokumentasjon på direkte sol enn bare en lys skogbunn.

Tidskontroll: bilde ved +1 s i https://default.no/clips/min/2026-09-25/16-40-33.mp4 ble sammenlignet med ballongfilen. Det samsvarer ved offset ca. 1201,35 s. Sammenligningen av det nedskalerte feltet rundt Anja/boksen gav MSE = 0. Dette knytter solbildet til omtrent **25.09 kl. 17.00.33 norsk arkivtid**, altså ca. **15.00.33 UTC**. Dette kalibrerer arkivfilene mot hverandre, ikke forsinkelsen fra kamera til arkiv. Bruk omtrent ett minutts observasjonsvindu fremfor å behandle hundredeler som absolutt tid.

Default.nos satellittbilde https://default.no/img/geo/2026-09-25/1640_mtg.png har selv overskriften «2026-09-25 16:40 local». Ikke tolk filnavnet som UTC. Jeg har ikke georeferert dette bildet eller beregnet hvilke områder som består satellittsammenligningen.

Til Claude: kryss den positive observasjonen rundt 17.00 CEST med dine satellittfelt rundt 15.00 UTC. Rapporter råverdier og følsomhet for tidsvindu, romlig vindu og skyterskel. En 7×7 km median kan ikke alene utelukke et lokalt solhull. Hvis dette skiller de gamle kandidatene, vis også kartet uten kandidatmarkører og undersøk klart land utenfor kandidatboksen; brukeren ønsker et åpent søk.

Lysvariasjoner bak stammer er ikke automatisk skypasseringer. Ingen påstand om et skyfritt område hele ettermiddagen trekkes fra dette ene bildet.

## 4. Det nye flyryktet

Kilde: https://default.no/cuts/202609251710_202609251722.mp4, 780,14 s. Jeg kontrollerte bilder hvert 10. sekund gjennom filen og hvert 2. sekund i offset 600–710 s. Rundt 618–622 s løfter hun blikket/hodet og har en hånd ved ansiktet. Stikkprøvene etablerer ikke en tydelig armretning til et bestemt fly; korte bevegelser mellom prøvene kan mangle. SAS50J eller SAS364 skal ikke tilskrives hendelsen bare fordi en chatmelding nevner fly.

## Konklusjon til fellesarbeidet

Nytt og brukbart: 1) dokumentert omskriving av ballongtavla, 2) håndrekvisittene er eldre, men står annerledes, og 3) et positivt solglimt ca. 17.00.33 med kontrollert intern arkivtid. Solglimtet er den av disse observasjonene som nå kan gi geografisk utslag uten å gjette hva arrangøren mente. Hånd-/ballongsporet bør testes som en gåte-/kodehypotese. Ingen av funnene alene dokumenterer et sted, og README-rangeringen endres ikke før den geografiske testen gir et faktisk resultat.
