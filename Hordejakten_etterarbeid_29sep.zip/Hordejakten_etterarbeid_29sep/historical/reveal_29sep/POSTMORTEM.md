# Why the reported location did not receive a detailed check

29 September 2026. This audit uses the **unverified coordinate posted in skiben's chat**, 60.5276944444, 12.1476388889. It is not an official location confirmation. The conclusions below describe how our saved search process treats that coordinate; if the final location differs, repeat the comparison there.

## Concrete findings from the saved data and selection code

1. **It was inside the 27 September regional scan**, and inside the saved official Grue boundary. The missing 44.8% of Grue in that particular regional raster does not explain this point being missed.

2. **The original coarse tree-height filter rejected this patch.** The closest raster centre is 8.6 m away. In its 5-by-5 neighbourhood, only 16% of samples had surface-minus-ground height above 12 m, whereas the search required at least 40%. The nearest actual sampled grid position, 117.4 m away, also scored 16%. Data coverage was 100%, and terrain relief passed. This is a result from old, coarsely sampled surface data, not proof that the present site lacks tall trees. We had not calibrated that filter against the scene or established the local surface-data acquisition date.

3. **The surrounding area did survive, but the follow-up dropped it.** A surviving coarse sample was only 331.1 m away, and 65 samples within 3 km survived. A selected weather representative, weather_3 at 60.5193873971, 12.1255322308, was 1.522 km away. It appears in region_results.json, but is absent from the explicitly selected ten detail-area IDs in batch_details.py and from detail_manifest.json. Those outputs do not document a site-specific rejection that justifies leaving it out. The tree filter therefore explains the exact patch's initial rejection, but cannot alone explain the missed surrounding area.

4. **A later search for new areas explicitly skipped places near old candidates.** evidence_27sep/forest_select.py discards proposals less than 4.5 km from any existing comparison point. S03 is one of those points, only 2.346 km from the reported coordinate. Thus that later pass could not select this neighbourhood even if its other conditions were satisfied. This was a novelty filter, not evidence that the skipped land had been thoroughly checked. Other passes had different criteria.

5. **Our S03 image inspection covered too little land to count as a search of this neighbourhood.** The saved 2025 orthophoto view spans only 677 by 336.5 m around S03. The reported coordinate, 2.346 km southwest, is outside that view. A regional weather match and an inspected pin did not amount to complete coverage between or around pins.

6. **Aircraft interpretations also diverted attention, with unresolved assumptions.** The saved direct-flight audit verified aircraft tracks, while explicitly leaving the aircraft Anja saw, the recording delay, and the meaning of her gesture unverified. It found that treating both evenings as precise overhead observations produced conflicts. Those caveats did not produce a systematic re-check of the S03 surroundings. This is a prioritisation weakness, not proof of which aviation assumption was actually wrong.

## Assessment

The failure was a combination of an unvalidated vegetation threshold, selective follow-up, and treating proximity to an old candidate as a reason to seek novelty elsewhere. The process generated and compared points, but did not maintain a reliable distinction between *covered by coarse data*, *selected by a model*, and *actually inspected in detail*. The appropriate correction would have been to review contiguous neighbourhoods around strong leads, retain a sample of rejected forest patches, and keep uncertain aircraft interpretations from closing those branches.

This does not prove a corrected process would have found the box from overhead images: tree canopy can obscure ground features, and the alleged location is still unconfirmed.

## Evidence

- Recomputed distances, coverage and filter values: `coverage_audit.json`; reproduction: `coverage_audit.py`.
- Original scan criteria: `../broad_27sep/screen_region.py`.
- Weather representative: `../broad_27sep/region_results.json`, weather_3.
- Explicit detail selection: `../broad_27sep/batch_details.py`; actual areas: `../broad_27sep/detail_manifest.json`.
- Later 4.5 km exclusion: `../evidence_27sep/forest_select.py`.
- S03 image extent: `../solor_adkomst_26sep/nib_manifest.json`.
- Aircraft limitations recorded at the time: `../nytt_27sep/DIRECT_CHECK.md`.

Local retrospective note only; no GitHub changes made during this audit.
