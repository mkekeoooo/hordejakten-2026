from pathlib import Path
import json, math
import numpy as np
from shapely.geometry import shape, Point

root = Path(__file__).resolve().parents[1]
lat, lon = 60 + 31/60 + 39.7/3600, 12 + 8/60 + 51.5/3600
def distance(la, lo):
    a = np.sin(np.radians(np.asarray(la)-lat)/2)**2 + math.cos(math.radians(lat))*np.cos(np.radians(la))*np.sin(np.radians(np.asarray(lo)-lon)/2)**2
    return 6371000*2*np.arcsin(np.sqrt(a))

result = {'notice': 'Retrospective comparison against an UNVERIFIED Twitch-chat coordinate, not an official location.', 'lat':lat,'lon':lon}
b = json.loads((root/'grue_28sep/boundary.json').read_text(encoding='utf-8'))
result['inside_grue_boundary'] = shape(b['omrade']).covers(Point(lon,lat))
result['S03_distance_m'] = float(distance(60.53938,12.18334))
result['S03_imagery_dimensions_m'] = [677,336.5166]
j = json.loads((root/'broad_27sep/region_sources.json').read_text())
box, n = j['bbox3857'], j['size']
x = 6378137*math.radians(lon)
y = 6378137*math.log(math.tan(math.pi/4+math.radians(lat)/2))
result['inside_27sep_regional_raster'] = bool(box[0]<=x<=box[2] and box[1]<=y<=box[3])
rf = (box[3]-y)/(box[3]-box[1])*n-.5
cf = (x-box[0])/(box[2]-box[0])*n-.5
z = np.load(root/'broad_27sep/DTM.npy', mmap_mode='r')
s = np.load(root/'broad_27sep/DOM.npy', mmap_mode='r')
for name,r,c in [('nearest_pixel',round(rf),round(cf)),('nearest_sample',int(12+6*round((rf-12)/6)),int(12+6*round((cf-12)/6)))]:
    patchz = z[r-2:r+3,c-2:c+3]
    h = s[r-2:r+3,c-2:c+3]-patchz
    valid = np.isfinite(h)&(h>=-10)&(h<=70)&(patchz>=0)&(patchz<2000)
    frac = float(np.mean(valid&(h>12)))
    relief = float(np.max(z[r-1:r+2,c-1:c+2])-np.min(z[r-1:r+2,c-1:c+2]))
    plon = math.degrees((box[0]+(c+.5)*(box[2]-box[0])/n)/6378137)
    plat = math.degrees(2*math.atan(math.exp((box[3]-(r+.5)*(box[3]-box[1])/n)/6378137))-math.pi/2)
    result[name] = dict(lat=plat,lon=plon,distance_m=float(distance(plat,plon)),height_m=float(z[r,c]),tall_fraction=frac,coverage=float(valid.mean()),relief_m=relief,passes_height_forest_terrain=bool(valid.mean()>.99 and frac>=.4 and relief<=20 and z[r,c]<1100))
grid = np.load(root/'broad_27sep/screened_grid.npz')
d = distance(grid['lat'],grid['lon'])
i = int(np.argmin(d))
result['nearest_surviving_regional_sample'] = {k:float(grid[k][i]) for k in grid.files}
result['nearest_surviving_regional_sample']['distance_m'] = float(d[i])
result['surviving_samples_within_3km'] = int(np.sum(d<3000))
files = ['broad_27sep/region_results.json','broad_27sep/detail_results.json','broad_27sep/refined.json','evidence_27sep/updated_detail_results.json','nytt_landsok_26sep/forest_candidates.json','nytt_landsok_26sep/forest_candidates_extended.json']
result['nearest_documented_points'] = {}
for f in files:
    p = root/f
    if not p.exists(): continue
    entries = []
    def walk(v,trail=''):
        if isinstance(v,dict):
            la,lo = v.get('lat'),v.get('lon')
            if isinstance(la,(int,float)) and isinstance(lo,(int,float)):
                entries.append(dict(path=trail,id=v.get('id'),lat=la,lon=lo,distance_m=float(distance(la,lo))))
            for k,w in v.items(): walk(w,trail+'/'+k)
        elif isinstance(v,list):
            for k,w in enumerate(v): walk(w,trail+'/'+str(k))
    walk(json.loads(p.read_text(encoding='utf-8')))
    result['nearest_documented_points'][f] = sorted(entries,key=lambda q:q['distance_m'])[:3]
out = Path(__file__).with_suffix('.json')
out.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
