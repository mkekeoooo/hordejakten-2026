# Kontroll av rapport v8 og F01–F25

Utført 25. september 2026. Les SVAR_TIL_CLAUDE.md for resultatene og forbeholdene.

- F01_F25_adkomst_beskrivende.csv: beskrivende avstander fra F-koordinatene til kartlagte objekter i tidligere nedlastede OSM-utdrag. «allroad» inkluderer track, «nontrack» utelater track. Ikke sertifisering av kjørbarhet eller parkering. Høydeforskjeller er nærmeste-celle DTM-prøver.
- *_coverage: within_query_radius betyr bare at funnet ligger nærmere enn kanten av det relevante nedlastede kartutsnittet. Det betyr ikke komplett kartlegging i OSM. may_be_nearer_outside_query markerer at et nærmere objekt kan finnes utenfor utsnittet. Avstand til water/building er til kartlagt way-geometri; polygoninnside, relasjoner og bygningsnoder er ikke fullstendig behandlet. Tallene er derfor beskrivende og ikke brukt som fraværsbevis eller harde filtre.
- model_25_recheck.json: ny kjøring av medsendt modell, med lokale filstier, ved publiserte geografiske F-koordinater. Kroneverdier og kameramodell er beregnet på nytt. Første treff er også undersøkt med 0,01 m avstandssteg for samme løsning.
- model_25_refined.json: samme kontroll, men også beregningen av gyldige kamerahøydeintervaller bruker 0,01 m avstandssteg. Dette er en numerisk følsomhetstest, ikke centimeterpresise høydedata. Ved ok4=false er hc/cal ikke en gyldig løsning.
- local_refined_summary.json og local_refined_points.json: nye lokale 2 m rutenett innen 20 m fra de publiserte representantene F01, F02, F17. Samme kroneterskler. Resultatene er ikke hele kollegaens sammenslåtte flekker.

Alle koordinater som er brukt som input kommer fra flekker_kontrolliste.csv (seks desimaler). Originale interne E/N-koordinater er ikke tilgjengelige med full presisjon i kontrollisten. Det kan gi forskjeller i cellemedlemskap og randtilfeller. Alle intervaltester er fortsatt diskrete; nøyaktig kontinuerlig skjæring ville kreve rotberegning mot valgt terrenginterpolant.

JSON-filene kan inneholde NaN for manglende treff, slik Python json skriver som standard. Det betyr manglende verdi, ikke null avstand.

Rådata finnes i tidligere adkomst_25sep.zip og DOM_kronetest_resultater.zip. Skriptene forutsetter prosjektets filstruktur. local_model.py er kollegaens v5-kilde med bare lokale stier/import tilpasset. De to originale kildefilene følger med for reproduksjon. En komplett ny kjøring av alle 45 150 posisjoner eller alle klynger er IKKE gjort i denne runden; antallene i de store CSV-filene er telt opp.

Kilder: rapport v8 og vedlagte skript/resultater; Kartverkets tidligere nedlastede NHM DTM/DOM; OpenStreetMap-råutdrag hentet 25. september 2026. Kartdata © OpenStreetMap-bidragsytere, https://www.openstreetmap.org/copyright.
