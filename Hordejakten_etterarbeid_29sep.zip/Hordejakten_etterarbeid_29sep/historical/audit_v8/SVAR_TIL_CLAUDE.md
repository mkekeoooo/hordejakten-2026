Hei!

Jeg har lest versjon 8, gjennomgått skriptene og kjørt nye kontroller. F01 er samme lokale område som våre C06/C07, og F17 svarer til området ved C23. F01 er fortsatt min første kontrollprioritet, men jeg fant en numerisk følsomhet og et konkret vannforbehold vi bør ta med.

1. Hva jeg har kontrollert

Opptelling i de vedlagte posisjonsfilene bekrefter 24 treff med v1, 25 med v2 og 17 felles, altså 32 i unionen. Dette er en kontroll av resultatfilene, ikke en ny kjøring av hele rutenettet. Jeg har i tillegg kjørt kameramodellen og den cellebaserte kronetesten på alle 25 oppgitte F-koordinater, og tettere lokale tester ved F01, F02 og F17.

Den cellebaserte prøvetakingen er en forbedring, og lagringen av en egen M0+B3+B4-løsning retter den tidligere koblingsfeilen. Til videre reproduksjon trenger pakken også kombi.py eller en selvstendig kjøreinngang: klynger.py, lokal.py og flekker.py viser til kombi.py og mellomfiler som ikke følger med. De fullstendige, uavrundede koordinatene bør lagres; ved rastercellegrenser kan selv små koordinatavrundinger endre hvilke celler som inngår.

2. En ny numerisk kontroll av første treff

hc_intervall bruker 5 cm steg for M0 og 25 cm for B3/B4. Kravet om første treff i intervallet gjelder derfor bare de prøvetatte avstandene. For B4 kan faktisk skjæring i den interpolerte terrengmodellen ligge mellom 11,75 og 12,00 m og likevel bli rapportert som et godkjent 12,00-meters treff.

Ved F01-koordinaten i kontrollisten gjenskaper jeg kamerahøyde ca. 1,557 m og K1. Med 1 cm avstandssteg gir den løsningen B4-treff ca. 11,76 m. Når høydeintervallene også beregnes med 1 cm steg, består ikke den eksakte markøren den strenge 12-metersgrensen. F03, F07, F13, F19 og F21 får samme type bortfall ved de oppgitte koordinatene. Dette er numerisk følsomhet, ikke grunnlag for å utelukke områdene eller påstå centimeterpresisjon i DTM.

Jeg undersøkte derfor nærområdet før jeg endret prioriteringen. På et 2 m rutenett innen 20 m fra den oppgitte F01-koordinaten er resultatet 25 treff med original prøvetaking og 24 med den tettere, av 317 undersøkte posisjoner. Nærmeste gjenværende posisjon ligger bare 2 m unna, omtrent 61.462505, 10.975048. F01-området står seg altså; den eksakte representanten og de avrundede treffavstandene bør ikke presenteres som presise mål.

Ved F02 får mitt lokale rutenett 19 treff med begge prøvesteg, og ved F17 sju med begge. Mine lokale rutenett er sentrert på CSV-ens representanter, ikke nødvendigvis på dine opprinnelige klyngesentre; antallene kan derfor ikke sammenlignes direkte med hele flekkenes posisjonstall.

3. Adkomst beregnet ved F-punktene

Jeg har brukt de tidligere innhentede OSM-rådataene og rapportert veier med og uten track separat. Resultatene nedenfor gjelder nærmeste kartlagte vei inkludert track. Stigning er høydeforskjell fra dette veipunktet til kandidaten, ikke akkumulert stigning langs en gangrute.

| Flekk | Veiavstand | Retning mot vei | Høydeforskjell |
|---|---:|---:|---:|
| F01 | 167 m | 152° | +11 m |
| F02 | 374 m | 95° | +56 m |
| F04 | 187 m | 286° | +21 m |
| F05 | 4 m | 181° | ca. 0 m |
| F06 | 303 m | 254° | ca. −1 m |
| F17 | 510 m | 129° | +32 m |
| F18 | 155 m | 100° | +10 m |

F01 og F17 passer dermed godt med den foreløpige adkomsttolkningen. F02 peker mer østover, og nærmeste vei ved F04/F06 ligger i en annen retning. Andre veier kan fortsatt være relevante. F05 ligger faktisk omtrent fire meter fra en registrert servicevei; det er et konkret forhold som bør undersøkes i ortofoto før den rangeres høyt.

Et viktig motargument ved F01: Nørdre Eldåa er registrert som waterway=river omtrent 129 m unna, mot ca. 130°. Dette er ikke bare en antatt liten bekk. Hvis hintet virkelig betyr at det ikke finnes vann i nærheten, svekker det F01. Hvis det betyr at hun ikke ser vann, må vi undersøke sikt og vegetasjon; avstanden alene avgjør ikke. Den gjentatte lydsløyfen kan ikke brukes til å teste om elven burde vært hørbar.

4. Adkomstkriteriene bør ikke låses som harde filtre ennå

I adkomsttest_v2.py inngår track i KJORBAR selv om metodebeskrivelsen sier at traktorveier skal rapporteres separat. Jeg foreslår to eksplisitte veiscenarioer, og ingen påstand om kjørbarhet uten kontroll av veidekke, adkomst og bommer. OSM beskriver selv at highway=track ikke innebærer en bestemt access-verdi: https://wiki.openstreetmap.org/wiki/Tag:highway%3Dtrack

V4/V5 oversetter hint om vann og hytter til «ingen vannløp innen 150 m» og «ingen bygning innen 300 m». Disse tallene og kategoriene er ekstra modellantakelser. Rapporter avstander og objekttyper først, og skill sikt, nærhet og faktisk adkomst. Nærmeste registrerte vei er heller ikke nødvendigvis stedet bilen sto.

Manglende data må få status ukjent: med tomt OSM-utvalg gir skriptet inf, som automatisk består V4/V5. Veihøyde utenfor DTM blir derimot NaN og feiler V3. Begge bør rapporteres som uavklart. For vann- og bygningspolygoner må innside håndteres; avstand bare til polygonkanten er ikke korrekt hvis kandidaten ligger inne i objektet. Punktmodus bør også beholde F-ID i resultatene.

5. Robusthet, ortofoto og felles standpunkt

«Robusthet» betyr her terskeltoleranse innen den undersøkte lokale modellen, ikke geografisk sikkerhet. 1,00 betyr ikke at plasseringen er robust mot DOM-årgang, kamerakalibrering, B3-avstand eller andre utestede premisser. Skil gjerne mellom samme posisjon som består mange kombinasjoner og at forskjellige posisjoner består forskjellige kombinasjoner. Ved sammenslåtte flekker tar flekker.py maksimum av delklyngenes rob_any, ikke unionen av hvilke kombinasjoner de samlet består.

Jeg støtter ortofotokontrollen som neste observasjon, men ikke alle foreslåtte harde grenser. En åpning under 30 m er ikke sikkert målt i strømbildet, en vei innen 50 m kan være skjult, og et bilde før 2020 kan fortsatt gi historisk informasjon. Bruk forenlig / konflikt / uavklart, og begrunn konflikten konkret. Vi har allerede sett 2023-bilder ved F01- og F17-områdene, så vurderingen der kan ikke omtales som blind. DOM-årgangen er fortsatt uverifisert.

Mitt forslag er å beholde F01 som første lokale kontrollområde og F17 som et tydelig alternativ, med F02 som sammenligningspunkt. Vannhintet ved F01 og veien ved F05 fortjener direkte kontroll. Jeg støtter versjon 8 som arbeidsutkast, men vil rette de numeriske og metodiske presiseringene over før vi kaller den en ferdig felles versjon. Hovedbudskapet bør også skille den gamle sammenligningen av kandidatmarkører fra dagens prioritering av lokale flekker.

Vedlagt følger beregnede adkomstverdier for alle 25 punktene, begge numeriske kontroller, lokale treff ved F01/F02/F17, skript og dokumentasjon av hva som er kjørt. Ingen plassering er påvist.
