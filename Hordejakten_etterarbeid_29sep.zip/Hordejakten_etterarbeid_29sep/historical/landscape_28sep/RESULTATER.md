# Landskapskontroll og skifte til Grue, 28. september 2026

**Ingen kasseposisjon eller sikker bildematch er funnet.** Arbeidet ble utført ca. 18.30–19.00 CEST. Etter brukerens oppdatering prioriteres Grue kommune; Alvdal-arbeidet bevares som en etterprøvbar kontroll av teorien i GitHub-sak 16.

## Grue: grunnlaget og konsekvensen

Brukeren opplyser at Grue er riktig kommune, med to begrunnelser: forbindelsen Slottet–Linstow–Grue kirke og en annenhånds rapport om en person som skal ha nådd kassen og blitt sett i kommunen. Sistnevnte er ikke uavhengig verifisert. Ingen personidentitet eller privat reiserute brukes her.

- Nasjonalmuseet identifiserer slottsbildet som Linstows *Den vordende kongebolig*, 1826: https://www.nasjonalmuseet.no/samlingen/objekt/NAMT.hms055
- Grues kulturmiljøplan, trykt side 55, bekrefter Linstow og innvielsen av Grue kirke 28.09.1828: https://www.grue.kommune.no/getfile.php/1358187-1699351106/grue-kommune/filer/politikk-organisasjon/kulturmilj%C3%B8plan-2021-2025.pdf
- Norsk kunstnerleksikon bekrefter at Ole Peter Riis Høegh arbeidet ved Slottet under Linstow i 1824–28 og assisterte ved Grue kirke. Dette underbygger forbindelsen, men gir ingen ny posisjon innen kommunen: https://nkl.snl.no/Ole_Peter_Riis_H%C3%B8egh
- SNL oppgir Kaketjennsberget, 584 moh., som Grues høyeste fjell. **Hvis kassen er i Grue, kan 810–891 moh. ikke være et gyldig høydefilter.** Tallet kan ha annen betydning; dette er ikke løst. https://snl.no/Grue
- Originalpubliseringene av apphint og måltid er fortsatt ikke gjenfunnet. Fanoppsummeringen er https://www.tiktok.com/@hordejegeren/photo/7690572478401285398 . Gjentakelser teller ikke som uavhengige kilder.

## Hva landskapstesten faktisk gjorde

Foto: https://praktiskinfo.no/img/hordejakten/gjeldfriveg1-adressehint-27-september-2026.webp . Original dimensjon 1179×1535. Manuelle målepunkter er relative til utsnitt med øvre venstre hjørne (50,550). Opptaksdato, kameravinkel, objektiv og om fotografiet viser leirens nærområde er ukjent.

606 observatørpunkter ble testet: 602 punkter i omtrent 500 meters rutenett i Alvdal-området, med modellert terrenghøyde 450–1000 meter, og fire faste kontrollpunkter. Dette er ikke en full undersøkelse av Østerdalen eller et fullstendig kart over alle mulige kameraposisjoner.

Kartverkets terrengmodell ble hentet som fire 1000×1000 F32-eksporter og satt sammen til et 2000×2000 raster over ca. 100×100 km. Nominell bakkeoppløsning er 50 m; bilineær interpolering. Faktiske kilde-URLer ligger i `tile_sources.json` og `terrain_source.json`. Anskaffelsesår for original laserdata er ikke kontrollert. Terrengmodellen inkluderer ikke trær eller bygninger.

Horisonten beregnes fra 1,7 m over bakken, 100 m–40 km ut, med geometrisk jordkrumning og uten refraksjon. Avstandstrinn er 50 m til 3 km og 100 m videre. Rutenettet bruker 1° asimuttrinn, de fire profilfigurene 0,25°.

26 manuelt avleste horisontpunkter tilpasses med horisontalt synsfelt 35–100° i trinn på 5°, kameraretning i trinn på 1°, roll begrenset til ±1° og fri vertikal forskyvning. Projeksjonen er en forenklet pinhole-modell, ikke full kalibrering av kamera, pitch eller linseforvrengning. Flere parametre og få utydelige landemerker gir stor fare for tilfeldige likheter.

## Resultater og uavhengig vannkontroll

| Testpunkt | Retning / synsfelt | Horisontfeil | Vannkontroll |
|---|---|---|---|
| Baugsberget 62.09804, 10.58951, fri tilpasning | 195° / 55° | 3,78 px RMS | Kartlagt elv mangler i høyre bildehalvdel innen 4 km i denne retningen |
| Samme punkt, pålagt elv mot høyre | 80° / 35° | 4,20 px RMS | Modellert elvelinje bommer i snitt ca. 153 px vertikalt/horisontalt på fem vannpunkter |
| Nærliggende rutenettpunkt 62.09700, 10.58800 | 27° / 100° | 4,43 px RMS | Nærmeste elvelinje ca. 8,4 px fra de fem punktene i snitt; ikke kontrollert for skjerming eller forgrunn |

**Dette avkrefter ikke hele Baugsberget.** Det viser at den første gode horisonttilpasningen alene er utilstrekkelig, og at en annen posisjon og et vidt synsfelt gir omtrent riktig projeksjon av vann. Ingen av modellene er identifisert som fotoets opptakssted. Gressbakken, gjerdestolpen, skogens plassering og konkrete topper er ikke matchet.

Vannkontrollen bruker Glomma/Folla-senterlinjer fra OpenStreetMap, hentet 28.09.2026: https://api.openstreetmap.org/api/0.6/map?bbox=10.58,62.065,10.65,62.13 . Kartdekningen er begrenset. Vannhøyde er tilnærmet med terrengmodellen, ikke målte vannstander. Elvebredder er ikke modellert. Terreng- og vegetasjonsskjerming er ikke beregnet. Kameraet ble først optimalisert for horisonten; vannet ble så kontrollert, ikke optimalisert samtidig. Andre orienteringer kan derfor passe bedre enn de undersøkte.

`river_projection_check.png` viser både en dårlig vannplassering fra det faste toppunktet og alternative omtrentlige treff. Feilverdier er ikke sannsynligheter. Et lavt tall identifiserer ikke kassen.

## Nye Grue-spor som bør skilles fra påstander

1. **Rotna–Revtjernet/Kaktjernsberget:** UT-ruten dokumenterer en elvebro og en bomvei, 5,3 km videre til Revtjernet. Den beviser ikke kort gangavstand til leiren. https://ut.no/turforslag/115038/kaktjernsberget-584-moh
2. **Tjura–Frysjødammen:** Frysjørunden dokumenterer bru ved Klart Glass og avkjøring mot dammen lenger øst. https://ut.no/turforslag/115667
3. **Sormsbekken–Frysjøneset–Voldstadvika:** Finnvegen-beskrivelsen dokumenterer en nåværende bro over Sormsbekken, samt skogsbilvei og sti. Den gamle broa i Sormsvika er derimot oversvømt. Dette er et nytt alternativ til de to foregående broteoriene. https://ut.no/turforslag/1112154444/finnevegen-kirkenr-svullrya
4. **Lindtjernet/Vannverksrunden:** Kommunen beskriver lett kupert, åpen furuskog og parkering ved Finnskogvegen. Det er en relevant terrengtype å sammenligne, men ingen kilde knytter stedet til Horde. https://www.grue.kommune.no/kultur-informasjon/tur-friluftsliv/vannverksrunden/

Den opprinnelige offisielle TikTok-kommentaren om bro er fremdeles ikke funnet. Det er ikke avklart om påstanden gjaldt kjøring eller gange. Ingen av disse rutene er dermed en anbefalt kasseposisjon.

## Reprodusering

Python med numpy, scipy og matplotlib. Kjør `terrain.py`, `fit.py`, `water_check.py`, `river_constrained.py`, `project_river.py` i den rekkefølgen. Pakken inneholder ferdig raster, kilde-URLer, elvegeometrier, manuelle målepunkter i resultatfilene, råresultater og figurer. Kildebildet og de tredjeparts bildene er ikke pakket inn; hent originalen fra lenken for visuell kontroll. For regenerering av elveutdrag fra XML må den kilde-URLen ovenfor lastes ned som `alvdal_osm.xml`; ferdig `alvdal_rivers.json` er inkludert.

Terrengdata: Kartverket. Elvedata: © OpenStreetMap-bidragsytere, ODbL. https://www.openstreetmap.org/copyright
