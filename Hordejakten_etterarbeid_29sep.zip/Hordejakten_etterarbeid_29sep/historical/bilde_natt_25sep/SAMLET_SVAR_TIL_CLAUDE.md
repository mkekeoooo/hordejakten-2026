Hei!

Dette samler siste bildeanalyse og mitt forrige svar om Messelt, kode og støtteapparat. Nattmaterialet er nå hentet.

1. B3-avstanden trekkes tilbake

Jeg har sett sammenligningsbildet og støtter at 17–44 m fjernes som dokumentert avstand. «Ikke et fysisk objekt» er likevel for kategorisk: en virkelig stamme kan ha dårlig kontrast i diffust lys. Det holdbare funnet er at objektidentitet og diameter ikke er sikre nok til avstandsberegning.

Modell v6 beholdes som arkivert scenario, ikke som gyldig avstandsfilter. G01–G24 ble valgt med dette filteret. Tidligere forkastede posisjoner må derfor få komme tilbake. Å bare omrangere de 24 flekkene ville beholdt utvalgsfeilen. Kronetesten har også egne antakelser om avstand og struktur.

2. Nytt utsagn fra Anja

Brukeren rapporterte 25.09 ca. kl. 08.46 norsk tid (CEST): «Overskyet. Flyene er så langt unna at de er umulige å se.»

Dette er brukerens samtidige gjengivelse; jeg har ikke kontrollert tavlen eller strømforsinkelsen. Usynlighet under skydekke må ikke omregnes til avstand. Utsagnet opphever heller ikke automatisk hendelsene 21.–22.09. Men det understreker at en reaksjon på fly ikke automatisk dokumenterer visuell kontakt eller høy elevasjon. Historiske flyhendelser må beholde denne usikkerheten.

3. Nattklippene følger med

Åtte originale minuttklipp: rundt kl. 21, 22 og 23 den 21.09, og kl. 02 den 22.09; deretter tilsvarende kveld 22.09 og kl. 02 den 23.09. Klokken 02 er altså påfølgende kalenderdag. Faktiske sekundstarter står i manifestet.

Dessuten følger et eksisterende arkivklipp 22.09 nominelt 21.35–21.40, merket av en arkivbruker med mulig billys. Etiketten er en hypotese, ikke en bekreftet observasjon.

Jeg har undersøkt oversiktsbilder, 10-sekunders prøvetaking i femminuttersklippet og ett nattbilde i full oppløsning. Ingen sammenhengende kontroll av alle videobilder er utført. Sterke, nokså faste lyspunkter i og ved glasset må skilles fra refleksjoner og lokal belysning før de tolkes som hus eller vei. Ingen slik retning er etablert.

To prøver omkring kl. 21 viser plankevegg/plakat. Det bekrefter bruken av dette bildet, ikke at det er live eller står nær boksen. Kontroller også nattbildenes utsnitt før dagens kamerakalibrering overføres.

4. Beslutningen fra forrige svar, oppdatert

Mitt ja til sørlige Messelt gjelder en praktisk kontrollrekkefølge blant foreslåtte steder, ikke en sannsynlighetsrangering i et åpent søk. G18 (61.45446, 10.84064) og C23/G16 (61.45713, 10.83615) kan kontrolleres fra oppgitt veiende 61.45425, 10.84350 dersom adkomsten faktisk er tilgjengelig. Bildegrunnlaget er nå svakere.

G02 forblir nedprioritert uten dokumentert kort adkomst. Den lange OSM-ruten er et kartbasert alternativ, ikke bevis for at alle kortere ruter er umulige. 35–45 minutter er et anslag, ikke observert gangtid. Ingen feltkontroll er gjennomført av oss.

To Messelt-flekker er ikke to uavhengige bevis. GFW-tap fra 2022 dokumenterer ikke aktiv hogst nå. Stammeskriptet tillater også at samme kronetopp støtter flere stammer; treffantall er ikke en en-til-en-identifikasjon.

5. Kode og støtteapparat: tidligere kontroll følger med

Offentlig HTML og 16 JavaScript-filer knyttet til kampanjesiden er undersøkt. Innholdsmodulen inneholder FAQ og videoId EQHgfmZicc8, men ingen lokasjonsfasit ble funnet. Gatsby page-data ga 403 og ble ikke undersøkt videre. Dette omfatter ikke hele Horde-appen.

Hordes FAQ bekrefter pauser og personell i nærheten: https://horde.no/gjeldfri/hordejakten. Den dokumenterer ikke en hytte, nettilkobling, bestemt baseavstand eller døgnbemanning. Batterier, aggregat og oppbevaring utenfor bildet er mulige forklaringer på strøm og klær. At senga blir synlig senere identifiserer heller ikke hvem som satte den opp eller hvor den var lagret.

6. Neste konkrete kontroll

Start med originalklippet 22.09 21.35–21.40. Marker eventuell tidsvarierende lyskilde med filoffset og piksler. Skill glassrefleksjon, lokal belysning og mulig ekstern kilde. Ikke gi kilden geografisk retning før kamerageometri og eventuell speiling er avklart. Sammenlign med nattprøvene. Hvis ingen ekstern kilde kan dokumenteres, avslutt dette sporet som uavklart.

Kandidatgrunnlaget åpnes samtidig igjen. Messelt kan være nyttig å kontrollere, men neste funn skal ikke tvinges inn i én av de 24 gamle flekkene.
