# Lyskontroll 25.09.2026

Kilde: https://default.no/cuts/202609222135_202609222140.mp4
Offentlig arkivlenke observert på https://default.no/clips.php.
Filens metadata: 1920x1080, H.264, 30 fps, varighet 360,03 s; 10 801 dekodede bilder. Arkivnavnet er ikke en garanti for opptakstid eller uavbrutt tidslinje.

Alle bilder ble dekodet til gråtone 640x360. Fire områder (x0,y0,x1,y1) ble målt: upper=(0,30,640,190), left=(0,30,155,350), right=(480,30,640,350), box=(155,110,480,320). Områdene overlapper. Lysendring er en detektor, ikke en klassifikator av lyskildens årsak.

Per bilde: gjennomsnitt, gjennomsnittlig absolutt endring mot forrige bilde, positivt avvik over 12 gråtonetrinn fra en eksponentiell bakgrunn, og antall piksler over bakgrunnen med mer enn 20 trinn. Bakgrunn oppdatert med 0,9835*bakgrunn + 0,0165*bilde. Topper valgt minst 4 s fra hverandre, etter de første 3 s. frame_metrics.csv og peaks.json inneholder resultatene.

Visuell kontroll: kontaktark fra hele filen med 5 s mellom bilder; originalbilder ved utvalgte utslag; 10 fps-sekvenser rundt +52, +58 og +120 s. Ikke alle originalbilder ble inspisert manuelt. En svak, kort hendelse kan derfor fortsatt unnslippe identifikasjon.

Registrering: Fourier-fasekorrelasjon av øvre 260 rader ved 960x540, med Hanning-vindu, mot første bilde i hvert 1,5-sekunders vindu. Heltallspikselpresisjon. registration.json oppgir forskyvninger; dette er bildebevegelse, ikke en måling av fysisk kameraforflytning.

contact_*.jpg og events.jpg er nedskalerte kontaktark. full_*.png er originale dekodede stillbilder uten lysjustering. transient_ground_sequence.jpg er utsnitt x1350:1920,y700:1080 fra originaloppløsningen, med 0,1 s intervall. pulse*_range_x5.png er beregnede maksimum-minus-minimum-kart ganger fem og må IKKE leses som fotografier av lysstyrken. Originalfil følger med.

Ingen ny stedskoordinat, avstand eller kompassretning er utledet fra denne kontrollen.
