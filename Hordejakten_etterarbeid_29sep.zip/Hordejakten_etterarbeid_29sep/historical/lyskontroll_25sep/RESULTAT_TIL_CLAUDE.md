Hei!

Jeg har nå utført kontrollen av originalfilen cuts_202609222135_202609222140.mp4 selv.

Resultat: Ingen bekreftet bilpassering, husbelysning eller geografisk retning til støtteapparat. Klippets merkelapp «lys ... som bil» bør fortsatt ikke brukes som lokasjonshint.

Filen varer faktisk 360,03 sekunder, ikke fem minutter. Jeg dekodet alle 10 801 bilder ved 30 fps for måling, gjennomgikk kontaktark fra hele filen med fem sekunders intervall og undersøkte utslagene tettere. Jeg har ikke sett hvert originalbilde manuelt. Alle tidspunkter nedenfor er offset fra filstart, ikke kalibrert klokkeslett.

- +8,9 s: stor endring i boksområdet samtidig med at tavlen løftes. Ingen påvist ekstern kilde.
- +52,2–52,4 s: bilderegistreringen viser vertikal forskyvning på omtrent 2 piksler ved analysebredden 960, tilsvarende omtrent 4 originalpiksler.
- +58,1–58,4 s: hele den øvre, statiske scenen forskyves frem og tilbake. Utslag opptil 3 piksler vertikalt og 1 horisontalt ved 960-bredde (omtrent 6 og 2 originalpiksler). Kamera-/bildeforskyvning bidrar derfor til lysendringsmålingens største topper. Dette er ikke i seg selv et lys som passerer gjennom skogen.
- +120,4–120,6 s: en kort lysflekk oppstår på vegetasjon nederst til høyre. Den globale registreringen er stabil i denne sekvensen. Originalutsnitt og tett bildeserie følger med. Jeg kan ikke avgjøre om dette er reflektert lokal belysning eller lys fra en ekstern kilde. Det er ikke tilstrekkelig til å identifisere billys, avstand eller kilderetning. Skjermposisjonen til belyst vegetasjon er ikke retningen til lyskilden.
- De sterke lyspunktene ved glasset består over lang tid. De er ikke dokumentert som fjerne lyskilder. Glass og lokal belysning må fortsatt tas med i tolkningen.

Konsekvens: Denne kontrollen endrer ikke rangeringen mellom Messelt og A2. Den gir ikke grunnlag for å plassere en vei eller hytte langs en antatt lysretning. Behold den korte lysflekken som et uavklart fenomen, men avslutt billys-hypotesen som grunnlag for dagens rangering.

Dette erstatter oppfordringen min om at du skulle gjøre akkurat denne kontrollen. Resten av forrige samlede svar står, særlig at B3-avstandsfilteret er trukket tilbake og at de tidligere 24 flekkene ikke er et komplett kandidatgrunnlag.
