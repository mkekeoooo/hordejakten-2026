# Independently selected areas — 26 September 2026

User direction: find new areas outside default.no. This pass selected regions from ecological field surveys, not default.no candidate locations, rain reports, aircraft exclusions, road-direction interpretations or driving-time assumptions. Independence here means selection provenance, not a claim these places have never appeared on another map. No box location is confirmed.

## Source findings

The public GeoGuessr discussion points back to default.no and is not independent support. Direct Børsen interview (22 September) says Anja slept during transport, did not know its duration, and was carried during the final stage. Thus a required seven-hour journey or a literal walking-time radius is not justified by that interview. This is a source correction supporting a wider search, not a new location clue.
https://borsen.dagbladet.no/nyheter/anja-29-snakker-ut-absurd/85185489

Horde confirms nearby support personnel and a setting without dangerous terrain. These support a broad logistics hypothesis, not a fixed road distance or a specific region.
https://horde.no/gjeldfri/hordejakten

## Three new independent search regions

1. Høyfossåsen–Vestfjella fringe, Aremark. BioFokus fieldwork from 2012 describes tall, productive pine woodland with berry-heath ground and some spruce/birch. The surveyed slope is southwest-facing and relatively steep: do not equate its entire area to the box scene. This provided an ecological starting point for a separate four-kilometre map search. The resulting Buer point below lies northeast of the named hill; the survey does NOT verify its exact species or age.
https://lager.biofokus.no/biofokus-notat/biofokusnotat2012-14.pdf

2. Sannesnåsa, Drangedal. The official survey describes pine with heath/bilberry vegetation, but also sparse rocky ridges, younger forest and richer oak patches. These mixed conditions make it a regional comparison, not a scene match. The SSR hill is at 59.01628,9.28566. A 4km square around it gave no strict clearing matches and only eight grid positions in the alternative canopy test, clustered into three. Two selected positions are downhill from their nearest roads, and imagery shows extensive lake shore. Lower priority. The report's stated 220–434m range was not reconciled with the sampled terrain (57–298m); do not present the square as a verified reserve-polygon survey. Imagery catalogue at centre lists 2021-09-01, not current 2026 conditions.
https://www.statsforvalteren.no/siteassets/fm-vestfold-og-telemark/miljo-og-klima/verneomrader/dokumenter/2022/horing-april/horingsdokument-sannesnasa-naturreservat.pdf

3. Barmen–Helgevann / Knutefjell, Kongsberg. The 2025 official consultation documents tall old pine with spruce across a broad elevation range. Helgevann (59.66186,9.49468) was used as a REGION anchor, not a box candidate (it is water). Terrain/imagery were retrieved, but road queries failed twice. The source and a local walking account identify proximity to Hengsvann military training land; no usable off-trail candidate was produced. Do not send someone to a point here. Regional centre imagery catalogue lists 2020-08-12.
https://www.statsforvalteren.no/contentassets/2034e70926ce4043a3bfe91fb65ad049/horingsdokument-04032025.pdf
https://ut.no/turforslag/115084/helgevann-rundt

## New theory: do not require an aerial clearing

The camera frame shows vegetation above and close around the box. A small platform may fit beneath overlapping crowns. Requiring a 15m low-canopy patch could therefore reject plausible woodland. This is a testable alternative, not evidence that any selected site contains the box.

First pass used the previous clearing predicate: centre 3x3 of 5m cells median DOM-DTM <=4m; at least half the neighbouring 105m square >12m; road 150–900m, absolute elevation difference <=80m. Zero matches in I01 and I02.

Alternative pass removed the central clearing requirement, required at least 25% of the local square >12m, and <=8m terrain range across a 35m square. Same road bounds, no compass-direction preference or required uphill approach. Results: I01 620 grid positions (not 620 clearings), eight separated selections; I02 eight positions, three selections. These intentionally permissive filters generate inspection points, not probabilities. DOM dates unverified; values are surface-minus-terrain proxies, not field-measured tree heights.

## Concrete new Aremark test point

Aremark-C2, Buer/Vestsia: **59.24808,11.64633**, terrain about121m. Local tall-surface fraction 73%; central surface-minus-terrain median17m. Nearest mapped road Vestsia/fv1318, OSM71758095: **199m west**, road about2.6m above point. Road endpoint59.24809215,11.64284139. Straight segment crosses none of the retrieved mapped waterway/wetland boundaries. This is NOT a verified walking route, parking place, access permission, or proof of no water.

Inspected 800m imagery: substantial retained canopy near the centre, with fields, buildings and harvested areas nearby. The regional imagery metadata lists2025-07-11; mixed image tiles are possible. Road/settlement proximity weakens a remote-forest interpretation. No species, box, tree-pattern, sun or weather match has been established.

Aremark-C1,59.23326,11.63711 looked appealing at310m from a southeast track, but its straight approach crosses mapped river347356252 and bog732188383. It is not promoted. Of eight separated Aremark selections, five have mapped water intersections along the nearest-road segment; three do not. This prevents road-distance-only false positives.

## Saved evidence and next useful checks

Raw Kartverket name responses, terrain/surface grids, OSM geometries, imagery exports/metadata, scripts and candidate JSON are in this folder. Existing S03/K01/K02 ranking is unchanged. These independent habitat candidates need current canopy verification, route geometry, camera-view comparison and independent dated weather observations before comparison with the old shortlist. No GitHub post or README change made in this pass.
