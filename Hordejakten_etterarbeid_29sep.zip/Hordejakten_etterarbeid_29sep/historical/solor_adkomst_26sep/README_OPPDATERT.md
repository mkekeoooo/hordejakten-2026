# Hordejakten 2026

**Ny originalkontroll: solstjerne også 23.09 kl. 16.45 og 16.50 CEST.** Codex har kontrollert seks bilder fra to minuttklipp. Sammenligningen med 25.09 gir et nytt grunnlag for å undersøke Engerdal–sørlige Femund og Solør/Finnskog; dette er et forslag til videre analyse, ikke en avtalt stedsrangering. [Resultater og svar til Claude · #10](https://github.com/mkekeoooo/hordejakten-2026/issues/10#issuecomment-5840220953) · [Alle nye vedlegg i én ZIP](https://github.com/user-attachments/files/32671438/Hordejakten_ny_solobservasjon_23sep.zip)

**Ny avklaring 25.09: Direkte sol rundt kl. 17.00 CEST er dokumentert av både Codex og Claude.** Antakelsen om en helt overskyet ettermiddag er trukket tilbake. Satellittsammenligningen velger foreløpig ingen region, og Østerdalen er ikke utelukket. Nye østlige og sørlige områder undersøkes; det er ikke vedtatt en ny stedsrangering.

[Solobservasjon og landsøk med satellittparallakse · #10](https://github.com/mkekeoooo/hordejakten-2026/issues/10#issuecomment-5839791607) · [Norsk notat, kart, data og kode · én ZIP](https://github.com/user-attachments/files/32670755/Hordejakten_landsok_solsikt_25sep.zip)


### Rapporter, kart og åpen vurdering av sporene

Et norskspråklig analysearkiv fra arbeidet med Hordejakten. Her er rapportene og figurene samlet, med en kort vei fra hovedfunn til metode og forbehold.

**Status 26. september 2026: Ingen plassering er bekreftet.** Den gjeldende arbeidslisten for videre kontroll står rett under. Rapportens opprinnelige kandidatliste er bevart som historikk lenger ned.

## Gjeldende arbeidsliste 26.09.2026 (ikke bekreftet)

**Felles standpunkt:** A01 og L07 beholdes som undersøkelsespunkter. **Nummereringen i tabellen er Claudes foreslåtte kontrollrekkefølge; innbyrdes rangering er ikke avtalt.** Codex finner L07 sterkere på den betingede adkomsttesten og beholder også Solør-punktet 60.53938, 12.18334. [Begrunnelse og nye bilder](https://github.com/mkekeoooo/hordejakten-2026/issues/12#issuecomment-5841782649).

Arbeidet i [#10](https://github.com/mkekeoooo/hordejakten-2026/issues/10) og [#12](https://github.com/mkekeoooo/hordejakten-2026/issues/12) kombinerer satellitt, skogmodell, sol, adkomst og terreng. Modelltreffene dokumenterer ikke geografisk nøyaktighet eller en unik lysning. **Ingen av punktene er bekreftet.**

| Claudes forslag | Område | Punkt (WGS84) | Hva som støtter | Viktigste forbehold |
|---|---|---|---|---|
| 1 | **Osen / Trysil-vest (A01)** | **61.23076, 11.72394** | Forenlig med været i alle fire følsomhetsvarianter (nr. 3 av 39). Beholdt i Codex' bildekontroll med 2025-foto (skog med mindre åpninger). Består skogkravene med 2,8 m margin og morgensolen. Ca. 12 min oppover (+56 m) fra vei uten vannkryssing. Står på en slak kolle (TPI +4,7 m). | Finsøket gir mange modelltreff innen 300 m, ikke én identifisert lysning. Nærmeste vei ligger mot 317° (NV), som passer svakere med en sørøstlig tolkning av tavlepilen. Ingen detaljmatch; adkomsten er modellert. |
| 2 | Elverum/Løten (L07) | 60.82353, 11.53750 | Forenlig med været i alle varianter. Beholdt i Codex' bildekontroll. Skogkrav og morgensol. | Nærmeste spor gir 321 m/+14 m og bekk. Codex fant også servicevei 400 m mot 108°, +21 m, uten kryssing av kartlagt vannløp i luftlinjen. Gangbarhet er ikke verifisert. Mange lokale modelltreff. |
| 3 | Solør/Finnskog | 60.61433, 12.32469 · 60.53938, 12.18334 · 60.80277, 12.12363 · 60.72728, 11.92034 | Beste værscore blant 31 robuste Solør-punkter. Skogkrav og morgensol. | De tre første er nå bildekontrollert i valgt 2025-prosjekt. 60.61433, 12.32469 ligger ved en stor hogstflate og nedprioriteres av Codex som eksakt markør; 60.53938, 12.18334 beholdes. Ingen detaljmatch. |
| 4 | Østerdalen, rapportens kandidater | se historisk liste under | Ikke utelukket. Kandidat 1 består skog og morgensol. | Ingen er forenlig med været i alle følsomhetsvarianter. Messelt, Koppang og Sjusjøen svekkes av værsammenligningen. |

**Modellvurderinger med åpne forbehold** (ikke generelle regionutelukkelser; detaljer og premisser i sakene):

- **Olivin-sporet:** Åheim/Almklovdalen, Bjørkedalen og Onilsa er uforenlige med morgensol og skydekke 21.09. Grøndalsvatnet står åpent. [#11](https://github.com/mkekeoooo/hordejakten-2026/issues/11)
- **Jernvinneveien 5a/5b og det eksakte A1-/site finder-punktet:** beregnet konflikt med morgensol under modellens antakelser om hvilke flater som er belyst. [#2](https://github.com/mkekeoooo/hordejakten-2026/issues/2) · [#8](https://github.com/mkekeoooo/hordejakten-2026/issues/8)
- **Engerdal–sørlige Femund:** ingen punkter består Claudes undersøkte 50 m-rutenett med de valgte skog-, sol- og adkomstkravene. Andre åpninger og adkomster kan være oversett; regionen er ikke utelukket. [#12](https://github.com/mkekeoooo/hordejakten-2026/issues/12)
- **Vestlige daler** (Gudbrandsdalen, Valdres, Lillehammer, Fagernes): gjentatte værkonflikter mens stedet hadde sol. [#10](https://github.com/mkekeoooo/hordejakten-2026/issues/10)

«Robust» betyr her at punktet består fire valgte modellvarianter, ikke statistisk sikkerhet. Hele listen over slike punkter (39) står i [`robuste.csv`](https://github.com/mkekeoooo/hordejakten-2026/blob/bevis/claude-2026-09-25/bevis/claude-2026-09-25/engerdal/robuste.csv). Skript og mellomresultater ligger i samme mappe på bevisgrenen.

**Det som kan flytte listen:** særpregede kjennetegn fra bildet mot ortofoto, arrangørens hint i helga, og feltdokumentasjon. Høydehintet (810–891 moh) er ikke brukt. Tolket som høyde ville det utelukke alle lavlandspunktene over.

## Siste avklaringer

Claude og Codex fører den løpende gjennomgangen i [samlesak #1](https://github.com/mkekeoooo/hordejakten-2026/issues/1). Viktige avklaringer publiseres også her; uavklarte forslag blir stående i sakene.

- **Regionen må holdes åpen.** Flyhendelsen 21.09 har usikker objektidentitet og tidsforsinkelse. Claudes nye flytabell er gjenskapt av Codex, men den bekrefter ikke Evenstad som region. [Bakgrunn og data · #5](https://github.com/mkekeoooo/hordejakten-2026/issues/5)
- **Pekevinkel og værutelukkelser er rettet.** En arm nesten loddrett i bildet er ikke en måling av flyets høydevinkel. Claude har trukket tilbake den slutningen, og vi er enige om at gesten ikke alene velger eller utelukker region. De tidligere værutelukkelsene av vest og sør var modellbaserte og ikke verifisert mot observasjoner; de brukes ikke som harde grenser. [Felles avklaring · #9](https://github.com/mkekeoooo/hordejakten-2026/issues/9#issuecomment-5831319502)
- **Temperatur skal ikke være et hardt filter.** Måleforholdene er ukjente. Messelt og andre steder skal ikke forkastes alene fordi uteluftsmodellen er kaldere enn tavleverdien. Ingen bestemt temperaturkorreksjon er dokumentert. [Avklaring · #3](https://github.com/mkekeoooo/hordejakten-2026/issues/3)
- **Morgensoltesten er under kontroll.** Codex har gjenskapt terrenghorisontene på 8,4° / 7,3° / 6,6° ved de tre Jernvinneveien-markørene. Om dette utelukker et sted, avhenger også av den faktisk belyste flatens plassering og høyde. Bakke-, stamme- og kronelys må skilles. Endelig stedsvurdering er fortsatt åpen. [Beregninger og uenighet · #2](https://github.com/mkekeoooo/hordejakten-2026/issues/2)
- **Gjentatte koordinater er ikke nye bekreftelser.** Punktet 61°26′55,3″N 10°58′39,0″E samsvarer innen én meter med default.no sitt site finder-toppunkt ved A1. Samme kilde kan ligge bak flere forslag. Et sted er heller ikke dokumentert gjennomsøkt uten feltdokumentasjon. [Avklart i samlesaken](https://github.com/mkekeoooo/hordejakten-2026/issues/1#issuecomment-5830735101)
- **Veiretning og tavletekst må oppgis med premissene.** Kandidat 1s vei ligger omtrent mot 94°, og får ikke ubetinget samsvar med en tolket 130°-retning. [Veiretning · #4](https://github.com/mkekeoooo/hordejakten-2026/issues/4) · [Hele tavlesitater · #6](https://github.com/mkekeoooo/hordejakten-2026/issues/6)
- **Det eksakte A1-punktet har svak skogstøtte i rastergrunnlaget.** Både Claudes kontroll og Codex' nye test viser lave kroneverdier ved 61.4487, 10.9775. Hos Codex består ingen av 25 prøveposisjoner alle skogkravene, verken med kamera i markøren eller fem meter forskjøvet, og verken med cellebasert eller radial prøvetaking. Årgangen for de valgte DOM-pikslene er fortsatt uavklart; resultatet utelukker ikke hele A1-området. [Målinger og avgrensning · #8](https://github.com/mkekeoooo/hordejakten-2026/issues/8)

**Hva mangler?** Et etterprøvbart samsvar mellom flere særpregede detaljer i bildene og ett faktisk sted. Modelltreff og enighet mellom AI-analyser er ikke nok.

**Nytt, uprøvd spor: olivenolje → olivin.** Brukerens ordspillforslag gir Åheim/Almklovdalen som et nytt undersøkelsesområde, med dokumentert olivindrift og olivinfuruskog. Koblingen fra appvaren til mineralet er ikke bekreftet, og området er ikke rangert foran de andre. Den nye landsdekkende sol- og værkontrollen ga heller ingen sikker region. [Les funn, kilder og forbehold](https://github.com/mkekeoooo/hordejakten-2026/issues/1#issuecomment-5831785445) · [Samlet dokumentasjon · én ZIP](https://github.com/user-attachments/files/32650613/Hordejakten_landsok_sol_appspor_25sep.zip).

[Ny kontrollpakke · én ZIP](https://github.com/user-attachments/files/32648877/Hordejakten_kontroll_25sep.zip) inneholder Codex' skript, resultater, rasterutsnitt, flyspor og den eldre modell v6. Pakken dokumenterer også at de undersøkte hintvideobildene passer med zoom/utsnitt og ikke gir en påvist stereobaseline for treavstander. [Les forskningssvaret](https://github.com/mkekeoooo/hordejakten-2026/issues/1#issuecomment-5831094440).

**[Les fullstendig rapport · 22 sider](rapport/Hordejakten_2026_fullstendig_rapport.pdf)** · **[Les kortversjonen · 12 sider](rapport/Hordejakten_2026_kortrapport.pdf)** · **[Se alle figurer](figurer/README.md)**

![Oversikt over kandidatene og modellert temperatur](figurer/oversikt_temp.png)

## Historisk kandidatliste fra rapporten

Den opprinnelige analysen undersøkte utvalgte områder rundt Evenstad i Østerdalen og kombinerte bilder, terreng, skog, adkomst, sol og vær. Tabellen viser hva rapporten foreslo da den ble skrevet. Begrunnelsene er historiske og må leses sammen med rettelsene over.

| Rapport-ID | Område | Omtrentlig kandidatpunkt (WGS84) | Opprinnelig begrunnelse | Viktigste forbehold |
|---|---|---|---|---|
| 1 | Myklebysæterveien vest | 61.3995, 11.0316 | Samsvar med de valgte modellkravene og flere naboposisjoner | Avhenger av skog-, sol- og temperaturantakelsene |
| 2 | Madsskardveien, traktorvei | 61.4443, 11.1234 | Adkomstretning og samsvar med modellkravene | Få lokale treff |
| 3 | Sørlige Messelt | 61.4571, 10.8362 og 61.4545, 10.8406 | Adkomst og betinget støtte fra høydehintet | Værmodellen er kaldere enn den oppgitte temperaturen |
| 4 | Madsskardveien øst | 61.4518, 11.1428 | Samsvar med modellkravene | Veien kommer fra sør; kartlagt bekk i nærheten |
| 5 | Jernvinneveien | 61.4351, 11.1435 | Mange modelltreff og temperatursamsvar | Kort avstand til vei og bekk |

Ingen ny nummerert rangering er vedtatt. Birkebeinerveien, Gålaveien, Messelt og punkt 7 inngår fortsatt i den dokumenterte undersøkelsen med ulike åpne spørsmål; listen avgrenser ikke hvor kassen kan være. Den opprinnelige samlemodellen er ikke gjenskapt i sin helhet i den løpende revisjonen.

## Fire ting som må følge konklusjonen

1. **Morgensolens geometri er ikke ferdig avklart.** Rapportens klokkeslett 07.51 kom fra default.no. Claude har senere analysert default.no sine minuttklipp og foreslått krone- og stammelys tidligere enn dette; koblingen mellom disse flatene og terrengmodellen gjennomgås i #2. Bakke, krone, stamme og refleks gir forskjellige premisser.
2. **Temperaturens målepunkt er ukjent.** Modellen gjelder uteluft. Temperatur inne i kassen kan ikke uten videre sammenlignes med den.
3. **Skogmodellen er historisk og forenklet.** DOM-årgangen er ikke verifisert. DOM minus DTM er en overflatehøyde og beskriver ikke sikkert stammer, treslag eller fri sikt under kronene.
4. **Søket dekker utvalgte områder.** Et godt modelltreff innenfor disse områdene bekrefter ikke at riktig region er valgt. Flere tester bruker samme data og er ikke uavhengige bevis.

Se [presiseringer og publiseringsstatus](PRESISERINGER.md) for kjente begrensninger og formuleringer som må leses med varsomhet.

## Bildet som skal sammenlignes

![Registrerte kjennetegn i morgenbildet fra sendingen](figurer/fig_kjennetegn_1045.png)

Figuren samler synlige kjennetegn. Den tidligere avstanden på 17–44 meter til det antatte stubbeobjektet ved B3 er trukket tilbake. Et faktisk samsvar mellom stedet og flere identifiserbare detaljer i bildet mangler fortsatt.

## Slik finner du fram

| Innhold | Hva du finner |
|---|---|
| [Fullstendig rapport](rapport/Hordejakten_2026_fullstendig_rapport.pdf) | Hint, fly, vær, sol, kamerageometri, terreng, skog, adkomst, rettelser og feltkart |
| [Kortversjon](rapport/Hordejakten_2026_kortrapport.pdf) | Hovedfunn, sammenligning og kontrollrekkefølge |
| [Figurgalleri](figurer/README.md) | Alle 15 figurer med forklaring og status |
| [Presiseringer](PRESISERINGER.md) | Usikkerhet, interne avvik og hva som faktisk er publisert |
| [Kilder og rettigheter](KILDER.md) | Opphav, datakilder og videre bruk |
| [Bidra med observasjoner](CONTRIBUTING.md) | Hvordan dokumentere et nytt funn slik at det kan kontrolleres |

Rapporter og figurer er bevart uendret fra opplastingspakken. PDF-enes henvisninger til komplette arbeidsarkiver gjelder separate pakker. Nye råspor og skript for revisjonen ligger foreløpig på [Claudes separate bevisgren](https://github.com/mkekeoooo/hordejakten-2026/tree/bevis/claude-2026-09-25/bevis/claude-2026-09-25); dette er ikke en komplett reproduksjon av den opprinnelige rapporten.

## Nye observasjoner

Bruk [Issues](https://github.com/mkekeoooo/hordejakten-2026/issues) til dokumenterte rettelser eller nye observasjoner. Ta med kilde, dato, klokkeslett, tidssone og hva observasjonen faktisk viser. Oppgi tydelig hva som er tolkning.

Kartlinjer er ikke verifiserte gangruter, og veipunkter er ikke bekreftede parkeringsplasser. Følg arrangørens regler og respekter terreng, bommer og mannskap.

## 🐈 Forker du? Ta med katten.

![Inspektør Pus – avdeling for ubekreftede spor](etterforskningskatten.svg)

Dette er **Inspektør Pus**, vår uoffisielle etterforsker. Han har undersøkt alle pappeskene og nekter å kommentere funnene.

**Repoets eneste katteskikk:** Lager du en fork, la Pus bli med i README-en. Du kan endre teoriene, flytte kartnålene og være uenig med oss. Katten ber bare om å få beholde jobben.

*En frivillig tradisjon, ikke et lisenskrav. Pus godkjenner snacks, ikke konklusjoner.*

Vil du ta ham med til et annet prosjekt? Kopier SVG-filen og denne linjen til README-en:

```markdown
![Inspektør Pus – avdeling for ubekreftede spor](etterforskningskatten.svg)
```

---

Uavhengig analysearbeid med AI-assistanse fra Claude og Codex, samlet av repositoriets eier. Ingen tilknytning til Horde. Takk til default.no og bidragsyterne til de åpne datakildene.

