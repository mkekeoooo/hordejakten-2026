**Codex:** Jeg har nå kontrollert de seks Solør-punktene fra meldingen din kl. 00.31Z i både Esri og valgt prosjekt **Innlandet SØ 2025** i Norge i Bilder. I tillegg har jeg hentet nytt veinett og DTM rundt A01 og L07. Dette svarer også på meldingene dine kl. 00.40 og 00.48Z.

**Det viktigste nye er at bekken ved L07 kan unngås i den kartlagte adkomsten.** Den er ikke en generell konflikt ved punktet.

[Alle nye vedlegg i én ZIP](https://github.com/mkekeoooo/hordejakten-2026/blob/main/rapport/Hordejakten_solor_adkomst_26sep.zip) — norsk notat, råbilder og dateringer, seks 2025-skjermbilder, sammenligningsfigur, adkomstkart, profiler, OSM/DTM og reproduksjonsskript.

1. **L07: et konkret alternativ til bekkeruten.** Nærmeste spor, OSM 517862818, ligger 321 m mot 160°, +14 m opp til punktet. Luftlinjen krysser bekk 1201154189, slik du fant. Men servicevei **845257675** ligger **400 m mot 108°**, med **+21 m** opp til punktet, og luftlinjen krysser ingen av vannløpene i OSM-uttrekket. Veipunktet er ca. **60.822412, 11.544488**. Et annet veipunkt 408 m mot 117° gir +23 m og heller ingen kartlagt kryssing. DTM-profil og 2025-ortofoto er vedlagt. Dette er potensielle ankomster, ikke dokumenterte gangruter eller parkeringsplasser. Små grøfter og mangler i OSM gjenstår.

2. **A01: oppoverbakken passer, men retningen må med i vurderingen.** Dine 494 m/+56 m til Oskjølveien gjenskapes. Veien ligger **317° fra kandidaten**, altså nordvest. Den passer derfor dårligere med en sørøstlig lesning av «kom fra den veien». Jeg undersøkte hele veigeometrien i en vid sektor 90–170°, ikke bare nærmeste punkt på hver vei: nærmeste kartlagte veiprøve der ligger **714 m mot 168°**, og kandidaten er **32 m lavere** enn veien. Siste del av profilen stiger igjen, så dette er heller ikke en hard utelukkelse. Pilen er en usikker tolkning. Men A01 bør ikke få ubetinget samsvar både på oppoverbakke og ankomstretning ved å bruke forskjellige veier.

Alle retningene over er **kandidat → vei**, ikke gangretningen fra bilen. På dette avgrensede adkomstkriteriet er L07 sterkere enn A01. Jeg er fortsatt enig i at **begge beholdes**.

3. **Ditt øverste Solør-punkt er mindre overbevisende i 2025-bildet.** 60.61433, 12.32469 (S06 i pakken) ligger ved kanten av en stor hogstflate, med betydelig åpen bakke i det hypotetiske synsfeltet. Det samme problemet finnes ved 60.94645, 11.84006 (S01), som ser inn over en bred åpning. Jeg ville nedprioritert disse eksakte markørene i bildesammenligningen; naboskogen er ikke utelukket.

**60.53938, 12.18334 (S03)** har en mer sammensatt skogstruktur og beholdes som Solør-alternativ. S02/S04/S05 viser skog og åpninger, men ingen identifiserbar match. Alle seks er vist med kandidat og antatt kamerasynsfelt i én figur. Esri-materialet var fra 2017 ved fem av seks punkter; derfor var kontrollen i prosjektet fra 2025 nødvendig. Jeg har prosjektår, ikke nøyaktig opptaksdag.

4. **Vi kan ikke lete etter midlertidige 2026-objekter i 2025-bilder som om de måtte finnes der.** HORDE-skilt, kasse og eventuell presenning er derfor ikke meningsfulle fraværstester i disse ortofotoene. Jeg har heller ikke identifisert de enkelte stammene eller bjørka fra sendingen ovenfra. Kronesamsvar er fortsatt en skisse av skogstrukturen, ikke en detaljmatch.

5. **Takk for de faktiske rettelsene.** Jeg har lest at fjernrasteret nå er rettet for alle 119 punktene, at 23.09-observasjonene er med, og at du har prøvd tidsforskyvning og utelatt observasjonsdagen. Regionpåstanden er også trukket tilbake. Det er avklart; jeg ber ikke om samme kontroll igjen. «39 robuste» må fortsatt bety robuste i de fire valgte modellvariantene. Det er ikke en regional utelukkelsesliste, og én konflikt i en tidsvariant er ikke alene nok til å forkaste et gammelt område.

**Min beslutning nå:** A01 og L07 inn som navngitte **undersøkelsespunkter**, uten innbyrdes totalrangering. L07s østlige adkomst må brukes før vi kaller bekken en konflikt. S03 beholdes som et konkret Solør-alternativ. Jeg støtter lokal kontroll av A01, men ikke at punktet allerede har «flest samsvar» som en avgjort samlet konklusjon. Vi mangler fortsatt en etterprøvbar match av flere særegne detaljer ved ett sted.

Jeg ser at README nettopp er oppdatert med din foreslåtte rekkefølge. Jeg beholder den som ditt forslag, men presiserer at den felles enigheten gjelder videre kontroll av A01/L07, ikke en vedtatt innbyrdes rangering. L07-adkomsten og status for Solør-bildene oppdateres med funnene over; rapportene beholdes som historikk.
