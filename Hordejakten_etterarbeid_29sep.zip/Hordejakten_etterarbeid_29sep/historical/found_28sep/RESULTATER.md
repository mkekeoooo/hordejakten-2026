# Hordejakten — 28 September 2026 source investigation

**Later update:** user stopped work around 19:13 CEST. See `../ARBEIDSSTATUS_28sep.md`, `../grue_28sep/RESULTATER.md` and `../landscape_28sep/RESULTATER.md` for the later completed work. Three GitHub comments and two evidence archives were published; the earlier statements below that no GitHub changes or new horizon tests had been made are historical. Latest published update: https://github.com/mkekeoooo/hordejakten-2026/issues/16#issuecomment-5874912922 . README correction was drafted but NOT committed before the stop request. No confirmed camp location.

The box has NOT been located by this investigation. This pass concentrated on actual visits, new public posts, and the reported bridge clue, outside default.no's candidate rankings. No new exact coordinate is presented as a find.

## What is established

- Horde has published footage of unsuccessful visits. The official 27 September repeat-visit post says the visitor is back and asks whether others will let him try a third time: https://www.tiktok.com/@horde.app/video/7690243173238557974 and https://www.facebook.com/reel/969480552138337/ . The earlier official visit post is https://www.tiktok.com/@horde.app/video/7689808350464232726 . This verifies visits; it does not reveal the location or prove any named location in the comments.
- The 28 September camp post shows the reverse side of the box and a rough wooden structure/tarpaulin: https://www.tiktok.com/@horde.app/video/7690561522933812502 . The interpretation as a permanent hut or outhouse is NOT established. Several public commenters say the structure is a camera/privacy screen. Their comments are not official confirmation either. Do not use a permanent cabin as a required map feature.
- The National Museum catalogue confirms the drawing *Den vordende kongebolig*, Hans D.F. Linstow, 1826, inventory NAMT.hms055, with Oslo as motif location: https://www.nasjonalmuseet.no/samlingen/objekt/NAMT.hms055 . This is a palace drawing; the catalogue does not establish any hunt location.
- Grue municipality's cultural heritage plan, printed page 55 (PDF page 54), identifies Linstow as architect of Grue church as well as the palace, and gives the church's consecration as 28 September 1828. Grue Finnskog church on the next page has a different architectural history. Do not conflate the two churches. https://www.grue.kommune.no/getfile.php/1358187-1699351106/grue-kommune/filer/politikk-organisasjon/kulturmilj%C3%B8plan-2021-2025.pdf
- Motti and pork have a documented Finnskogen cultural connection; for example, Norsk Skogfinsk Museum lists the dish at its Svullrya event: https://skogfinskmuseum.no/runoja--festkonsert-med-kork-og-sinikka-langeland-ensemble . This is a regional association, not proof of where a meal was prepared or eaten.

## New reported clues — original Horde publication still missing

A public five-slide recap dated 28 September from fan account @hordejegeren reports two new hints: a shake-the-phone app hint showing the Linstow palace drawing, and Anja being served flesk og motti with lingonberry jam. All five slides were read visually. Source: https://www.tiktok.com/@hordejegeren/photo/7690572478401285398 . The account is not Horde; the post is labelled as a paid partnership and itself says nothing is confirmed. Its food-date text contains a corrected/acknowledged date ambiguity.

The catalogue facts and regional food connection were independently checked, but the original app display and original meal post were not recovered. The combined **Grue/Finnskogen hypothesis is a useful new branch**, not a confirmed location. Linstow designed numerous churches, and food can travel. The fact that the church's anniversary falls on 28 September is interesting but does not prove intentional clue design.

## Bridge claim: still unverified

User's source chain: a streamer reportedly said that an official account commented on TikTok that they crossed a bridge. The streamer, specific post, parent question, original wording, and meaning of "they" are not known. It is therefore not established whether this refers to driving, walking, Anja's arrival, staff access, or a visitor's route.

Read hundreds of loaded public top-level comments across the official posts below, with selected relevant reply threads expanded. This is not an exhaustive audit of every nested reply or every Horde post. No original official bridge statement was found in the material actually read. Absence from this sample is not evidence that the comment does not exist.

Particularly relevant checks:

- Weekend post 7689746828358733078: expanded the three replies beneath the question about the river. All three replies were from viewers, with guesses about the river, not Horde. Saved as `river_comments.txt`.
- Launch post 7687857958859934998: expanded all 13 replies under Alf Gunnar's invitation to ask for hints. The answers read were jokes/general comments; no bridge statement. Saved as `alf_gunnar_launch_replies.txt`.
- Sponsored @iriseyf episode 4, https://www.tiktok.com/@iriseyf/video/7689024369271573782 : read loaded comments and Horde's own comment/reply thread. Horde's comment praised the introduction; it did not locate the camp.
- TikTok search for `hordejakten bro` returned generic hunt videos and then required login for additional results. No login or bypass was attempted.
- Pinned official rules carousel, https://www.tiktok.com/@horde.app/photo/7689497058390134038 : all 11 cards read. It says the box is not in dangerous terrain and gives general hunt rules. It does not supply a bridge route or establish the alleged public-road-only statement.

Public TikTok posts checked during this pass (not every nested reply):

| ID | Caption / context |
|---|---|
| 7690597319443778818 | Ikke bare en måte å vinne på — newest Alf promotion |
| 7690561522933812502 | Hør hvor begeistret hun er — 28 Sep camp view |
| 7690243173238557974 | Skal dere la han prøve en tredje gang — repeat visit |
| 7690177071372438806 | På tide å få ræven i gir |
| 7689935616724847894 | En mann dere kan ta mye lærdom av — retrospective interview, not established as today's finder |
| 7689808350464232726 | Din tur — unsuccessful visitor |
| 7689746828358733078 | Lykke til alle som er ute og leter denne helgen |
| 7689069277462285590 | Sesam, sesam, lukk deg opp |
| 7688850851397471510 | Ingen har funnet Anja enda |
| 7688721776800501014 | Kjenner jeg dere riktig så vil dere overanalysere |
| 7688455485011365142 | Hun er modig — loaded comments and complete travel-time reply thread; no official bridge statement |
| 7688328990272097558 | Finneren er vinneren |
| 7687857958859934998 | JAKTEN ER I GANG |
| 7686569838986169622 | Countdown has started — 17 September, no route question in loaded top-level comments |

Use https://www.tiktok.com/@horde.app/video/ followed by each ID.

The fan recap's drawing, app-hint description, and food slides were archived as `fan_recap_source_1.png`, `fan_recap_source_2.png`, and `fan_recap_source_4.png`. Their source URLs are in `new_clue_source_urls.json`. These are screenshots of the fan's claims, not independent screenshots of the original Horde app.

## Public chat claims and two real bridge routes

YouTube chat claimed the finder had written a TikTok comment about meeting people in Grue. The alleged first-person comment was not recovered. Other viewers named Finnskogvegen, Furubergsvegen, Kaktjernsberget/Revtjernet and Grue generally. These are crowd claims, not separate confirmations. The visible chat buffer is archived in `youtube_location_claims_1756.txt`; the filename is an approximate observation label, not a calibrated event timestamp.

Skiben's public Twitch chat suggested Frysjøen's outlet toward Tjura, Helgen bru, and Kirkesjøå bru. A later message proposed a red cabin near a bridge. Those are viewer proposals, not proof of the bridge claim or the camp. Saved visible buffer: `stream_bridge_claims.txt`; individual message timestamps were not calibrated. Stream: https://www.twitch.tv/skiben . The recap linked in the stream title was checked and turned out to concern the earlier Skibathon, not this hunt.

Two suggested approaches have independently documented bridges:

1. **Rotna → Kaktjernsberget/Revtjernet:** a private contributor's UT.no route says to drive Namnå–Rotnaveien, cross the river bridge, then take the second road left. It describes a gated forest road and 5.3 km from the gate to Revtjernet, with substantial climbing. This verifies a bridge on a possible approach, not a short final walk or a Horde connection. https://ut.no/turforslag/115038/kaktjernsberget-584-moh
2. **Tjura → Frysjøen:** the published Frysjørunden route identifies a bridge by Klart Glass in Tjura and an access turn to Frysjødammen roughly one kilometre farther east. This verifies local geography, not that Horde crossed that bridge. https://ut.no/turforslag/115667

Both are compatible with the vague existence of a bridge. Neither should be promoted to a camp pin without the original quote or a recognizable scene match. No visit to either location has been performed by this investigation.

## Original recorded lives reviewed

- 28 September recording, 8m24s, local `C:/Users/hildo/Downloads/tiktok_2026-09-28_1501_1511.mp4`: contact sheets visually reviewed and Norwegian speech transcribed locally. The recording is a Mental Helse interview; no usable new geographic clue was identified. `today_source.json` records the source and SHA256. `today_auto_transcript.jsonl` is automatic transcription, not a verified quotation.
- 27 September recording, about 26 minutes, local `C:/Users/hildo/Downloads/tiktok_2026-09-27_1844_1910.mp4`: complete local automatic transcript in `yesterday_auto_transcript.jsonl`. Potentially useful passages include last driving segment on gravel (~276–290s), uneven mossy/rocky ground without a path (~311–337s), no water seen/heard (~400–421s), limited sky view between high trees (~250–275s), and visitor not being permitted to tell Anja the location (~1450–1472s). ASR has errors; verify the audio before treating the exact wording as fact. No bridge phrase was identified.

## Corrections carried forward

- Sæsetvegen updated U3 from 27 September is downgraded because an existing negative field report is approximately 140 m away. Do not keep recommending it unchanged.
- The gjeldfriveg1 landscape remains unidentified. Google Lens gave no exact match. Baugsberget/Alvdal remains a crowd theory, not an image match; this pass did not calculate a new terrain horizon.
- A hand pointing upward is not a calibrated aircraft elevation. The prior high-elevation aircraft filters remain conditional.
- The 891 m result does not explicitly say elevation above sea level. Do not force a height mask without establishing what the number describes.
- Original public-road-only context remains unverified. General safe-terrain rules do not prove road ownership or forbid every forest-road approach.
- GitHub issue 16 was read, including its request for a Baugsberget horizon comparison; it has no comments at this check. No GitHub comment, post, upload, or README mutation was made this pass. https://github.com/mkekeoooo/hordejakten-2026/issues/16

## Most useful unresolved work

Recover the original bridge reply with its parent question and author link; recover Horde's actual 28 September app/meal hints; obtain a first-person, voluntarily published route clue from a finder. Current material supports continued Grue/Finnskogen investigation, but does not support claiming to have found Anja or sending someone to one precise clearing.
