# Nye steder etter bredt søk – 26. september 2026

**Nytt hovedspor: Dahlsvegen, nord for S03.** Ingen plassering eller detaljmatch er bekreftet. Dette er forslag til ekstra undersøkelser, ikke en avtalt omrangering av S03.

## To nye konkrete undersøkelsespunkter

| Punkt | Koordinater | Adkomstmodell | Regnserie, 3 × 3 celler |
|---|---|---|---|
| **K01 Dahlsvegen** | **60.60356, 12.14124** | Ca. 220 m fra vei i retning 130° fra punktet, punktet 18 m høyere; ingen kryssing av kartlagte vannlinjer langs akkurat denne rette linjen | 10/11 regn og 3/6 opphold |
| **K02 ved Burmavegen / Øvre Malibergsvegen** | **60.59997, 12.17279** | Ca. 648 m fra nærmeste vei i retning 173°, +25 m; denne rette linjen krysser en kartlagt bekk | 11/11 regn og 3/6 opphold |

K01 er ca. 7,5 km fra S03, og de to nye punktene ligger omtrent 1,8 km fra hverandre. Avstander er avrundede; de er ikke to uavhengige værbekreftelser. K01 har en mer anvendelig adkomsthypotese enn K02. Ved K01 krysser en annen nærliggende adkomstlinje Lauksjøåa; det er derfor viktig å vise den faktisk testede veiposisjonen og ikke bare si «nær vei».

K01s testede veipunkt: **60.6022948, 12.1443229**, OSM way 323062959 (Dahlsvegen). K02s nærmeste veipunkt: **60.5941941, 12.1742278**, way 392095303 (Burmavegen i OSM). Navnene i Kartverkets stedsnavnregister og OSM er ikke alltid identiske. Dette er kartpunkter, ikke verifiserte parkeringsplasser eller ferdige gangruter.

K02 har også en mulig tilnærming fra sørvest: omtrent 697 m, retning 240°, +72 m, uten kartlagt vannkryssing langs luftlinjen. Den er brattere og passer dårligere med den usikre pilretningen. Ingen adkomst er kontrollert i felt.

**Sol mot terreng:** DTM kontrollert til omtrent 10 km i solretningen. Kl. 07.51 CEST 23.09 er sola ca. 5,8° over horisonten; beregnet terrenghorisont er 3,3° ved K01 og 3,7° ved K02. Også 23.09 kl. 16.45 og 25.09 kl. 17.00 ligger sola over den undersøkte terrenghorisonten. Dette viser geometrisk mulighet, ikke faktisk sol, og inkluderer ikke skygge fra trær eller skyer.

**Bildekontroll:** Begge punkter er sett i Norge i bilder med Innlandet SØ 2025, prosjekt 4916. Områdene har sammensatt skogstruktur og hogst/regrowth i nærheten. Jeg har ikke identifisert kassens konkrete lysning, bjørk eller stammer. «Åpning» i genereringen betyr et lavere DOM-minus-DTM-felt omgitt av høyere flater; det er ikke en verifisert lysning på bakken. K01 og K02 er beholdt for videre detaljkontroll, ikke erklært bildematch.

## Hvordan de ble funnet

Jeg begynte uten den gamle kandidatlisten: en systematisk femkilometers prøverute i rektangelet 58–63,5 N / 4–13 Ø. 6 492 prøvepunkter hadde gyldig radar ved alle 17 valgte rapporttidene etter maskering av manglende data, blokkering og ground clutter. Rutenettet dekker også sjø og deler av Sverige; dette er ikke 6 492 norske skogsteder, og land uten radardekning eller mellom rutenettpunktene er ikke utelukket.

Første rangering brukte én radarcelle per rutenettpunkt, +/-5 min og medianen av balansert samsvar ved tersklene 0,05/0,1/0,2 mm/t. Punkter minst 20 km fra hverandre ble valgt til geografiske kontroller. Deretter hentet jeg faktiske 5 × 5-uttrekk for fem utvalgte nye områder og beregnet sammenligningen med samme 3 × 3 / 0,1 mm/t som i forrige svar. De grove og detaljerte tallene skal ikke blandes.

Sterkeste grove punkt var W01, **60.58674, 12.16314**, nær Knapptjernsvegen/Kontenus i Åsnes. Ved detaljkontrollen passer 11/11 regnreferater og 4/6 opphold. Det ligger omtrent 5,4 km nord for S03. Det eksakte punktet har mye regrowth og en navngitt fritidsbolig omtrent 145 m unna, så jeg brukte det som værmessig utgangspunkt, ikke som ferdig kandidat.

En test i en 2 km-boks rundt W01 fant ingen treff på de valgte kriteriene for lav flekk, tilstrekkelig høye naboflater og oppoveradkomst 200–700 m fra vei. Med uendrede kriterier i en 3,8 km-boks kom 13 rutenettposisjoner fram, som ble gruppert romlig. K01 og K02 er to slike grupper. Begge fikk egen ny radar-, vei-, vann-, terreng- og bildekontroll. Det er ikke snakk om 13 separate lysninger. Overflatedataenes lokale opptaksår er ikke kontrollert; nyere ortofoto er derfor brukt som separat visuell kontroll.

## Andre nye områder faktisk prøvd

- **Nærosen/Nærosvegen, Ringsaker – 60.99821, 10.73316.** Detaljradar 5/11 regn og 5/6 opphold. 2025-bildet viser betydelig ungskog i tidligere hogstflate ved markøren; nærmeste vei omtrent 112 m. Det eksakte punktet er svakere enn grove radarresultater antydet.
- **Midtbulivegen, Østre Toten – 60.50793, 10.89077.** Detaljradar 5/11 og 4/6. Innlandet SV 2024, prosjekt 4564, viser skog og en innsjø med vei langs bredden. Nærmeste vei ca. 219 m og 65 m lavere. Mulig skogområde, men svakere værserie og bratt tilnærming. To genererte nabopunkter krever også store høydeøkninger; ingen løftes foran Solør.
- **Svartåvegen/Østkjølvegen, Ringebu – 61.69278, 9.97042.** Detaljradar 4/11 og 6/6. Bakken ved punktet ligger lavere enn de undersøkte nærmeste veiene. Lokal terrenghorisont ca. 8,4° mot solhøyde 4,6° kl. 07.51 23.09: konflikt for direkte lys på lavt plasserte flater på dette punktet. Ikke en utelukkelse av høye trekroner eller hele Ringebu.
- **Stangvollvegen, Hamar – 61.09933, 11.09197.** Detaljradar 4/11 og 6/6. Oppfølging av vei mangler etter tidsavbrudd fra Overpass; ikke rangert som kontrollert adkomst.
- **W02 – 60.73496, 10.95315.** Grov radar traff relativt godt, men kartet viser jordbrukslandskap på Helgøya. Ikke beholdt som skogkandidat. **W06 – 59.72055, 5.43764** har høyde 0 og er heller ikke en ferdig landkandidat.

## Nye teorier vurdert

1. **Regn først, skog etterpå:** Søk uten fly-, region- eller gamle kandidatpriorer kan finne steder vi ellers ikke ville undersøkt. Det ga både de vestlige kontrollene og det nye Dahlsvegen-sporet. Rangeringen er en utforskende tilpasning; samme regnreferater brukes til utvalg og vurdering.
2. **Motsatt adkomstretning:** En eldre skiltforklaring hos Pladsen peker mot ankomst fra nordvest. Samme side har en senere «KOM FRA DEN VEIEN»-forklaring som snur dette. Jeg fant ikke nytt originalbevis for å snu hele søket. Alternative veier er derfor undersøkt uten å gjøre én pilretning til hard grense.

## Felles usikkerhet og neste skritt

Regntidene er fortsatt referater fra default.no, ikke kontrollert originalopptak. Begge nye punkter bommer på halvparten av oppholdsreferatene. Ingen kalibrert sannsynlighet eller geografisk presisjon følger av poengene. Jeg har lest Claudes svar 13.13Z: hans separat implementerte regionsøk finner samme Solør-belte. Vi bruker samme MET-data og samme referater, så dette er reproduksjon og en ny kombinasjon med terreng/skog, ikke uavhengige observasjoner.

K01 er det nye punktet jeg ville prioritert til en uavhengig kontroll av bilder, skogdata og den eksakte adkomstlinjen. K02 er et alternativ med tydelig bekkeinnvending. Behold S03 som etablert første kontrollprioritet inntil sammenligningen er gjort.

Kilder og råuttrekk følger med: MET OPeNDAP, Kartverket DTM/DOM, kommuneinfo og Sentralt stedsnavnsregister, Norge i bilder, OpenStreetMap og Esri World Imagery. Esri-bildene har varierende eldre opptaksår og er bare innledende oversikter. Se JSON-filer for eksakte URL-er og resultater. NIB-visningene er lagret separat med prosjektår i filnavnet; prosjektets oppgitte fotodato er ikke nødvendigvis eksakt opptaksdato for hver piksel.
