**Codex: to nye punkter nord for S03 – Dahlsvegen og Burmavegen – pluss faktiske kontroller i Ringsaker, Toten og Ringebu.**

Jeg leste ditt svar 13.13Z etter å ha kjørt et separat grovsøk i **58–63,5 N / 4–13 Ø**, uten gammel kandidatliste. Femkilometers prøverute, 6 492 punkter med gyldige data ved de 17 tidene; også sjø og Sverige inngår før geografisk kontroll. Beste grove punkt havnet ved **60.58674, 12.16314**, ca. 5,4 km nord for S03. Eget 3×3-uttrekk der gir **11/11 regn og 4/6 opphold**. Dette støtter utvidelse nordover, ikke en meterpresis markør.

Jeg gikk videre fra radarcellen til skog, veier og nyere bilder. Disse to nye undersøkelsespunktene er nå kontrollert:

| Punkt | Koordinater | Adkomst fra vei | Regn / opphold |
|---|---|---|---|
| **K01 Dahlsvegen** | **60.60356, 12.14124** | **220 m, vei mot 130°, +18 m**, ingen kartlagt vannkryssing langs akkurat denne luftlinjen | **10/11 · 3/6** |
| **K02 Burmavegen / Øvre Malibergsvegen** | **60.59997, 12.17279** | 648 m, vei mot 173°, +25 m; **krysser kartlagt bekk** | **11/11 · 3/6** |

K01s konkrete veipunkt er **60.6022948, 12.1443229**, OSM way 323062959. En annen vei 296 m unna gir en linje som krysser Lauksjøåa; derfor må den nøyaktige tilnærmingen følge med vurderingen. K02 har en alternativ sørvestlig linje 697 m/+72 m uten kartlagt vannkryssing, men den er brattere og svakere mot pilhypotesen. Dette er ikke feltkontrollerte ruter.

**Sol/skog:** Ved 23.09 kl. 07.51 er solhøyden ca. 5,8°. Terrenghorisont undersøkt til 10 km: K01 ca. 3,3°, K02 ca. 3,7°. Også 23.09 kl. 16.45 og 25.09 kl. 17.00 er terrenget forenlig med sol. Trær og skyer er ikke med i denne testen. Begge punkter er sett i **Innlandet SØ 2025, prosjekt 4916**. Ingen unik lysning eller detaljmatch er identifisert. Punktene ble generert som lave DOM-minus-DTM-flekker med høyere naboflater og oppoveradkomst; 13 rutenettposisjoner er ikke 13 dokumenterte lysninger.

**Konflikter beholdt:** K01 og K02 har radarnedbør ved de rapporterte oppholdene **09.10, 10.34 og 11.20**. K01 ligger dessuten under terskelen ved 10.47. Jeg løfter derfor ikke dem over S03 bare på antallet regntreff. K01 er mitt første *nye* punkt til uavhengig kontroll.

**Nye geografiske kontroller:**
- Nærosen/Ringsaker **60.99821, 10.73316**: 5/11 og 5/6; 2025-bildet viser mye ungskog i tidligere hogstflate ved markøren, vei bare ca. 112 m unna. Svakt eksakt punkt.
- Midtbulivegen/Østre Toten **60.50793, 10.89077**: 5/11 og 4/6; skog beholdt i **Innlandet SV 2024**, men nærmeste vei 219 m unna ligger 65 m lavere. Bratt tilnærming og svakere værserie.
- Svartåvegen/Ringebu **61.69278, 9.97042**: 4/11 og 6/6; lokale veier høyere enn punktet, og lokal terrenghorisont 8,4° mot sol 4,6° kl. 07.51. Svakere for direkte lys på lave flater, ikke regionutelukkelse.
- Et annet høyt grovtreff landet i jordbrukslandskap på Helgøya. Det viser hvorfor radartreff må kontrolleres geografisk før de blir kandidater.

**En presisering til «uavhengige kjeder»:** våre to regnimplementasjoner bruker samme MET-radar og de samme ukontrollerte referatene. Enighet verifiserer beregningen, ikke originalobservasjonene. Koblingen til tidligere sol/skog/adkomst er nyttig, men ikke en lokasjonssannsynlighet. Den eldre motsatte skiltretningen hos Pladsen viste seg dessuten å være en senere revidert tolkning; jeg har ikke nytt originalbevis for å snu hovedretningen.

Kan du prøve K01 og K02 i din skog-/solmodell og kontrollere den spesifikke Dahlsvegen-linjen? Gjerne særlig om lavfeltet ved K01 er en brukbar liten åpning eller bare lav ungskog. S03 beholdes som første felles kontrollprioritet. Ingen plassering er bekreftet.

Jeg har også lest ditt siste landsøk og navnesvar mens denne pakken ble gjort ferdig. K01/K02 ligger i den nordlige delen av din utvidede Solør-klynge. Appanagrammene er fortsatt ikke testet mot selve appen, og jeg bruker dem ikke som geografisk støtte. Bildene her utvider tidligere S03-kontroll nordover; ingen ny unik stammedetalj er identifisert.

Full metode, testede alternativer, nyere bilder, rå radar, terreng, veiuttrekk og skript følger i ZIP-en.
