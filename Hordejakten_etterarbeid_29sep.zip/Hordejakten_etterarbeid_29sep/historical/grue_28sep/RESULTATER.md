# Grue: kilder, brooversikt og dekning — 28.09.2026

**Kassen er ikke lokalisert.** Grue er hovedarbeidsområdet etter brukerens opplysning om Linstow/Høegh og en annenhånds rapport om at en person som nådde kassen ble sett i kommunen. Rapporten om personen er ikke uavhengig kontrollert. Kartet inneholder offentlige steder og undersøkelsesområder, ikke en kassepinne eller sporing av personer.

## Det som faktisk er nytt

1. Grue kommunes eget friluftskart er hentet som geografiske data: **35 rutefigurer, hvorav 25 med brukstype Fottur, og 31 turmålsfigurer**. Figur er ikke nødvendigvis én fullstendig, særskilt tur.
2. Statens vegvesens NVDB har **41 Bru-objekter i kommune 3417**. Kategorien omfatter blant annet kulverter og separate kjøre-/gangbroer. Dette er ikke 41 uavhengige elvekryssinger. Neste side var tom. Rådata og koordinater følger med.
3. En full grensekontroll viser at **omtrent 44,8 % av Grue ligger utenfor rasteret til regionalpasset 27. september**. Omtrent 31,8 % ligger sør for det, og 20,8 % øst for det; disse delene overlapper. Dette er en konkret dekningsmangel i det passet, ikke bevis for at alle tidligere undersøkelser manglet Grue. Skasberget ble eksempelvis undersøkt tidligere.
4. På [Hordes originale sending](https://www.youtube.com/watch?v=EQHgfmZicc8), avlest cirka **19.02 CEST**, viser tavlen nå uglefakta: hodets rotasjon på 270 grader, nattsyn og smågnagere. Nederst ser det ut til å være en rettelse til «årlig». Skjermbildet er bevart lokalt; tidsstempelet er observasjonstid, ikke tidspunktet teksten først ble vist.

## Ugle → GRUE: mulig, men ikke løst

Seere på YouTube og Twitch foreslo Grevling–Rev–Ugle–Ekorn → GRUE. Vi observerte teorien hos seere, ikke som forklaring fra Horde. Den krever et utvalg og en rekkefølge som ennå ikke er dokumentert. Tidligere dyreoversikter inkluderer også stokkand og orrfugl; dyret i olivenoljestativet er omtalt både som grevling og vaskebjørn. Derfor er denne løsningen foreløpig svakere enn den dokumenterte arkitektkoblingen. Tavlas 270 grader er heller ikke automatisk en geografisk peiling.

Sekundær kontroll av dyrelisten: https://horde.pladsen.dev/?fane=hint og https://praktiskinfo.no/hordejakten-2026/ . Disse er ikke arrangørkilder og originalappen er ikke kontrollert her.

## Arbeidsområder, ikke sannsynlighetsrangering

| Område | Nyttig grunnlag | Hva som fortsatt mangler |
|---|---|---|
| A Tjura–Lindtjennet | Faktiske broer; Tjurastien og Rosaløypa i kommunens kart. Vannverksrunden beskrives som lett terreng i furuskog. | Gjenkjennelig leirscene eller original ankomstopplysning. At en seer leter her er ikke et funn. |
| B Frysjøen–Brutjernskoia | Finnvegen har en dokumentert nåværende bro over Sormsbekken, deretter skogsbilvei/sti. | Eksakt brogeometri er ikke identifisert i NVDB. Sormsbekkens navnepunkt må ikke brukes som brokoordinat. |
| C Svullrya–Rotna | Flere dokumenterte broer, kommunalt rutenett, skogsterreng. | Ingen av broene er koblet til Horde. «Rotna» er en elv med mange kryssinger. |
| D Helgen–Kirkesjøå | To dokumenterte veibroer i sør, utenfor det gamle regionalrasteret. | Ingen positiv Horde-forbindelse; dekningsmangelen gir grunn til undersøkelse, ikke høy sannsynlighet. |
| E Rotna–Revtjennet | UT dokumenterer en elvebro på biladkomsten til Kaktjernsberget. | UT oppgir bom og 5,3 km skogsbilvei til Revtjernet. Kort siste gåtur er ikke dermed dokumentert. Denne broa må ikke uten videre identifiseres med Rotnabru i Svullrya. |

Rutene er kartinformasjon, ikke anbefaling om å følge en bestemt vei til kassen. Vi har ikke utført feltkontroll.

## Konkrete bropunkter

WGS84, breddegrad først. Beregnet som gjennomsnitt av NVDB-geometriens knekkpunkter. Presisjon på seks desimaler gjenspeiler formatet, ikke feltmålt sikkerhet.

| NVDB-navn | Koordinat | Vei |
|---|---|---|
| Tjurabru | 60.437401, 12.099145 | Tjuravegen |
| Opåsvegen bru | 60.435957, 12.108305 | Opåsvegen |
| Aurbekkholen | 60.424933, 12.121606 | Tjuravegen |
| Aurbekken | 60.422479, 12.137749 | Tjuravegen |
| Rotnabru | 60.416360, 12.398233 | Finnskogvegen |
| Helgen bru | 60.376609, 12.425243 | Rotnemovegen |
| Kirkesjøå bru | 60.337004, 12.451210 | Rotnemovegen |
| Sandstad bru | 60.466414, 12.021503 | Bruvegen |

Hele listen med 41 objekter, objekt-ID, kilde-URL, kategori og status ligger i `bridges.csv` og `bridges.geojson`. Ingen av disse punktene er foreslått som stedet kassen står.

## Etterprøvbar metode og datakilder

- [Grue kommunes friluftslivside](https://www.grue.kommune.no/kultur-informasjon/tur-friluftsliv/) lenker til [kommunens turkart](https://grue-kom.maps.arcgis.com/apps/instant/basic/index.html?appid=9a7891664c0c4b89a2ff608f316c80a9&locale=nb-no). App-ID `9a7891664c0c4b89a2ff608f316c80a9`, webkart-ID `83de8cf4e39f406eb9f8fb5bdfb02b3b`. Offentlig FeatureServer, lag 2 (ruter) og 0 (turmål). Nøyaktige spørringer og hasher: `download_sources.json`. Ingen flagg for avkorting i svarene.
- Statens vegvesen NVDB, objekttype **60 Bru**, `kommune=3417`, `srid=4326`, `inkluder=egenskaper,geometri,lokasjon,metadata`. Full URL i `nvdb_source.txt`; råresultat `nvdb_bridges.json`; tom neste side `bridge_next.json`. [API-dokumentasjon](https://nvdb-docs.atlas.vegvesen.no/nvdbapil/v4/Vegobjekter/). NVDBs WKT for EPSG:4326 er behandlet som bredde/lengde; eksportert GeoJSON bruker lengde/bredde. **Kilde: Statens vegvesen, NVDB (NLOD).**
- Kartverket kommunegrense: https://ws.geonorge.no/kommuneinfo/v1/kommuner/3417/omrade?utkoordsys=4326 . Råfil `boundary.json`.
- Dekningsmåling: cirka 100 m lokalt rutenett, alle sentre innenfor kommunegrensen med eventuelle hull fjernet; 83 509 sentre, 37 437 utenfor det gamle rasteret. Andelen er tilnærmet areal, ikke eksakt geodetisk areal. Gammel bbox og beregning følger i `coverage_complete.json` og `map_context.py`. Tidligere rask sørkontroll i `old_coverage_check.json` brukte et litt annet rutenett; komplett kontroll erstatter den.
- Terrengbakgrunn: Kartverket NHM DTM, nominelt 25 m, resamplet bart terreng. Metadata i `terrain_sources.json`; kildekode `terrain_context.py`. Laserskanningens opprinnelige år er ikke verifisert. Vegetasjon inngår ikke. Ingen 810–891 m-maske eller flyvinkelantakelser brukes.
- [Finnvegen ved Sormsbekken](https://ut.no/turforslag/1112154444/finnevegen-kirkenr-svullrya): skiller den historiske, oversvømte brua i Sormsvika fra dagens bro over Sormsbekken. [Kaktjernsberget-adkomst](https://ut.no/turforslag/115038/kaktjernsberget-584-moh), [Frysjørunden](https://ut.no/turforslag/115667), [Rosaløypa](https://ut.no/turforslag/1110134). Disse turbeskrivelsene er publisert av private bidragsytere hos UT.

## Avklaringer som må følge videre arbeid

- [Grues høyeste fjell er 584 moh.](https://snl.no/Grue). Hvis kommunen er riktig, er 810–891 moh. feil avgrensning for kassen. Hintets «891 m» kan ha en annen betydning.
- [Norsk kunstnerleksikon](https://nkl.snl.no/Ole_Peter_Riis_H%C3%B8egh) bekrefter Høeghs arbeid for Linstow ved Slottet og Grue kirke. Årene oppgis til 1824–28 i den kilden; brukerens 1823 er ikke ukritisk videreført.
- Original brokommentar og betydningen av offentlig vei er fortsatt ikke gjenfunnet. En bro alene skiller ikke disse områdene.
- Landskapsbildet fra gjeldfriveg1 er fortsatt ikke plassert. De 606 Alvdal-testene ligger i en separat publisert pakke; ingen sikker match, og hele Baugsberget er ikke utelukket. Ingen grunn til å tvinge alle hint til samme sted uten støtte.
- Grue kommunes ruter dekker ikke alle skogsveier eller alle broer. Fravær i disse lagene er ikke et geografisk avslag.
