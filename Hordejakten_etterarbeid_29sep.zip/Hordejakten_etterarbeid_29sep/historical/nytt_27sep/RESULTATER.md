# Hordejakten — update checked 27 September 2026

## What changed

The latest secondary aircraft report concerns 26 September around 20:10 CEST. It associates an upward gesture with SAS4094 or SAS389 and uses a 60-degree minimum elevation to favour Åmot. Its own comparison conflicts with the older pointing event. Aircraft identities, positions and real-world timestamps remain unverified here. Source: https://default.no/

I downloaded the linked public two-minute clip through its browser player, inspected samples every four seconds and retained its checksum in clip_source.json. Anja raises an arm while reclining at +4s and +16–28s; another raised-arm pose is visible at +56s after she sits up. This independently verifies raised-arm imagery, not the spoken phrase, a specific aircraft, continuous gesture boundaries or clock calibration. The filename is not a calibrated start time. The visible vertical projection of an arm does not establish a 60-degree elevation in three dimensions.

Original clip: https://default.no/cuts/202609262010_202609262011.mp4

## Recalculated conditional aircraft geometry

flight_geometry.py uses the reported position/altitude endpoints with 201 interpolated positions, spherical Earth and observer heights from 0 to 600m. Aircraft barometric altitude is treated as approximate geometric altitude. No refraction or terrain/tree visibility model. These intervals are sensitivity ranges, not confidence intervals. Source coordinates in flight_geometry.json are secondary data, not fresh ADS-B retrieval.

| Previous candidate | SAS4094 elevation | SAS389 elevation |
|---|---:|---:|
| S03 Solør | 5.0–5.6° | 2.7–3.0° |
| K01 Dahlsvegen | 5.5–6.2° | 2.9–3.2° |
| K02 Burmavegen | 5.5–6.1° | 2.9–3.2° |
| L07 | 9.5–11.1° | 4.9–5.5° |
| A01 | 32.3–34.6° | 6.8–7.5° |
| Aremark C2 | 1.2–1.3° | 0.5–0.7° |
| Rena-west regional comparison | 29.0–37.3° | 10.0–11.5° |
| Reported stop390 comparison | 53.1–68.2° | 10.1–11.1° |

Consequence: if one of these aircraft was directly overhead, Solør and Aremark are poor fits. If the gesture merely announces an aircraft or points along the camera axis, its 2D appearance is not a justified hard exclusion. A01 fits an intermediate-elevation interpretation better than Solør. None of this confirms a box location. Stop390 is a comparison point, not a recommended field destination; military-land boundaries/access have not been checked here.

## Direct source outside default.no

Horde's sponsored FINN page has a 35-piece puzzle. The rendered puzzle DOM exposes “Ikke en øy” on its pieces. This verifies the not-an-island wording directly at an advertiser source, without relying on a fan site's paraphrase. I did not complete/submit the puzzle. The page does not establish when this hint was released; call it newly checked, not newly published. It does not distinguish our mainland candidates.

https://www.finn.no/annonsorinnhold/eiendom/horde/jakten-2026

KOM24's 26 September interview quotes Horde's marketing manager explaining that a failed heart drawing was mistakenly interpreted by participants as a municipality outline. This is a direct reason to downweight the scribble theory. It does not invalidate deliberately released puzzles. The interview also describes daily planned clues and overnight support shifts; neither supplies a geographic radius.

https://www.kom24.no/horde-hordejakten-kampanje/horde-med-sin-storste-kampanje-noensinne-rekorder-pa-rekorder/954687

## Other updates and limits

- The public-road/no-private-forest-road wording was found on a secondary map legend; its original wording/context/date were not verified. Do not convert OSM service/track labels into ownership, or eliminate Dahlsvegen on that basis.
- Claude's 26 September sunlight update reports that the afternoon observation fits most existing southeastern candidates and does not discriminate them. This is Claude's result, not an independent re-run by me: https://github.com/mkekeoooo/hordejakten-2026/issues/14#issuecomment-5848014301
- The claim that S03 is the only independently passing region is too strong: the prior national scan used shared source observations and a default-derived validity mask. Its ranking comparison also predates the current aircraft model. S03 is a conditional candidate, not a settled winner.
- No confirmed fresh official geographic hint dated27 September was established in the accessible sources checked. No box or new exact field target was found. No GitHub/README changes in this pass.

## Next discriminating work

Recover independently timestamped flight traces and the original public-road statement. Compare both aircraft events under the same uncertainty assumptions before updating geography. Keep a weather/forest branch with Solør and an aircraft branch with Åmot rather than silently combining incompatible hard constraints. Independent Aremark remains a low-priority ecological alternative; it has no weather or scene match and fails the overhead-aircraft branch.
