# Direct aircraft check and alternative-area test — 27 September

## Result

The two26September aircraft tracks have now been independently retrieved from adsb.lol. They agree closely with the positions reported by default.no. This verifies the tracking inputs, NOT which aircraft Anja saw, the stream-to-real-time offset, or the interpretation of her arm.

Flightradar24 identifies26September SK4094 as SE-DOX, ModeS4A91F8, and SK389 as SE-RSO, ModeS4ACA6F. The latter is listed as E195LR by Flightradar24 but E190 in the trace database; no location conclusion depends on this type-label difference.

https://www.flightradar24.com/data/flights/sk4094
https://www.flightradar24.com/data/aircraft/se-dox
https://www.flightradar24.com/data/flights/sk389
https://www.flightradar24.com/data/aircraft/se-rso

Direct traces:
https://globe.adsb.lol/globe_history/2026/09/26/traces/f8/trace_full_4a91f8.json
https://globe.adsb.lol/globe_history/2026/09/26/traces/6f/trace_full_4aca6f.json

The downloaded bytes are gzip-compressed despite the .json filenames. Checksums, callsigns and interpolated positions are preserved in direct_trace_audit.json. Observations near the relevant window are spaced by up to17s for SAS4094 and9.5s for SAS389; per-second interpolation is NOT a claim of per-second independent measurements.

## Timing sensitivity

With the reported20:10:22–20:10:44CEST window, SAS4094 is5.0–5.6degrees from S03. Allowing20:09–20:12CEST only raises its maximum to6.5degrees. Dahlsvegen tops out at7.3degrees; Aremark at1.5degrees. Observer-height sensitivity0–600m, barometric altitude, spherical Earth, no refraction/terrain/tree visibility. Small timing uncertainty therefore cannot make these two identified planes overhead at Solør. A different aircraft or a nonliteral gesture remains possible.

## Symmetric two-night test

Fresh21September traces also retrieved directly:
https://globe.adsb.lol/globe_history/2026/09/21/traces/ac/trace_full_4791ac.json
https://globe.adsb.lol/globe_history/2026/09/21/traces/b0/trace_full_47a3b0.json

joint_aircraft.py uses21September19:28:50–19:29:40UTC as a deliberately broad assumed window, and26September18:10:22–18:10:44UTC as the reported window. Neither visual event's exact time was independently calibrated. Grid60.65–61.60N,10.40–11.70E, steps0.005by0.01degrees; uniform400m observer elevation. The score is the smaller of the maximum aircraft elevations at the two events. It is a geometric compatibility measure, NOT a location probability. Other flights are not included.

| Aircraft pair | Best shared minimum angle in tested grid | Consequence |
|---|---:|---|
| NOZ9EG / SAS4094 |26.7degrees|No grid location supports both above30degrees|
| NOZ56U / SAS4094 |15.8degrees|Even20degrees at both fails|
| NOZ9EG / SAS389 |61.2degrees|High-angle overlap exists farther west|
| NOZ56U / SAS389 |11.0degrees|Poor shared high-angle fit|

This shows why choosing the newest gesture as a strict filter while relaxing the older one can dictate the winning area. The same uncertainty treatment should apply to both.

## Western alternative screened independently of default's candidate list

Downloaded Kartverket terrain and surface raster exports for a30km square centred61.35,10.88, sampled at roughly20m. URLs and bounds are in west_branch.json. Tested the NOZ9EG/SAS389 overlap against a permissive forest proxy: at least40% of a local5x5 raster window has surface-minus-terrain greater than12m. Surface acquisition year is unverified, coarse nearest-neighbour sampling can miss trees, and this proxy does not establish species or a clearing.

- At30degrees shared flight elevation: zero sampled matches to that forest proxy within the exported square.
- Relaxed to20degrees: one sampled match at61.470,10.970; ground about413m, local tall-surface fraction72%, median surface difference13.1m. Shared flight score about22.3degrees assuming400m ground. This is NOT a verified forest site or nationwide unique match; the sparse flight grid is roughly500m and the square does not cover every20degree overlap cell.
- This falls near an earlier northern search cluster, rather than demonstrating a wholly undiscovered region. No road/access/water/modern imagery or rain checks have been done for this exact point. Do not promote it to a travel destination.

## Road clue

Focused public searches still lead back to the secondary map wording, not an original dated Horde statement. No ownership-based candidate exclusion was applied. No GitHub/README mutation or new ranking agreement in this pass.

## Practical ranking implication

Solør retains weather/forest support, but cannot be rescued as an overhead match for these two26September flights by a small timing shift. Åmot fits the latest northbound-flight hypothesis while conflicting with treating the older event equivalently. Western higher ground supplies a different aircraft pairing, but the coarse tall-forest check is weak. No new confirmed location; the hard-overhead model should not be used as a settled exclusion rule.
