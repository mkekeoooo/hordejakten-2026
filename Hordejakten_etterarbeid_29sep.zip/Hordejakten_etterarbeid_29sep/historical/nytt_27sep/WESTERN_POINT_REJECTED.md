# Western point follow-up — 61.470,10.970

Decision: drop this exact point from the practical shortlist. The coarse flight/forest match is on steep ground, with a nearby mapped stream. This does not exclude the entire western region.

## Detailed checks

- Kartverket terrain/surface exports:2km square,800x800 samples,approximately2.5m sampling. Exact point ground421.2m versus413m in the earlier20m sample. This difference reflects sampling on steep ground, not evidence of a changing landscape.
- Ground range across the central35m square:27.6m. Along assumed camera bearing219degrees, ground falls14m within25m and26m within50m. These are sampled terrain values, not a measured platform footprint; a small ledge is not impossible, but the broad site fit is poor.
- About71% of the surrounding100m square has surface-minus-terrain above12m. Tall vegetation survives the finer check; terrain is the problem. Surface acquisition year remains unverified.
- Nearest mapped road: Gålaveien, OSM503635108,139m southwest at217degrees,about64m below the point. This is straight-line separation, not a verified route or road ownership claim.
- A service road lies284m east-northeast,about22m above the point.
- Nearest retrieved stream centreline is98m northwest; Imsa river is434m south. Water audibility and stream permanence are not inferred. OSM water mapping includes old source dates and can be incomplete.
- Esri imagery catalogue at the centre reports19July2024,0.5m source resolution. The800m image shows forest on a ravine-side slope, extensive neighbouring clearings, roads and a stream corridor. No exact scene/box match found. This is not2026 imagery.

## Nearby flatter-ground test

Tested50m-spaced positions across the2km square. Required35m terrain range<=8m,at least50% of a100m local square with surface-minus-terrain>12m,nearest mapped road150–900m,and site0–80m above road. Zero sampled points passed all filters. These are candidate-generation assumptions, not official hints; the sparse grid can miss small platforms, and results do not prove no suitable site exists. No new replacement point promoted.

## Sources and reproducibility

Raw exports and source URLs:west_detail_sources.json; raster bytes:west_detail_DTM.data andwest_detail_DOM.data. Calculation:west_access.py/results west_access.json; neighbourhood test:west_flats.py/results west_flats.json. Image:west_detail.jpg; catalogue metadata:west_detail_metadata.data. Names:Kartverket SSR query recorded in manifest, identifying Gålaveien and nearby Leråbua/Leiråa.

OSM Overpass query returned406. Normal OSM map download succeeded:
https://api.openstreetmap.org/api/0.6/map?bbox=10.951,61.461,10.989,61.479

Terrain source:
https://hoydedata.no/arcgis/rest/services/NHM_DTM_25833/ImageServer

Imagery catalogue:
https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer

No GitHub/README changes. Earlier aircraft conclusions stand; this pass does not establish a new location or justify removing Solør from the separate weather/forest branch.
