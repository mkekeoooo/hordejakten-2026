# Adkomstkontroll av 24 modelltreff, 25. september 2026

Dette er en ny kontroll av treffene fra kronetest og samlet terrengmodell. Ingen plassering er bekreftet.

## Nye beregninger

Veigeometri ble hentet direkte fra OpenStreetMap API 0.6 for tre utsnitt. Rådata ligger i A1A2.osm, Messelt.osm og P7.osm. Første forsøk via Overpass feilet; resultatene bruker ikke Overpass.

For hvert treff ble nærmeste punkt på kartlagte veisegmenter beregnet i EPSG:25833. Veitypene inkluderer skogsvei (track), service og ordinære bilveiklasser; rene stier er ikke brukt som vei. Avstanden og kompassretningen til dette punktet ble deretter beregnet geodetisk. Dette er luftlinje til nærmeste kartlagte vei, ikke gangrute, lovlig parkering eller bekreftet kjørbar adkomst. Andre veier kan være relevante selv når den nærmeste ligger i feil retning.

De 24 treffene danner 18 sammenhengende grupper med en valgt nabogrense på 50 meter. Dette er gruppering av prøver, ikke målte lysninger. Gruppen kan ha større diameter enn 50 meter ved kjeding.

## Tre interessante kontrollpunkter

| ID | Breddegrad | Lengdegrad | DTM moh | Nærmeste vei, luftlinje | Retning mot vei |
|---|---|---|---:|---:|---:|
| C06, A2 | 61.462358 | 10.974954 | 366,52 | 156,2 m | 147,0 grader |
| C07, A2 | 61.462543 | 10.975118 | 364,86 | 169,7 m | 153,3 grader |
| C23, sørlige Messelt | 61.457130 | 10.836146 | 898,18 | 506,9 m | 129,3 grader |

Alle tre består original kronetest og varianten med dedupliserte rasterpiksler, samt M0+B3+B4. Nærmeste vei er registrert som track. C06 og C07 ligger omtrent 22 meter fra hverandre og er samme lokale kontrollområde. Ingen av disse punktene er dokumentert som boksstedet. Millimeterpresisjonen i koordinater eller centimeter i DTM-output uttrykker ikke tilsvarende nøyaktighet i plasseringen.

Eksempler på hvorfor adkomst bør kontrolleres: C14 ved A1 ligger bare 4 meter fra nærmeste registrerte servicevei. Flere østlige A2-treff ligger 37–94 meter fra servicevei. Dette er forhold til kartet, ikke automatisk utelukkelse. Fravær av registrert sti betyr heller ikke at sti mangler.

## Flyfoto kontrollert visuelt

Norge i bilder ble åpnet i nettleser og prosjektet «Innlandet NØ 2023», id 4291, ble valgt. I A2-utsnittets tidslinje var 2025-alternativet Sentinel-2-mosaikk, ikke et nytt høyoppløselig ortofotoprosjekt. Dette er ikke en komplett kartlegging av alle mulige nyere kilder.

Ved C06/C07 ses skog med åpne/glisne partier i nordlig og nordvestlig del av omgivelsene. Ingen sikker identifikasjon av lysningen eller trærne i strømbildet er gjort. C23 ble også inspisert i samme valgte prosjekt; omgivelsene viser skog og åpne partier. Flyfotoets prosjektår er 2023. Eksakt flydato er ikke verifisert. Dette fastsetter IKKE opptaksåret for den tidligere nedlastede DOM-mosaikken.

Lenker til kontrollerte kartutsnitt:

- A2: https://norgeibilder.no/?wkid=25833&is3d=false&xmin=285368.4375&xmax=285791.5625&ymin=6820800.99609375&ymax=6821039.00390625&id=4291
- C23: https://norgeibilder.no/?wkid=25833&is3d=false&xmin=277720.875&xmax=278567.125&ymin=6820554.9921875&ymax=6821031.0078125&id=4291
- Kartverkets beskrivelse av tidslinje og prosjektinformasjon: https://www.kartverket.no/om-kartverket/nyheter/geodataarbeid/2026/juli/norge-i-bilder-er-oppgradert
- OSM kilde: https://api.openstreetmap.org/api/0.6/map?bbox=10.950,61.438,11.000,61.477 (de andre utsnittene er dokumentert med sine lokale råfiler).
- Kartdata © OpenStreetMap-bidragsytere, https://www.openstreetmap.org/copyright

## Foreløpig konklusjon

C06/C07 er en konkret lokal kontrollprioritet fordi nærterreng, foreslåtte kronekriterier og retningen til nærmeste kartlagte vei passer samtidig. C23 er et alternativ med tilsvarende vei-retning, men annen høyde og lengre avstand. Ingen sannsynligheter er beregnet. Vi trenger fortsatt dokumentert tidsmessig samsvar i skogbildet og bedre stedsspesifikke kjennetegn før vi kan velge en faktisk plassering.

CSV inneholder alle 24 punkter, veidata og DTM-høyde. GeoJSON inneholder de samme punktene og veidata; høydekolonnen finnes i CSV. Skriptet access_check.py reproduserer veiberegningene; DTM-høydene ble lagt til separat fra eksisterende DTM1-utsnitt.
