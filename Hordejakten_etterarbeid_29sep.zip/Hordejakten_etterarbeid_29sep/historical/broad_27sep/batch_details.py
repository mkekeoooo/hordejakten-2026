from pathlib import Path
import json,urllib.request,urllib.parse,math
from concurrent.futures import ThreadPoolExecutor
P=Path(__file__).parent
allpoints=json.loads((P/'region_results.json').read_bytes())['selected']
ids=['weather_2','weather_5','weather_6','weather_7','both_flights_1','both_flights_2','both_flights_7','latest_flight_1','latest_flight_3','latest_flight_5']
def fetch(url,p):
 if not p.exists():p.write_bytes(urllib.request.urlopen(url,timeout=40).read())
 return p.read_bytes()
def run(r):
 name=r['id'];D=P/name;D.mkdir(exist_ok=True);la=r['lat'];lo=r['lon'];s=math.cos(math.radians(la));R=6378137;x=R*math.radians(lo);y=R*math.log(math.tan(math.pi/4+math.radians(la)/2));h=1000/s;box=[x-h,y-h,x+h,y+h];sources={};errors={}
 jobs=[]
 for k in ['DTM','DOM']:
  q=dict(bbox=','.join(map(str,box)),bboxSR=3857,imageSR=3857,size='800,800',format='bsq',pixelType='F32',interpolation='RSP_NearestNeighbor',f='image');jobs.append((k,f'https://hoydedata.no/arcgis/rest/services/NHM_{k}_25833/ImageServer/exportImage?'+urllib.parse.urlencode(q)))
 jobs.append(('names','https://ws.geonorge.no/stedsnavn/v1/punkt?'+urllib.parse.urlencode(dict(nord=la,ost=lo,koordsys=4326,radius=1500,treffPerSide=30))))
 dl=.011/s;jobs.append(('osm',f'https://api.openstreetmap.org/api/0.6/map?bbox={lo-dl},{la-.011},{lo+dl},{la+.011}'))
 base='https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer';hh=400/s
 jobs.append(('imagery',base+'/export?'+urllib.parse.urlencode(dict(f='json',bbox=f'{x-hh},{y-hh},{x+hh},{y+hh}',bboxSR=3857,imageSR=3857,size='1000,1000',format='jpg'))))
 jobs.append(('metadata',base+'/10/query?'+urllib.parse.urlencode(dict(f='json',geometry=f'{lo},{la}',geometryType='esriGeometryPoint',inSR=4326,spatialRel='esriSpatialRelIntersects',outFields='*',returnGeometry='false'))))
 q=dict(SERVICE='WMS',VERSION='1.1.1',REQUEST='GetFeatureInfo',LAYERS='Skytefelt',QUERY_LAYERS='Skytefelt',STYLES='',SRS='EPSG:4326',BBOX=f'{lo-.005},{la-.005},{lo+.005},{la+.005}',WIDTH=101,HEIGHT=101,X=50,Y=50,FORMAT='image/png',INFO_FORMAT='text/plain',FEATURE_COUNT=10)
 jobs.append(('military','https://wms.geonorge.no/skwms1/wms.skytefelt?'+urllib.parse.urlencode(q)))
 for k,u in jobs:
  try:
   b=fetch(u,D/(k+'.data'));sources[k]=u
   if k=='imagery':fetch(json.loads(b)['href'],D/'imagery.jpg')
  except Exception as ex:errors[k]=str(ex)
 result=dict(**r,bbox3857=box,sources=sources,errors=errors);(D/'sources.json').write_text(json.dumps(result,indent=2));print(name,errors,flush=True);return result
res=list(ThreadPoolExecutor(3).map(run,[r for r in allpoints if r['id'] in ids]));(P/'detail_manifest.json').write_text(json.dumps(res,indent=2))
# All22point military screening, rather than only the ten detail areas.
def mil(r):
 la=r['lat'];lo=r['lon'];q=dict(SERVICE='WMS',VERSION='1.1.1',REQUEST='GetFeatureInfo',LAYERS='Skytefelt',QUERY_LAYERS='Skytefelt',STYLES='',SRS='EPSG:4326',BBOX=f'{lo-.005},{la-.005},{lo+.005},{la+.005}',WIDTH=101,HEIGHT=101,X=50,Y=50,FORMAT='image/png',INFO_FORMAT='text/plain',FEATURE_COUNT=10);u='https://wms.geonorge.no/skwms1/wms.skytefelt?'+urllib.parse.urlencode(q)
 try:
  txt=fetch(u,P/(r['id']+'_military.txt')).decode();return dict(id=r['id'],url=u,result=txt)
 except Exception as ex:return dict(id=r['id'],url=u,error=str(ex))
(P/'military_checks.json').write_text(json.dumps(list(ThreadPoolExecutor(3).map(mil,allpoints)),indent=2))
