from pathlib import Path
import math,json,xml.etree.ElementTree as ET
import numpy as np
from scipy.ndimage import uniform_filter,maximum_filter,minimum_filter
from concurrent.futures import ThreadPoolExecutor
P=Path(__file__).parent;R=6378137
def xy(la,lo):return np.array([R*math.radians(lo),R*math.log(math.tan(math.pi/4+math.radians(la)/2))])
def ll(v):return [math.degrees(2*math.atan(math.exp(v[1]/R))-math.pi/2),math.degrees(v[0]/R)]
def run(row):
 D=P/row['id'];box=row['bbox3857'];s=math.cos(math.radians(row['lat']));Z=np.frombuffer((D/'DTM.data').read_bytes()[:2560000],dtype='<f4').reshape(800,800);H=np.frombuffer((D/'DOM.data').read_bytes()[:2560000],dtype='<f4').reshape(800,800)-Z
 def height(v):
  col=int((v[0]-box[0])/(box[2]-box[0])*800);r=int((box[3]-v[1])/(box[3]-box[1])*800)
  return float(Z[r,col]) if 0<=r<800 and 0<=col<800 else None
 root=ET.parse(D/'osm.data').getroot();nodes={n.attrib['id']:xy(float(n.attrib['lat']),float(n.attrib['lon'])) for n in root.findall('node')};roads=[];water=[];build=[]
 for w in root.findall('way'):
  t={q.attrib['k']:q.attrib['v'] for q in w.findall('tag')};v=[nodes[q.attrib['ref']] for q in w.findall('nd') if q.attrib['ref'] in nodes]
  if len(v)<2:continue
  segments=[(a,b,w.attrib['id'],t) for a,b in zip(v[:-1],v[1:])]
  if t.get('highway') in ['primary','secondary','tertiary','unclassified','residential','service','track']:roads.extend(segments)
  if 'waterway' in t or t.get('natural') in ['water','wetland']:water.extend(segments)
  if 'building' in t:build.extend(segments)
 def make(seg):
  if not seg:return None
  a=np.array([q[0] for q in seg]);v=np.array([q[1]-q[0] for q in seg]);return a,v,np.maximum((v*v).sum(axis=1),1e-9)
 rd=make(roads);wd=make(water);bd=make(build)
 def nearest(p,data):
  if data is None:return None,None,float('inf')
  a,v,vv=data;t=np.clip(((p-a)*v).sum(axis=1)/vv,0,1);ps=a+t[:,None]*v;ds=np.linalg.norm(ps-p,axis=1)*s;i=int(np.argmin(ds));return i,ps[i],float(ds[i])
 frac=uniform_filter(((H>12)&(H<70)).astype('float32'),40);relief=maximum_filter(Z,14)-minimum_filter(Z,14);cand=[];counts=dict(terrain_forest=0,road_band=0,water_and_building=0)
 for r in range(25,775,10):
  for c in range(25,775,10):
   if not(0<Z[r,c]<1500) or relief[r,c]>8 or frac[r,c]<.5:continue
   counts['terrain_forest']+=1;p=np.array([box[0]+(c+.5)/800*(box[2]-box[0]),box[3]-(r+.5)/800*(box[3]-box[1])]);i,q,dist=nearest(p,rd)
   if not(150<=dist<=900):continue
   counts['road_band']+=1;wi,wp,waterdist=nearest(p,wd);bi,bp,builddist=nearest(p,bd)
   if waterdist<100 or builddist<150:continue
   counts['water_and_building']+=1;qh=height(q);la,lo=ll(p)
   cand.append(dict(lat=la,lon=lo,ground_m=float(Z[r,c]),relief35m=float(relief[r,c]),tall_fraction100m=float(frac[r,c]),road_distance_m=dist,road_id=roads[i][2],road_tags=roads[i][3],road_point=ll(q),road_bearing=math.degrees(math.atan2(q[0]-p[0],q[1]-p[1]))%360,gain_from_road_m=float(Z[r,c])-qh if qh is not None else None,nearest_water_m=waterdist if math.isfinite(waterdist) else None,nearest_building_m=builddist if math.isfinite(builddist) else None,r=r,c=c))
 cand.sort(key=lambda z:(-z['tall_fraction100m'],z['relief35m']));selected=[]
 for p in cand:
  if all(math.hypot(p['r']-q['r'],p['c']-q['c'])*2.5>250 for q in selected):selected.append(p)
  if len(selected)==3:break
 names=json.loads((D/'names.data').read_bytes()).get('navn',[]);meta=json.loads((D/'metadata.data').read_bytes()).get('features',[]);mil=(D/'military.data').read_text(encoding='utf-8')
 center=dict(ground_m=float(Z[400,400]),relief35m=float(relief[400,400]),tall_fraction100m=float(frac[400,400]))
 out=dict(id=row['id'],seed=[row['lat'],row['lon']],names=[dict(distance=q['meterFraPunkt'],name=q['stedsnavn'][0]['skrivemåte']) for q in names[:5]],image_dates=[q['attributes'].get('SRC_DATE') for q in meta],military=mil,center=center,counts=counts,selected=selected)
 (D/'analysis.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8');print(row['id'],counts,len(selected),flush=True);return out
rows=json.loads((P/'detail_manifest.json').read_bytes());out=list(ThreadPoolExecutor(3).map(run,rows));(P/'detail_results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
