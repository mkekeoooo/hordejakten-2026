# Hordejakten — broad independent regional pass, 27 September 2026

This pass replaces one-pin-at-a-time work with a regional screen. No treasure location or filmed clearing has been identified. The useful result is a larger, reproducible set of alternatives and evidence that our earlier apparent convergence was too strong.

## What was actually covered

- A nominal 130 × 130 km window centred at 61.0 N, 11.25 E, using national DTM and DOM height services. This is a regional search, not all of Norway.
- 355,216 sampled positions; 351,161 inside an independent Natural Earth Norway mask; 8,135 met coarse terrain and tall-surface filters. These are grid samples, not 8,135 identified clearings.
- Three separate rankings: reported rain agreement, both aircraft evenings, and the latest aircraft evening alone. Twenty-two region representatives were selected, separated by at least 8 km within each ranking.
- Ten regions received 2 km detailed height/road/water/building checks. Six regions produced 16 spatially separated sample clusters. All 16 received point-centred imagery, acquisition-date lookup, mapped-water route checks and official military-boundary queries.
- Satellite brightness sensitivity was compared for all 16 points on 23 and 25 September, with four assumed cloud heights. No binary cloud exclusion was imposed.

The regional terrain criteria are heuristic: surface-height difference above 12 m in at least 40% of a roughly 180 m neighbourhood; roughly 108 m terrain range at most 20 m. Detailed criteria use at least 50% tall surface in a 100 m square, at most 8 m relief in a 35 m square, road distance 150–900 m, mapped water distance at least 100 m and mapped building distance at least 150 m. Height acquisition dates are not established. These criteria do not identify species, a tent-sized canopy gap, public road ownership or a scene match.

## Findings that change the investigation

**The rain ranking has weak demonstrated predictive robustness.** Across 2,653 Norwegian land-grid positions, selecting the best match to the first nine reported wet/dry observations produced three tied winners (balanced accuracy 0.90). Each scored 0.50 on the remaining eight. This retrospective diagnostic does not rule out Solør. It does mean that fitting the whole sequence should not be called independent confirmation. The 17 observations still come from a secondary source, rather than a fresh verification of the original recordings.

The best full-sequence score at a 0.1 mm/hour radar threshold was 0.8258 near 60.45404, 12.26620. In an exploratory 1,000-label shuffle, 121 shuffled datasets yielded an equally high or higher maximum somewhere in the tested grid. This is **not a calibrated p-value**, because temporal dependence is destroyed and the exercise is retrospective; it is **not a location probability**. The regional ranking uses a median of three thresholds, while this robustness diagnostic uses one threshold.

**No sampled forest/terrain position supports a 30° aircraft elevation on both reported evenings.** The largest smaller-of-two maximum angles was 25.41°, at 61.46354, 10.90909 with local ground height about 587 m. This allows either of the two tested aircraft on each evening. The result is conditional on the reported time windows, the four traces, the regional grid and the terrain filters. It does not establish that the gestures mean 30°, exclude unsampled areas, or prove a different aircraft identity. It is a reason to stop forcing both gestures into one precise geometric constraint.

**The Mjøsa imagery exposed incomplete water filtering.** The Moen/Målingen samples lie in narrow woodland near fields; point 2 is visibly near Mjøsa even though the extracted OSM water distance was 472 m. The OSM way-based extraction misses some water geometry, including relation-based or off-window shoreline. All automatically reported water distances are therefore provisional. A route with zero mapped intersections is not verified dry ground.

**Imagery age changes within a single search neighbourhood.** Two Bynstua points return 2019 imagery metadata, whereas the third returns 2024. The coarse seed's 2024 date must not be applied to the entire region. Point-specific dates are saved.

**Two latest-aircraft region seeds intersect Regionfelt Østlandet.** Those seeds (latest_flight_5 and latest_flight_6) were removed from the field shortlist. The 16 detailed surviving sample points returned no hit in the published military-boundary service; this is a boundary lookup, not a general access determination.

## Alternatives and disposition

| Area / representative | Why it survives | Main weakness / disposition |
|---|---|---|
| **Bynstua–Vangbrenna, 61.005553, 10.692087** | Point-centred 2024 imagery shows a forest block; 35 m terrain range 1.4 m; nearest mapped drivable road 441 m; about +6 m from road | Better structural alternative west of earlier favourites. Satellite brightness on 25 September is less favourable than S03 across the four tested cloud-height scenarios. Keep as a challenged alternative, not the new favourite. |
| **Yglesætra vicinity, 61.226848, 11.355352** | 2025 imagery; substantial forest around the sample; 35 m terrain range 7.2 m; mapped road 411 m | Latest-aircraft branch. Nearby selected points are roughly 51 m below their nearest road; this point's road elevation falls outside the height window. No verified uphill approach or clearing match. |
| **Skasberget / Nytorpet vicinity, 60.438035, 12.275857** | Strong regional reported-rain branch; road 237 m; approximately +34 m from that road; 35 m range 6.8 m | Imagery is from 2018; both aircraft angles are low in this region. An alternative to S03 within broader Solør, not independent corroboration of Solør. |
| **Kvesetberget, 60.534755, 12.293756** | Road 195 m; approximately +18 m gain; tall-surface fraction 60% | Imagery from 2017; weak aircraft geometry. Nearby point has more tall forest but lies below its nearest road. |
| **Pershytta / Ormset vicinity, 61.268077, 11.507165** | Latest-aircraft branch; road 236 m; approximately +38 m gain | Imagery from 2017, visibly managed forest and nearby open land; weak older-aircraft agreement. Place names describe the vicinity, not exact point identity. |
| **Moen / Målingen** | 2025 imagery and a reasonable coarse reported-rain match | Downgraded after imagery: narrow agricultural woodland and incomplete lake-distance extraction. |

Visual inspection of the 16 point-centred images did not identify the filmed clearing. Most samples are closed canopy, managed forest or forest edges. Tiny gaps could be unresolved, but a high forest score must not be described as a scene match.

## Sun/cloud cross-check

The existing EUMETSAT rendered visible images were sampled along hypothetical sun rays, with spherical satellite parallax, at cloud heights 1, 2, 5 and 10 km and each point's measured ground height. A small local median was used. Baselines are minimum brightness from other days at the same clock time; these are not guaranteed clear-sky references.

On 23 September, the alternatives largely overlap S03 in displayed excess brightness. On 25 September, Bynstua point 3 gives 46, 54, 29, 46 display units, compared with S03's 28, 7, 15, 13. Yglesætra point 3 gives 32, 30, 31, 32. This is unfavourable comparative evidence for the western alternatives under this model, **not proof of opaque cloud or an exclusion**. Values are rendered image brightness, not optical thickness or cloud probability; assumed cloud height changes the sampled location. S03 ground height is a 250 m reference assumption for this comparison.

## Sources and reproducibility

- [National height data](https://hoydedata.no/) — primary DTM and DOM services. Exact tile URLs/checksums in region_sources.json and point-region sources.json files.
- [OpenStreetMap API](https://api.openstreetmap.org/api/0.6/) — saved map extracts; incomplete water geometry caveat above.
- [Kartverket place-name API](https://ws.geonorge.no/stedsnavn/v1/) — nearby names, not proof of exact named location.
- [Esri World Imagery](https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer) — point-centred imagery and point-specific source dates.
- [Official military-area WMS](https://wms.geonorge.no/skwms1/wms.skytefelt?service=wms&request=getcapabilities) — exact query URLs saved in refined.json and military_checks.json.
- [EUMETSAT WMS](https://view.eumetsat.int/geoserver/wms) — previously saved dated imagery and source manifests in satellitt_25sep.
- [adsb.lol historical traces](https://globe.adsb.lol/) — direct trace files in nytt_27sep; source URLs and time/identity limitations documented there.

Main files: regional_comparison.png, imagery_contact.jpg, screened_points.geojson, region_results.json, detail_results.json, refined.json, rain_audit.json and sun_sensitivity.json. Raw inputs and scripts are retained. No GitHub ranking or README claim was changed during this pass.

## What would materially resolve the remaining disagreement

The next discriminating evidence is an original-recording audit of the wet/dry observations, a calibrated timestamp/identity for the aircraft event, or a recognisable scene feature. More precise-looking scores from the same uncertain observations would not establish a breakthrough. The strongest practical result of this pass is that there are multiple geographic branches, and none currently passes a genuinely independent full set of verified clues.
