from pathlib import Path
import json,gzip,math,numpy as np,shapely
from shapely.geometry import shape
from scipy.ndimage import uniform_filter,maximum_filter,minimum_filter
from scipy.spatial import cKDTree
P=Path(__file__).parent;root=P.parent;j=json.loads((P/'region_sources.json').read_bytes());box=j['bbox3857'];N=j['size'];Z=np.load(P/'DTM.npy');H=np.load(P/'DOM.npy')-Z
valid=np.isfinite(H)&(H>=-10)&(H<=70)&(Z>=0)&(Z<2000)
frac=uniform_filter((valid&(H>12)).astype('float32'),5,mode='constant');coverage=uniform_filter(valid.astype('float32'),5,mode='constant');relief=maximum_filter(Z,3)-minimum_filter(Z,3)
rr,cc=np.meshgrid(np.arange(12,N-12,6),np.arange(12,N-12,6),indexing='ij');rr=rr.ravel();cc=cc.ravel();height=Z[rr,cc];f=frac[rr,cc];rel=relief[rr,cc]
x=box[0]+(cc+.5)*(box[2]-box[0])/N;y=box[3]-(rr+.5)*(box[3]-box[1])/N;lon=np.degrees(x/6378137);lat=np.degrees(2*np.arctan(np.exp(y/6378137))-np.pi/2)
geo=json.loads((root/'satellitt_25sep/ne_50m_admin_0_countries.geojson').read_bytes());nor=shape(next(q['geometry'] for q in geo['features'] if q['properties'].get('ADMIN')=='Norway'));land=shapely.contains_xy(nor,lon,lat)
keep=land&(coverage[rr,cc]>.99)&(f>=.4)&(rel<=20)&(height<1100);total=len(rr)
rr,cc,height,f,rel,x,y,lon,lat=[a[keep] for a in [rr,cc,height,f,rel,x,y,lon,lat]]
print('sampled',total,'land',int(land.sum()),'forest/terrain candidates',len(rr),flush=True)
R=6371000
def flight(file,start,end):
 b=(root/'nytt_27sep'/file).read_bytes();d=json.loads(gzip.decompress(b) if b[:2]==b'\x1f\x8b' else b);a=np.array([[r[0],r[1],r[2],r[3]] for r in d['trace'] if isinstance(r[3],(int,float))]);t=np.arange(start,end+1,2);xyz=np.array([np.interp(t,a[:,0],a[:,k]) for k in [1,2,3]]);best=np.full(lat.shape,-90.)
 for la,lo,ft in xyz.T:
  p=np.radians(lat);q=math.radians(la);theta=np.arccos(np.clip(np.sin(p)*math.sin(q)+np.cos(p)*math.cos(q)*np.cos(np.radians(lon-lo)),-1,1));el=np.degrees(np.arctan2((R+ft*.3048)*np.cos(theta)-(R+height),(R+ft*.3048)*np.sin(theta)));best=np.maximum(best,el)
 return best
a=flight('trace_full_4791ac_21.json',70130,70180);b=flight('trace_full_47a3b0_21.json',70130,70180);c=flight('trace_full_4a91f8.json',65422,65444);d=flight('trace_full_4aca6f.json',65422,65444);older=np.maximum(a,b);latest=np.maximum(c,d);balanced=np.minimum(older,latest)
rad=np.load(root/'nytt_landsok_26sep/wide_radar.npz');mask=np.isfinite(rad['score']);rlat=rad['lat'][mask];rlon=rad['lon'][mask];tree=cKDTree(np.c_[rlon*111200*math.cos(math.radians(61)),rlat*111200]);dist,idx=tree.query(np.c_[lon*111200*math.cos(math.radians(61)),lat*111200]);rain=rad['score'][mask][idx];rain[dist>4500]=np.nan
oldsites=[(60.53938,12.18334),(60.60356,12.14124),(60.59997,12.17279),(60.82353,11.5375),(61.23076,11.72394),(61.47,10.97),(61.295,11.17)]
branches={'weather':(np.nan_to_num(rain,nan=-1)+.01*f,8),'both_flights':(balanced+.1*f,8),'latest_flight':(latest+.1*f,6)};selected=[]
for branch,(score,count) in branches.items():
 chosen=[]
 for k in np.argsort(score)[::-1]:
  if any(math.hypot(x[k]-x[q],y[k]-y[q])*math.cos(math.radians(lat[k]))<8000 for q in chosen):continue
  chosen.append(k)
  near=min(math.hypot((lat[k]-la)*111200,(lon[k]-lo)*111200*math.cos(math.radians(lat[k]))) for la,lo in oldsites)
  selected.append(dict(id=f'{branch}_{len(chosen)}',branch=branch,lat=float(lat[k]),lon=float(lon[k]),height_m=float(height[k]),tall_fraction_180m=float(f[k]),relief_108m=float(rel[k]),rain_score_nearest_5km=float(rain[k]) if np.isfinite(rain[k]) else None,radar_node_distance_m=float(dist[k]),old_flight_max_deg=float(older[k]),new_flight_max_deg=float(latest[k]),shared_min_deg=float(balanced[k]),distance_to_known_shortlist_m=near,row=int(rr[k]),col=int(cc[k])))
  if len(chosen)>=count:break
out=dict(method='130kmnominal square,3600²raster~36msample;216mcandidategrid;NaturalEarthNorway;validheight0-1100;local5x5tallproxy>12matleast40%;3x3terrainrange<=20m. NO roads,water,currentforestyear,species,access,fieldverification. Ranks are hypotheses,not probabilities.',sampled_grid_points=total,land_grid_points=int(land.sum()),passing_grid_points=len(rr),selected=selected)
(P/'region_results.json').write_text(json.dumps(out,indent=2));np.savez_compressed(P/'screened_grid.npz',lat=lat,lon=lon,height=height,tall_fraction=f,relief=rel,rain=rain,old_flight=older,new_flight=latest,balanced=balanced)
print(json.dumps(selected,indent=2))
