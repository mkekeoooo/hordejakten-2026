**Codex: radarverdiene er gjenskapt uavhengig, men den lengre regnsekvensen taler MOT å svekke S03 på grunnlag av 07.45 alene.**

Jeg har hentet MET Norges originale 1 km / 5-minutters radar for ni punkter, fra 25.09 kl. 22Z til dagens tilgjengelige data, og valgt cellene med en separat Lambert-projeksjon. METs egne lat/lon-arrayer bekrefter celleplasseringen ved S03. Dine morgen-/nattandeler og maksverdier gjenskapes ved samtlige sju overlappende kontrollpunkter (L07, A01, S03, 60.77395, 60.55727, 60.63783, 60.96777). Dine tall stemmer.

**1. Kildekontrollen av Anjas utsagn er fortsatt åpen.** Jeg forsøkte originalbildet 26.09 07.46.22 og minuttarkivet; default.no returnerer 403 / «This Page Does Not Exist» for disse ressursene og rå regnfiler, mens hovedrapporten kan leses. Den offisielle YouTube-sendingen spiller, men tilbakespoling er deaktivert. Jeg kan derfor ikke bekrefte «LITT SMÅREGN …» i originalen. Videre: «Hvorfor har den ikke ladet …» og «Skiltet til høyre …» er **chatreferater under tavlebildene i rapporten**, ikke dokumentert tekst på Anjas tavle. Jeg ville rettet dette i saksteksten.

**2. Hele den publiserte morgenserien gir en annen prioritering enn første observasjon alene.** Default.no har nå 20 referater fra 07.45 til 12.24 CEST. Jeg brukte de 11 tydelige regnreferatene og seks opphold/tørt-referater; «mindre regn» og to drypp-referater er ikke presset inn i ja/nei. Originalene er ikke kontrollert, så resultatet er betinget av korrekt referat og tid.

Her er **gjennomsnittlig radarintensitet i 3×3 celler og ±5 min, mm/t**, etter maskering av no-data, blokkering og ground clutter:

| Referat, CEST | L07 | A01 | S03 | default #324 |
|---|---:|---:|---:|---:|
| 08.35 regn | 0,008 | 0,012 | 0,058 | 0,255 |
| 08.50 mer regn | 0,019 | 0,010 | **0,294** | 0,003 |
| 09.10 stoppet | 0,024 | 0,026 | **0,012** | 0 |
| 09.21 tørt | 0,032 | 0,161 | **0** | 0 |
| 09.37 tørt | 0,005 | 0,052 | **0** | 0 |
| 10.27 mer regn | 0,002 | 0 | **0,212** | 0,751 |
| 10.34 stoppet | 0 | 0 | **0,192 – konflikt** | **0,748 – konflikt** |
| 10.47 regn | 0 | 0 | **0,146** | 0,104 |
| 11.20 stoppet | 0,002 | 0 | **0,015** | 0,346 |
| 11.40 mer regn | 0,002 | 0,0003 | **0,451** | 0,580 |
| 12.07 mer regn | 0,008 | 0,020 | **0,299** | 0,114 |
| 12.24 stoppet | 0,106 | 0,010 | **0,003** | 0,002 |

S03 er **60.53938, 12.18334**. #324 er **60.4644, 12.1207**, omtrent 9 km unna. Begge har flere av pulsene; de er ikke uavhengige værbekreftelser av samme lysning.

**3. Følsomhet, ikke lokasjonssannsynlighet.** Jeg prøvde sentrumscellen / 3×3 / 5×5 celler, tidsforskyvning −10/0/+10 min og terskel 0,05/0,1/0,2 mm/t: 27 varianter. Hver hendelse bruker ±5 min. Med lik vekt til andel treff blant regnreferater og blant oppholdsreferater blir S03 øverst i 15 varianter, #324 i 9 og 60.63783/12.28269 i 3. Dette er en enkel sammenligning av **ni utvalgte punkter**, ikke landsrangering, kalibrert sannsynlighet eller 17 uavhengige bevis.

Ved grunninnstillingen 3×3 / ingen forskyvning / 0,1 mm/t:
- S03: **8/11 regnreferater og 5/6 oppholdsreferater**.
- #324: 8/11 og 4/6.
- 60.77395/12.08670: 3/11 og 6/6.
- 60.55727/11.77521: 4/11 og 3/6.
- L07 og A01: **0/11 og 5/6**.

Dermed skal ikke de to nordligere Solør-punktene løftes foran S03 bare fordi de har signal ved 07.45. S03 har et klart manglende morgensignal, og 10.34 passer ikke; jeg har beholdt begge konfliktene.

**4. Kvalitetsflagg og avgrensning.** Ingen no-data eller blocked i mine ni utsnitt. Ground-clutter-flagg forekommer og er maskert i sekvensanalysen. Ditt skript omgjør manglende/ugyldige rateverdier til 0; behold dem heller som manglende ved framtidige kjøringer. Det endret ikke reproduksjonen her. Radaren kan overse yr, og takdrypp kan fortsette etter nedbør. Ingen enkelt nullverdi utelukker et sted.

**Mitt forslag:** behold S03 og løft det til førsteprioritet for kontroll av den *lengre regnsekvensen*, med #324 som geografisk kontroll. L07/A01 står fortsatt åpne, men den regionale morgenoppsummeringen gir dem ikke automatisk bedre støtte. Ikke merk S03 generelt «svekket av dagens regn» før den senere serien er vurdert. Kan du kontrollere serien mot ditt eget opptak og særlig overgangen 08.35–09.10, 10.34 og 11.20–12.24?

Kilder: [publiserte hendelsesreferater](https://default.no/) · [MET originaldata 26.09](https://thredds.met.no/thredds/dodsC/remotesensing/reflectivity-nordic/2026/09/yrwms-nordic.mos.pcappi-0-dbz.noclass-clfilter-novpr-clcorr-block.nordiclcc-1000.20260926.nc.html). Råuttrekk, skript, hendelsestabell, kvalitetsflagg og sammenligningsfigur er samlet lokalt til én dokumentasjonspakke. Ingen plassering er bekreftet.
