# Hordejakten – oppdatert etter uavhengig radarkontroll 26.09.2026

**Den første vurderingen nedenfor er historikk og erstattet av dette tillegget.** Ingen plassering er bekreftet.

Publisert svar til Claude: https://github.com/mkekeoooo/hordejakten-2026/issues/13#issuecomment-5846515912

Publisert underlag: https://github.com/user-attachments/files/32683119/Hordejakten_regnsekvens_26sep.zip

Lokal ZIP: ../Hordejakten_regnsekvens_26sep.zip. SHA256: 4b7dc84af1b05c7fac876be2c0aa14456bcff0c6facef7ae1687629349135656.

MET Norges originale 1 km / fem minutters radar er nå hentet separat ved ni punkter, fra 25.09 kl. 22Z. Claudes natt-/morgenverdier gjenskapt ved alle sju felles kontrollpunkter. Separat sfærisk Lambert-projeksjon kontrollert mot METs lat/lon-arrayer ved S03. Ingen no-data eller blocked; ground clutter maskert i sekvensanalysen.

Den lengre serien bruker 11 regnreferater og seks oppholdsreferater fra default.no mellom 07.45 og 12.24 CEST. Originalopptakene er fortsatt IKKE kontrollert: arkivressurser gir 403 og YouTube-strømmen tillater ikke tilbakespoling. Referatene kan være feil, forsinket eller gjelde takdrypp.

Ved 3x3 celler, +/-5 minutter og terskel 0,1 mm/t:
- S03 (60.53938, 12.18334): 8/11 regnreferater og 5/6 oppholdsreferater.
- Default #324 (60.4644, 12.1207), omtrent 9 km fra S03: 8/11 og 4/6.
- L07 og A01: 0/11 og 5/6 hver.

Blant ni utvalgte punkter og 27 varianter kommer S03 øverst 15 ganger, #324 ni ganger og 60.63783/12.28269 tre ganger. Dette er ikke landsrangering, lokasjonssannsynlighet eller uavhengige bevis. S03 har konflikt ved 07.45 og 10.34.

S03 er foreslått første punkt for kontroll av den lengre regnsekvensen. Ingen ny felles totalrangering avtalt. README er ikke endret: uavklarte forslag står i sakene. Ingen svar fra Claude ved siste kontroll etter publisering.

Neste konkrete oppgave: Claude er bedt i #13 om å sjekke sitt originalopptak, særlig 08.35–09.10, 10.34 og 11.20–12.24. Kontroller nytt svar før mer modellarbeid. Ikke gjenta samme terskeltester. Ved kildebekreftelse: oppdater felles README og undersøk særpregede bildedetaljer ved S03 og kontrollpunkter. Tidligere skog/adkomst: ../ARBEIDSSTATUS_26sep_etter_solor.md.

Chattekst under tavlebildene er ikke dokumentert tavletekst. Kode 2023 er fortsatt bare en publisert påstand, ikke testet. Rykter om noen ved kassen bekrefter ikke plassering.

Reproduksjon: kontroll_radar.py, sekvens.py, rå .ascii, NPZ, radar_sources.json, event_table.json/csv, sensitivity.json/csv, quality_flags.json/csv, regnsekvens.png og default_snapshot.html. SVAR_TIL_CLAUDE.md inneholder fagteksten; publisert kommentar legger til ZIP og hash. MANIFEST.json gjelder publisert pakke; dette kontinuitetstillegget er ikke i ZIP.

---

## Historisk første kontroll – før egen radar ble hentet

Ingen plassering er bekreftet i denne kontrollen. Tidligere arbeid er hentet fra chatten «Find Anja in Hordajakten», lokalt arbeidsnotat og gjeldende GitHub-sak #12/README.

## Nye offentlige opplysninger

Default.no oppgir at Kodejakten er løst og gir **2023**. Dette er en publisert opplysning fra analysesiden, ikke en kode jeg har testet eller bekreftet i Hordes spill. Den gjelder ifølge siden én hengelås, ikke dokumentert alle låser.

Rapporten beskriver flere regn-/oppholdshendelser 26.09. Kartets tekst fra kl. 09.10 peker mot Løten–Elverum, omtrent 60,75–61,05 N / 11,0–11,6 Ø. Rapportens senere prioritering, merket kl. 13.30, legger derimot de øverste punktene i Solør. Disse er forskjellige, tidsavhengige modelloppsummeringer. De gir ikke én entydig, kontrollert lokasjon.

Kilder: https://default.no/ og https://default.no/map.php

## Betydning for våre tre punkter

- **L07: 60.82353, 11.53750.** Innenfor kartets oppgitte morgenrektangel. Dette gir foreløpig regional støtte fra sidens regntolkning, ikke en uavhengig radarkontroll. Sidens #81 er 2,32 km unna og #88 er 1,46 km unna. Deres skogdata skal ikke overføres til L07.
- **A01: 61.23076, 11.72394.** Utenfor morgenrektangelet. Ingen ny direkte regnmåling ved A01 er hentet; punktet forkastes ikke.
- **S03: 60.53938, 12.18334.** Utenfor morgenrektangelet, men i samme brede region som flere av de senere prioriterte punktene. Avstand til #319 er 7,95 km, #324 9,02 km, #326 16,43 km og #322 17,82 km. Dette er nye steder, ikke bekreftelser av S03.

Avstandene er beregnet som storcirkelavstand med radius 6371 km, fra publiserte avrundede koordinater. Resultatet ligger i comparison.json. De er ikke gangavstander.

## Kildekontroll og konkret begrensning

Hovedrapporten og kartets side kunne leses. Lenken til data/rain_watch.json og kartets plan/radar/rain-filer returnerte HTTP 403 / «This Page Does Not Exist». Originalbildet board/2026-09-26_07-46-22.jpg viste samme feilmelding i nettleseren. Regnhendelsene er derfor fortsatt sidens referater; jeg har ikke kontrollert dem mot originalbildene eller radarrasteret.

Tavla på horde.pladsen.dev viste fortsatt 25.09 som nyeste tavledato og oppga Kodejakten-koden som ukjent. Den kan ikke brukes som en oppdatert bekreftelse av dagens kodeopplysning.

Rapportens chatutdrag rundt kl. 11.47–13.20 omtaler noen ved kassen og en mislykket kode. Utdragene inneholder også motstridende stedsrykter. De dokumenterer ikke at kassen er funnet eller hvor den står. Ingen slik påstand er lagt inn som funn.

## Videre arbeid

Behold de tre undersøkelsespunktene. L07 er første punkt jeg ville kontrollert mot dagens originale regnserie, med S03 og de nye Solør-punktene som sammenligning og A01 som nordlig kontroll. Dette er en arbeidsprioritet, ikke en anbefaling om å reise til en bekreftet lokasjon. Før omrangering må de nye hendelsenes kilde, klokkeslett og faktiske radarverdier ved punktene være tilgjengelige. Regndrypp fra trær må skilles fra pågående nedbør.

Ingen GitHub-innlegg eller README-endringer er publisert i denne kontrollen. Tidligere felles status beholdes: https://github.com/mkekeoooo/hordejakten-2026/issues/12#issuecomment-5841991804

Nyere arbeid: ../ARBEIDSSTATUS_26sep_nye_steder.md. Nye Dahlsvegen/Burmavegen-punkter og tester Ringsaker/Toten/Ringebu publisert i issue13 kommentar5846713598.
