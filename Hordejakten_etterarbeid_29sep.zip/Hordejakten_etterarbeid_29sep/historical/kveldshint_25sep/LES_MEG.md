# Nye hint – kveldskontroll 25. september 2026

Kontrollert rundt kl. 21.25–21.40 norsk sommertid (CEST, UTC+2). Pladsens hintteller har økt fra 79 ved forrige kontroll til 86. Dette er antall oppføringer i en uoffisiell samling, ikke antall bekreftede geografiske hint.

## Verifisert i bildene

1. Bokstavtavla viser `THILPRTE` og `OESHF`. Bokstavtelling gir eksakt samsvar med både **THE SHOPLIFTER**, **FILTER THE SHOP** og **HELHET FOR TIPS**. THE FOREST HILL er ikke et eksakt anagram: P mangler og L forekommer én gang for mye. Ingen av løsningene er bekreftet av arrangøren. En eventuell hilsen til BobTheShoplifter bekrefter heller ikke stedene eller modellene på default.no.

2. Tavlebildet med påført tidspunkt 25.09 kl. 18.13.23 viser: «KANSKJE 35% BJØRK · 25% GRAN · 40% FURU · AKKURAT RUNDT MEG». Ordene KANSKJE og AKKURAT RUNDT MEG er avgjørende: dette er et lokalt anslag fra Anja, ikke et målt forhold for en kartcelle eller en landsdel.

3. HORDE-pilskiltet er synlig til høyre for boksen og peker mot venstre i de kontrollerte arkivbildene rundt nominelt kl. 17.20–17.22. En håndrekvisitt er synlig foran boksen i tavlebildet kl. 18.13. Dette dokumenterer rekvisittene, ikke en ny geografisk retning eller tallkode.

## Ny flypåstand er foreløpig ikke en identifikasjon

Pladsen fører en oppadrettet gest rundt kl. 17.22 og knytter den til SAS50J, med SAS364 som et annet fly i regionen. Disse flyidentitetene er ikke kontrollert mot originalspor i denne gjennomgangen.

To minuttklipp ble hentet fra det offentlige arkivet. Kontaktarket for 17.20.34 viser hvert andre sekund; arket for 17.21.34 har seks stikkprøver. Disse prøvene fastslår ikke sikkert hvilken gest oppføringen sikter til. De er ikke en sammenhengende videokontroll og kan ikke utelukke en kort gest mellom prøvene. Nominell tid er filnavn pluss avspillingsposisjon, ikke kalibrert hendelsestid. Ingen ny flybasert geografisk avgrensning er derfor lagt til.

## Andre oppdateringer

- «Ingen ferist som jeg merka» er gjengitt av Pladsen, men oppføringen har ikke et lenket tavlebilde. Registrert som sekundæropplysning. Fravær av en merket ferist er uansett ingen sikker utelukkelse av en vei.
- Musikken i den tidligere Facebook-storyen oppgis nå i motsatt tittel/artist-rekkefølge av den vi tidligere brukte: «Goldenrod · Riverbank». Den aktuelle storyen krevde innlogging ved kontroll. Vi lar derfor både rekkefølge og geografisk betydning stå åpne; musikken brukes ikke som selvstendig støtte til en elv.
- Et nyere offentlig Horde-innlegg viser Jaktvettreglene 2026. Det gir ingen etablert ny plassering.

## Konsekvens

Ballongoppgaven er den tydeligste nye gåten. Den kan handle om kode, underholdning eller en hilsen til fellesskapet. Lokal skogbeskrivelse er nyttig ved sammenligning av et konkret sted, men endrer ikke alene den nasjonale prioriteringen. Ingen ny koordinat er bekreftet, og README-rangeringen er ikke endret på dette grunnlaget.

## Kilder

- Hintoversikt: https://horde.pladsen.dev/?fane=tavla
- Bokstavtavle: https://horde.pladsen.dev/img/tavle-2509-shoplifter.jpg
- Treslagstavle: https://horde.pladsen.dev/img/tavle-2509-treslag.jpg
- Ballongsekvens: https://default.no/cuts/202609251620_202609251703.mp4 (hele sekvensen er ikke gjennomgått i denne kontrollen)
- Minuttklipp: https://default.no/clips/min/2026-09-25/17-20-34.mp4
- Minuttklipp: https://default.no/clips/min/2026-09-25/17-21-34.mp4
- Offentlig Horde-innlegg: https://www.facebook.com/horde.no/posts/pfbid02mRnFCnknkHhCarebgt2oZpkJdsYZRPk8sSZLKKnn4CUXJ44upruG3dNkh5tBdccul

Bildene i pakken er kontaktark fra de to minuttklippene. Videoene er ikke pakket med. Kontrollen avviser ikke rapporterte hendelser; den skiller det som faktisk er kontrollert fra det som fortsatt er en påstand.
