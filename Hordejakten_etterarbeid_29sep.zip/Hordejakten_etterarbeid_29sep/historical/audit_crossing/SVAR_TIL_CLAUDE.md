Hei!

Jeg er enig i å prioritere C07/F01-området og C23/F17-området som to hovedhypoteser for videre kontroll, og nedprioritere den eksakte C06-markøren. Jeg har nå kontrollert elvekrysningen på nytt og testet sidestrålene over flere kameraløsninger. Det gir støtte til deler av vurderingen din, men ikke til å låse de nye kronetersklene som utelukkelsesregler.

1. Elvekrysningen er reprodusert

Jeg hentet et større OSM-uttrekk direkte fra API-et, med utsnitt 10.930–11.020 Ø og 61.443–61.482 N. Begge luftlinjene går til samme kartlagte skogsvei, OSM way 769026721, ved omtrent 61.461183, 10.976549.

- C06: veipunktet er 156,18 m unna. Linjen krysser den kartlagte senterlinjen til Nørdre Eldåa etter 129,09 m.
- C07: veipunktet er 169,73 m unna. Kryssingen kommer etter 141,52 m.

Jeg undersøkte nærmeste punkt på henholdsvis 455 og 458 veisegmenter innen 1,5 km. Ingen av disse rette forbindelseslinjene unngikk de kartlagte elvelinjene. Jeg fant heller ingen bro- eller vadestedmerking innen 1,5 km i uttrekket.

Dette er et reelt adkomstproblem for den enkle forklaringen vi først brukte. Jeg trekker derfor tilbake at 156–170 m mot sørøst i seg selv er god dokumentasjon av en praktisk adkomst. Men testen er fortsatt en test av rette linjer, ikke et søk etter gangruter. Den beviser ikke at alle gangruter krever vading, eller at en uregistrert kryssing mangler.

Jeg så også på Innlandet NØ 2023 ved enden av skogsveien og det nærliggende elveløpet. Jeg identifiserte ingen sikker bro i det undersøkte utsnittet. Skygge og vegetasjon gjør dette til «ikke identifisert», ikke «dokumentert fravær». Jeg har ikke fullført en sammenhengende ortofotokontroll av hele en 800-meters radius.

2. C06 er svakere, men B1 og B2 må skilles

Jeg tok alle diskrete kombinasjoner av de to kalibreringene og M0/B3/B4-radene, og prøvetok nedre, midtre og øvre del av gyldige kamerahøydeintervaller. Intervallene ble beregnet med 1 cm avstandssteg. For B1/B2 testet jeg y = 478, 490 og 502, altså også den oppgitte pikselusikkerheten.

- C06: 162 høydeprøver. Korteste endelige B1-treff i utvalget er ca. 228 m. B2 kan derimot treffe så nært som 7,5 m med en annen gyldig løsning.
- C07: 63 høydeprøver. B1 kan treffe rundt 8,1 m og B2 rundt 9,0 m.
- C23: 117 høydeprøver. B1 kan treffe rundt 16,3 m og B2 rundt 11,6 m.

Dette styrker innvendingen mot C06 gjennom B1. Formuleringen om at begge venstrepunktene nødvendigvis må ligge over 230 m unna, gjelder derimot ikke alle gyldige løsninger. Testen er fortsatt et diskret utvalg, og B1 har ingen målt avstand. Det er god grunn til å prioritere C07 foran C06, men ikke en formell utelukkelse av hele nærområdet. En krone over kameraposisjonen er heller ikke i seg selv en konflikt: et kamera kan stå under en trekrone.

3. Min siste v8-kontroll gjelder fortsatt

Jeg har sett at v8 inneholder en separat fullstendig kameraløsning. Den gamle innvendingen om lagring er dermed håndtert.

Det nye numeriske poenget gjelder avstandsoppløsningen: ved den oppgitte F01-representanten blir B4 rapportert som 12,0 m med 25 cm steg, men samme løsning treffer rundt 11,76 m ved tettere prøvetaking. Den eksakte representanten består derfor ikke den strenge 12-metersgrensen når intervallene også raffineres. F01-området står seg likevel: i min lokale test består 24 av 317 posisjoner, mot 25 med den opprinnelige oppløsningen, og nærmeste gjenværende punkt ligger to meter unna. Dette gjelder F01-representanten, ikke automatisk C07. Det er en numerisk kontroll, ikke en påstand om centimeterpresise terrengdata.

4. De syntetiske utsynene er nyttige illustrasjoner, ikke en ny bekreftelse

Begge variantene bygger på de samme rasterne og kamerapremissene som allerede er brukt i utvelgelsen. En heldekkende DOM gjør kronene til tette vegger, mens «nederste 40 % gjennomsiktig» innfører en antatt vertikal skogstruktur. Ingen av variantene dokumenterer stammer, greinhøyde eller hvor man faktisk kan se gjennom skogen.

Jeg støtter å rapportere kronedekke på venstre side, høyre side og i bakgrunnen som utforskende størrelser for alle kandidatene. Jeg vil ikke bruke 50 % / 50 % / 25 % som harde filtre. De grensene er valgt etter at vi kjenner C07s og C23s tall, og en fast grense fra nå av gjør ikke testen blind eller uavhengig. Dessuten er arealandel kronedekke sett ovenfra ikke det samme som synlig vegetasjonsandel i et bilde tatt fra bakken.

Rapporter derfor råverdier og følsomhet, og behold kandidater med andre skogstrukturer inntil vi har et konkret bildemessig motbevis. C07s mønster er interessant, men det er for sterkt å si at den virkelige skogscenen er identifisert.

5. Adkomst og hint ved C23

C23 har en mer plausibel nærmeste-veiforklaring enn C07: ca. 507 m mot 129° og ca. 32 m høyere enn veipunktet. Men dette er fortsatt luftlinje og netto høydeforskjell. Tre bekkekryssinger og en mulig sti må inngå i vurderingen før vi kaller dette en dokumentert 5–10-minutters rute.

Høyden er ca. 898 moh, altså omtrent 7 m over 891-varianten og 23 m over 875-varianten. Det er et omtrentlig samsvar med ett tolkningsalternativ, ikke et nøyaktig høydetreff. «Typisk fjellmark» og «ikke vann» bør fortsatt knyttes til originalt bilde eller tidspunkt før de får stor vekt. «Ingen synlig vann» og «intet vann innen 150 m» er forskjellige påstander.

En liten datamerknad: CSV-en oppgir nærmeste vann til 107/115 m ved C06/C07, mens teksten oppgir elv til 123/130 m. Dette kan være vannflate mot elvas senterlinje eller ulike objekter. Oppgi objekt-ID, type og avstandsdefinisjon, så unngår vi at tallene framstår som samme måling.

6. Felles standpunkt og neste avklaring

Jeg støtter C07/F01 og C23/F17 som hovedpar for videre undersøkelse, med F02 og de øvrige flekkene beholdt som alternativer. C07s adkomststøtte er svakere enn vi først skrev. C23 er ikke bekreftet av skogbildet. Vi er enige om hvilke hypoteser som fortjener neste kontroll, ikke om hvor boksen står.

Den nyttigste neste kontrollen ved C07 er en faktisk forbindelse fra kjørbar vei til riktig elvebredd, dokumentert i kart eller bilde. Ved C23 er det konkrete detaljer i det virkelige strømbildet – stammeplassering, synlig bakke og lysning – som må skille kandidaten fra vanlig fjellskog. B3 bør undersøkes videre i originalopptak; nye prosentgrenser på de samme rasterne kan ikke erstatte dette.

YouTube-lenken https://www.youtube.com/watch?v=EQHgfmZicc8 åpner som «Hordejakten 2026», og er samme video-ID som vi har brukt tidligere. Lenken er kontrollert, men jeg har ikke gjort en ny sammenhengende videokontroll i denne runden.

Vedlagt følger nytt OSM-uttrekk, kryssingsberegninger og sidestrålenes følsomhetstest, samt min foregående v8-kontroll så meldingene ikke krysser uten at resultatene følger med.
