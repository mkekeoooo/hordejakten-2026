# Elvekrysning og sidestråler, 25. september 2026

Svar og to nye beregningskontroller. Ingen bekreftet plassering.

- A2_expanded.osm: hentet fra https://api.openstreetmap.org/api/0.6/map?bbox=10.930,61.443,11.020,61.482. Uttrekk kan inneholde komplette ways og tilhørende noder langt utenfor utsnittet. Bro-/vadestedmerking ble derfor kontrollert geografisk, ikke bare ved globalt tekstsøk. To ford-noder finnes langt unna (ca. 15 og 18 km), ikke nær C07.
- river_crossings.json: linjeskjæringer mellom rett forbindelse til nærmeste punkt på veisegmenter og OSM waterway=river. Ingen beregnet gangrute eller vannbredde. Ingen fraværsbevis for uregistrerte broer, vadesteder eller stier. Avstander er EPSG:25833-planavstander, avrundet i svaret.
- side_rays_sensitivity.json: flere høydeprøver i samtlige gyldige diskrete kombinasjoner av modellens kalibrering og M0/B3/B4-pikselvalg. Høydeintervaller med 0,01 m avstandssteg, sidestråler med 0,1 m steg til 300 m. B1/B2 y=478/490/502. Ikke en full kontinuerlig optimering, og ikke centimeterpresise rasterdata. NaN betyr ingen beregnet skjæring innen rekkevidden. joint_near45_samples er bare en beskrivende diagnostikk, ikke en avstandsgrense målt i bildet.
- Skriptene forutsetter prosjektets tidligere rastermapper og den lokale tilpasningen av kollegaens modell i hordejakten/flekker_received/local_model.py. Den foregående Kontroll_v8_til_Claude.zip følger med som separat vedlegg i den samlede pakken.

Ortofoto kontrollert visuelt i nettleser: https://norgeibilder.no/?wkid=25833&is3d=false&xmin=285276.875&xmax=286123.125&ymin=6820611.9921875&ymax=6821088.0078125&id=4291 . Prosjekt Innlandet NØ 2023. Ingen sikker bro identifisert i dette utsnittet; ingen full 800 m radiuskontroll utført.

Kartdata © OpenStreetMap-bidragsytere: https://www.openstreetmap.org/copyright . Terrenggrunnlag: Kartverkets tidligere nedlastede NHM DTM1. Primærvideo: https://www.youtube.com/watch?v=EQHgfmZicc8 .
