# Beslutning og driftsspor – 25.09.2026

## Konklusjon
Sørlige Messelt kan prioriteres som første kontrollsone blant alternativene i kollegaens notat. Dette er en beslutning om kontrollrekkefølge, ikke en identifisert plassering. Adkomst er fortsatt ikke kontrollert som sammenhengende gangrute. G18 først er praktisk fordi punktet ligger nærmere oppgitt veiende; det er ikke en sannsynlighetsrangering.

## Kildekontroll gjennomført
Lest BESLUTNINGSNOTAT.md, LES_MEG.md og stammetest.py direkte fra Hordejakten_beslutningsnotat_25sep.zip. Stammetesten er ikke kjørt på nytt i denne kontrollen.
Hentet offentlig HTML fra https://default.no/ og https://horde.no/gjeldfri/hordejakten.
Hentet åtte JavaScript-filer lenket fra Horde-siden, kampanjesidens komponent og sju avhengigheter identifisert gjennom Gatsby/webpack-ruteregisteret. Kommentarer, referanser, kampanjeinnhold og relevante tekststrenger undersøkt. Dette omfatter ikke hele Horde-appen eller alle nettsidens undersider.
Kampanjekomponent: https://horde.no/component---src-pages-gjeldfri-hordejakten-index-tsx-2992cc538b09baf63383.js
Innholdsmodul: https://horde.no/19e8b8b4a745f7e1ae924d1dc7c3754113a8bbc2-024aae2ee3f6940a6b12.js
Innholdsmodul 6699 har videoId EQHgfmZicc8 og kampanje-/FAQ-tekst. Ingen lokasjonsfasit funnet i undersøkt innhold. Nøkkelordsøk alene beviser ikke fravær av skjulte hint.
En forespørsel til offentlig Gatsby page-data.json ga HTTP 403; den er ikke brukt som bevis og ble ikke omgått. Ingen innloggede tjenester eller interne kameraendepunkter er undersøkt.
Default.no oppgir selv at det er en søkelogg basert på offentlige kilder. Dets kandidatkoordinater er ikke arrangørens fasit.
Se source_inventory.json og de to URL-manifestene for filnavn, størrelse, SHA256 og omfang. HTML/JS-kopiene ligger lokalt, men er ikke nødvendige vedlegg i denne pakken.

## Støtteapparat: hva er dokumentert?
Primærkilde: https://horde.no/gjeldfri/hordejakten, FAQ om sikkerheten til personen i kassen.
Horde oppgir regelmessige pauser, frivillighet og personer i nærheten som ivaretar Anja. Dette dokumenterer støttepersonell, men ikke en konkret 24/7-vaktordning, avstand, hytte, bolig eller nettilkobling.
Strømbehov beviser ikke strømnett: batterier, batteribytte eller aggregat er alternative driftsmåter. Regneeksempel, IKKE målt forbruk: 100 W kontinuerlig = 2,4 kWh/døgn; 500 W = 12 kWh/døgn, før tap. Vi kjenner ikke utstyrslisten eller eventuell oppvarming.
Klær som ikke synes i bildet kan oppbevares utenfor bildefeltet eller leveres av personell. Klærne dokumenterer ikke en bygning i nærheten. Analysen skal gjelde offentlig synlig utstyr og logistikk, ikke hennes private pauser eller klesskift.

## Sekundært driftsspor som bør etterprøves
Default.no oppgir skifte til et bilde av en plankevegg/plakat ved leveringer og pause 23.09 ca. 12.04–12.11 og 14.45–15.01. Disse sekvensene er IKKE visuelt kontrollert i denne runden. Kamerabytte alene beviser verken en bygning eller fysisk avstand mellom opptaksstedene. Det kan være en separat kulisse eller et innslag. Undersøk overgangene for sikkert synlige kabler, utstyr, leveringsretning og sammenheng mellom bildene.
https://default.no/

## Endringer til beslutningsnotatet
- To geografisk ulike flekker er ikke to uavhengige bevis: samme observasjoner og modeller valgte begge.
- Erstatt «ingen konflikter» med «ingen avgjørende motbevis dokumentert i de hittil undersøkte sporene». Uavklarte forhold er ikke bekreftelser.
- G18s oppgitte luftlinje på 155 m er ikke i seg selv et treff på 5–10 minutters gange. Startpunkt, parkeringsmulighet, faktisk rute og sammenhengen mellom tavleutsagnene er ukjent.
- GFW-tap fra 2022 er ikke dokumentasjon på aktiv tømmerdrift i september 2026. Vegetasjonstap alene identifiserer heller ikke årsaken.
- stammetest.py bruker ok.any() separat for hver observert stamme: samme kronetopp kan dermed telle for flere stammer. Treffantall er ikke en en-til-en-identifikasjon. Avstandene avhenger av antatte stammediametre, og kronetopp trenger ikke ligge over stammefot.

## Konkrete kontrollpunkter
Oppgitt veiende: 61.45425, 10.84350 (ikke verifisert bilparkering).
G18: 61.45446, 10.84064.
C23/G16: 61.45713, 10.83615.
Før eventuell fysisk kontroll: dokumenter farbar adkomst, bekker og veibegrensninger. Ingen befaring er gjennomført av oss.
C07: 61.46254, 10.97512 beholdes som alternativ med uavklart elvekryssing.

## Neste resultat som faktisk kan endre prioriteringen
Fotografier fra kandidatstedet i riktig retning kan sammenlignes med originalbildets stammer, terreng og åpning. Mismatch ved to nøyaktige punkt utelukker ikke hele Messelt, men bør stoppe stadig flytting av markørene uten et nytt selvstendig holdepunkt.
En kontroll av overgangene til pausebildet kan gi et uavhengig driftsspor. Ikke utled husavstand fra udokumenterte antakelser om strøm, klær eller kamerabytte.
