Start with documents/ETTERARBEID_2026-09-29.md and documents/KODER_OG_HINT.md.
The documents mirror the GitHub root; some links require that online context.
Historical files may contain superseded status and unresolved relative references to large omitted data.
Run python reproduce_audit.py for the compact offline audit. Full historic workflows may need omitted rasters or remote sources.
Reported coordinate and Y2567 remain unconfirmed.
