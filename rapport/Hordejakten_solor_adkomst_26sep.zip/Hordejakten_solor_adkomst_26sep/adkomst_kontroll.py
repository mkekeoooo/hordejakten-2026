"""Kontrollerer kartlagte linjer, ikke gangbarhet eller faktisk ankomstrute."""
from pathlib import Path
import json, math
import numpy as np
from pyproj import Transformer, Geod
from shapely.geometry import LineString, Point
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
P=Path(__file__).parent
T=Transformer.from_crs(4326,25833,always_xy=True)
INV=Transformer.from_crs(25833,4326,always_xy=True)
G=Geod(ellps='WGS84')
fig,axs=plt.subplots(1,2,figsize=(15,8))
results={}
for ax,name in zip(axs,['A01','L07']):
 r=json.loads((P/f'{name}_adkomst.json').read_text(encoding='utf-8'))
 osm=json.loads((P/f'{name}_osm.json').read_text())
 x,y=T.transform(r['lon'],r['lat']); center=Point(x,y)
 waters=[];roads=[];ses=[]
 for e in osm['elements']:
  tags=e.get('tags',{})
  if e['type']!='way' or len(e.get('geometry',[]))<2:continue
  coords=[T.transform(p['lon'],p['lat']) for p in e['geometry']]
  line=LineString(coords)
  if 'waterway' in tags:waters.append((e,line))
  if 'highway' in tags:
   roads.append((e,line))
   ds=np.linspace(0,line.length,max(2,math.ceil(line.length/2)+1))
   pts=[line.interpolate(d) for d in ds]
   lo,la=INV.transform([p.x for p in pts],[p.y for p in pts])
   az,_,d=G.inv(np.full(len(pts),r['lon']),np.full(len(pts),r['lat']),lo,la)
   az=np.asarray(az)%360;d=np.asarray(d)
   m=(az>=90)&(az<=170)
   if np.any(m):
    ii=np.flatnonzero(m)[np.argmin(d[m])]
    ses.append(dict(osm_id=e['id'],highway=tags['highway'],distance_m=float(d[ii]),azimuth=float(az[ii]),lat=float(la[ii]),lon=float(lo[ii])))
 selected=[]
 for road in r['roads']:
  if road['distance_m']>900:continue
  path=LineString([(x,y),road['xy']])
  cross=[]
  for we,wl in waters:
   inter=path.intersection(wl)
   if not inter.is_empty:
    cross.append(dict(osm_id=we['id'],tags=we.get('tags',{}),intersection_wkt=inter.wkt))
  selected.append(dict(osm_id=road['id'],distance_m=road['distance_m'],azimuth=road['azimuth_from_camera'],dz_m=road['dz_m'],waterway_intersections=cross))
 sector=sorted(ses,key=lambda v:v['distance_m'])[:5]
 z=np.frombuffer((P/f'{name}_DTM2.bsq').read_bytes()[:4000000],dtype='<f4').reshape(1000,1000)
 bb=r['dtm_bbox'];ext=[bb[0]-x,bb[2]-x,bb[1]-y,bb[3]-y]
 for q in sector:
  if q['distance_m']>900:continue
  xx,yy=T.transform(q['lon'],q['lat']);path=LineString([(x,y),(xx,yy)])
  q['waterway_intersections']=[dict(osm_id=e['id'],tags=e['tags']) for e,l in waters if path.intersects(l)]
  n=math.ceil(path.length/5);xxs=np.linspace(xx,x,n+1);yys=np.linspace(yy,y,n+1)
  cols=np.floor((xxs-bb[0])/2).astype(int);rows=np.floor((bb[3]-yys)/2).astype(int)
  if np.any((cols<0)|(cols>=1000)|(rows<0)|(rows>=1000)):raise ValueError('Profile outside raster')
  h=z[rows,cols];q['dz_m']=float(h[-1]-h[0]);q['profile_z']=h.tolist();q['max_5m_slope_pct']=float(max(abs(np.diff(h)))/(path.length/n)*100)
 results[name]=dict(sector_deg=[90,170],road_sampling_m=2,sector_nearest=sector,nearest_roads=selected)
 shade=LightSource(315,45).hillshade(z,vert_exag=1,dx=2,dy=2)
 ax.imshow(shade,cmap='gray',extent=ext,origin='upper',vmin=0,vmax=1)
 for e,line in roads:
  c=np.array(line.coords);ax.plot(c[:,0]-x,c[:,1]-y,color='#c92828',lw=1.4,ls='--' if e['tags']['highway']=='track' else '-')
 for e,line in waters:
  c=np.array(line.coords);ax.plot(c[:,0]-x,c[:,1]-y,color='#187bc2',lw=1)
 for road in r['roads'][:3]:
  xx,yy=road['xy'];ax.plot([0,xx-x],[0,yy-y],color='#d44ac5',lw=1,ls=':')
  ax.text(xx-x,yy-y,f" {road['distance_m']:.0f} m / {road['azimuth_from_camera']:.0f}°",fontsize=8,color='#7c075e',bbox=dict(fc='white',alpha=.7,pad=1,ec='none'))
 for az in [90,170]:
  lon,lat,_=G.fwd(r['lon'],r['lat'],az,900);xx,yy=T.transform(lon,lat);ax.plot([0,xx-x],[0,yy-y],color='#c67b00',ls='--',lw=1)
 ax.plot(0,0,'r+',ms=14,mew=2);ax.set(xlim=(-1000,1000),ylim=(-1000,1000),aspect='equal',xlabel='Øst fra punkt (m)',ylabel='Nord fra punkt (m)',title=f"{name}: {r['lat']:.5f}, {r['lon']:.5f}\nRød: kartlagt vei/spor. Blå: vannløp.")
fig.suptitle('Adkomstkontroll 26.09.2026 — OSM og Kartverket DTM2\nPrikket: luftlinjer, ikke gangruter. Gule stråler: svak tolkningssektor 90–170°.',fontsize=13)
fig.tight_layout();fig.savefig(P/'adkomst_A01_L07.png',dpi=150)
(P/'adkomst_kontroll.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
for n,r in results.items():
 print(n,'SE nærmest',r['sector_nearest'][:2])
 print('Veier',[(q['osm_id'],round(q['distance_m']),round(q['azimuth']),len(q['waterway_intersections'])) for q in r['nearest_roads'][:6]])
