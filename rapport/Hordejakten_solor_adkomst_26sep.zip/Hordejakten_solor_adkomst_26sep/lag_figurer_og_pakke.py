from pathlib import Path
import json,math,hashlib,zipfile
import numpy as np
from PIL import Image
from pyproj import Transformer,Geod
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).parent
T=Transformer.from_crs(4326,25833,always_xy=True);G=Geod(ellps='WGS84')
sites=[('S01',60.94645,11.84006),('S02',60.80277,12.12363),('S03',60.53938,12.18334),('S04',60.91635,12.26619),('S05',60.86382,12.28116),('S06',60.61433,12.32469)]
man=[]
fig,axs=plt.subplots(2,3,figsize=(15,10.8))
for ax,(n,lat,lon) in zip(axs.flat,sites):
 x,y=T.transform(lon,lat);bb=[x-338.5,y-168.2583,x+338.5,y+168.2583]
 url=f'https://norgeibilder.no/?wkid=25833&is3d=false&xmin={bb[0]}&xmax={bb[2]}&ymin={bb[1]}&ymax={bb[3]}&id=4916'
 im=Image.open(P/f'{n}_NIB2025.png');w,h=im.size
 ax.imshow(im,extent=[-338.5,338.5,-168.2583,168.2583])
 for az in [188.7,219.6,250.5]:
  lo,la,_=G.fwd(lon,lat,az,60);xx,yy=T.transform(lo,la);ax.plot([0,xx-x],[0,yy-y],color='red',lw=.8,ls='--' if az==219.6 else '-')
 ax.plot(0,0,'r+',ms=12,mew=1.5);ax.set(xlim=(-125,125),ylim=(-125,125),aspect='equal',title=f'{n}: {lat:.5f}, {lon:.5f}',xlabel='Øst fra punkt (m)',ylabel='Nord fra punkt (m)')
 man.append(dict(id=n,lat=lat,lon=lon,url=url,project='Innlandet SØ 2025',project_id=4916,exact_capture_day=None,screenshot=f'{n}_NIB2025.png',map_width_m=677,map_height_m=336.5166,note='URL-en kan normaliseres av nettstedet med mindre enn ca. 1 m avrunding.'))
fig.suptitle('Seks Solør-kandidater i valgt prosjekt Innlandet SØ 2025\nRødt: kandidat og hypotetisk kamerasynsfelt. Det er ikke påvist noen detaljmatch. © Norge i Bilder / Geovekst',fontsize=12)
fig.tight_layout();fig.savefig(P/'Solor_NIB2025_sammenligning.png',dpi=140)
(P/'nib_manifest.json').write_text(json.dumps(man,indent=2,ensure_ascii=False),encoding='utf-8')
fig,axs=plt.subplots(1,2,figsize=(13,4.5))
c=json.loads((P/'adkomst_kontroll.json').read_text())
for ax,name in zip(axs,['A01','L07']):
 d=json.loads((P/f'{name}_adkomst.json').read_text(encoding='utf-8'))
 rr=d['roads'][0]
 choices=[(f"Nærmeste: {rr['distance_m']:.0f} m / {rr['azimuth_from_camera']:.0f}°",rr['profile_z'],rr['distance_m'])]
 alt=c[name]['sector_nearest'][0 if name=='A01' else 1]
 choices.append((f"Alternativ: {alt['distance_m']:.0f} m / {alt['azimuth']:.0f}°",alt['profile_z'],alt['distance_m']))
 for label,h,dist in choices:
  ax.plot(np.linspace(0,dist,len(h)),np.asarray(h)-h[-1],label=label)
 ax.axhline(0,color='gray',lw=.5);ax.set(title=name,xlabel='Avstand langs luftlinjen FRA veien (m)',ylabel='Høyde relativt til kandidat (m)');ax.legend(fontsize=8);ax.grid(alpha=.2)
fig.suptitle('Terrengprofiler — Kartverket DTM eksportert i 2 m, prøver ca. hver 5 m\nDette er ikke dokumenterte gangruter eller målte gangtider. Retning i tegnforklaring: kandidat → vei.',fontsize=11)
fig.tight_layout();fig.savefig(P/'adkomst_profiler.png',dpi=150)
out=P.parent/'Hordejakten_solor_adkomst_26sep.zip'
files=[f for f in sorted(P.iterdir()) if f.is_file() and f.name not in ['forbered.py','SHA256SUMS.txt']]
hashes=''.join(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.name}\n' for f in files)
(P/'SHA256SUMS.txt').write_text(hashes,encoding='utf-8')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files+[P/'SHA256SUMS.txt']:z.write(f,'Hordejakten_solor_adkomst_26sep/'+f.name)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(out.name,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
