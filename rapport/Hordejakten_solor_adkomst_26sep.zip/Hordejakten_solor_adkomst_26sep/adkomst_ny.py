from pathlib import Path
import json,urllib.request,urllib.parse,math
import numpy as np
from pyproj import Transformer,Geod
from concurrent.futures import ThreadPoolExecutor
P=Path(__file__).parent
T=Transformer.from_crs(4326,25833,always_xy=True);INV=Transformer.from_crs(25833,4326,always_xy=True);G=Geod(ellps='WGS84')
sites=[('A01',61.23076,11.72394),('L07',60.82353,11.53750)]
def run(s):
 name,lat,lon=s;x,y=T.transform(lon,lat)
 q=f'''[out:json][timeout:45];(way["highway"](around:1200,{lat},{lon});way["waterway"](around:1200,{lat},{lon});way["natural"~"^(water|wetland)$"](around:1200,{lat},{lon});relation["natural"~"^(water|wetland)$"](around:1200,{lat},{lon}););out geom;'''
 p=P/(name+'_osm.json')
 if not p.exists():
  req=urllib.request.Request('https://overpass-api.de/api/interpreter',data=urllib.parse.urlencode({'data':q}).encode(),headers={'User-Agent':'Hordejakten-public-research/1.0'})
  with urllib.request.urlopen(req,timeout=55) as r:p.write_bytes(r.read())
 osm=json.loads(p.read_text(encoding='utf-8')); roads=[]
 for e in osm['elements']:
  if e['type']!='way' or 'highway' not in e.get('tags',{}):continue
  xy=np.array([T.transform(g['lon'],g['lat']) for g in e['geometry']]);a=xy[:-1];v=xy[1:]-a
  t=np.clip(np.sum((np.array([x,y])-a)*v,axis=1)/np.maximum(np.sum(v*v,axis=1),1e-9),0,1)
  pts=a+t[:,None]*v;d=np.linalg.norm(pts-np.array([x,y]),axis=1);i=np.argmin(d);lo,la=INV.transform(*pts[i]);az,_,dist=G.inv(lon,lat,lo,la)
  roads.append(dict(id=e['id'],tags=e['tags'],nearest=[la,lo],distance_m=float(dist),azimuth_from_camera=az%360,xy=pts[i].tolist()))
 roads.sort(key=lambda r:r['distance_m'])
 x0=math.floor(x)-1000;y0=math.floor(y)-1000;W=H=1000;res=2
 args=dict(bbox=f'{x0},{y0},{x0+2000},{y0+2000}',bboxSR=25833,imageSR=25833,size=f'{W},{H}',format='bsq',pixelType='F32',interpolation='RSP_NearestNeighbor',f='image')
 url='https://hoydedata.no/arcgis/rest/services/NHM_DTM_25833/ImageServer/exportImage?'+urllib.parse.urlencode(args)
 rp=P/(name+'_DTM2.bsq')
 if not rp.exists():
  with urllib.request.urlopen(url,timeout=40) as r:rp.write_bytes(r.read())
 z=np.frombuffer(rp.read_bytes()[:W*H*4],dtype='<f4').reshape(H,W)
 def height(xx,yy):return z[np.clip(np.floor((y0+2000-yy)/res).astype(int),0,H-1),np.clip(np.floor((xx-x0)/res).astype(int),0,W-1)]
 for road in roads:
  if road['distance_m']>900:continue
  start=np.array(road['xy']);end=np.array([x,y]);dist=np.linalg.norm(end-start);n=max(2,math.ceil(dist/5));xy=start+(end-start)*np.linspace(0,1,n+1)[:,None];h=height(xy[:,0],xy[:,1]);dh=np.diff(h);step=dist/n;slope=dh/step
  road.update(dz_m=float(h[-1]-h[0]),up_m=float(np.maximum(0,dh).sum()),maximum_5m_slope_pct=float(np.max(abs(slope))*100),tobler_minutes=float(np.sum(step/1000/(6*np.exp(-3.5*abs(slope+.05)))*60)),profile_z=h.tolist())
 result=dict(id=name,lat=lat,lon=lon,z=float(height(np.array(x),np.array(y))),osm_query=q,dtm_url=url,dtm_bbox=[x0,y0,x0+2000,y0+2000],dtm_res=res,roads=roads)
 (P/(name+'_adkomst.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(name,[(r['id'],r['tags'],round(r['distance_m']),round(r['azimuth_from_camera']),round(r.get('dz_m',0))) for r in roads[:8]],flush=True)
 return result
with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(run,sites))
