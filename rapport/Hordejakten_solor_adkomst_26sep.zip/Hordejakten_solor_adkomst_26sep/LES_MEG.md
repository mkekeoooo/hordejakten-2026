# Solør-bilder og reell betydning av adkomst — 26.09.2026

## Resultatet som endrer arbeidsprioriteringen

**L07 har en alternativ kartlagt veiadkomst fra øst-sørøst som ikke krysser det kartlagte vannløpet.** Den tidligere bekkeinnvendingen gjelder luftlinjen til nærmeste spor, ikke alle mulige ankomster. A01 beholdes, men det er en spenning mellom nærmeste vei mot nordvest og tolkningen av tavlepilen mot sørøst. Ingen plassering er bekreftet.

| Kandidat / kartlagt linje | Luftlinje | Retning fra kandidat til vei | Høydeforskjell vei → kandidat | Kartlagt vannløp over luftlinjen |
|---|---:|---:|---:|---|
| A01, Oskjølveien, OSM 542425038 | 494 m | 317° | +56 m | Ingen treff |
| A01, nærmeste prøve i sektoren 90–170°, OSM 542422796 | 714 m | 168° | −32 m | Ingen treff |
| L07, nærmeste spor, OSM 517862818 | 321 m | 160° | +14 m | Ett: bekk 1201154189 |
| L07, alternativ servicevei, OSM 845257675 | 400 m | 108° | +21 m | Ingen treff |
| L07, alternativ vei, OSM 441767304 | 408 m | 117° | +23 m | Ingen treff |

Alle tall er avrundet. Retningene er geodetiske, ikke UTM-gridretninger og ikke gangretningen fra bilen. A01 = 61.23076, 11.72394 (Osen), **ikke gamle A1 ved Evenstad**. L07 = 60.82353, 11.53750 (Elverum/Løten).

Dette gjør L07 mer interessant relativt til A01 **på adkomstkriteriet**, dersom den usikre tolkningen av pilen og oppover-hintet brukes. Det gir ikke en samlet sannsynlighetsrangering. Ved A01 faller terrenget netto fra den sørlige veien, men den siste delen stiger igjen; netto høydeforskjell er ikke en full test av utsagnet om de siste minuttene. Pilen fastsetter heller ikke en presis kompasskurs. Veistatus, bom, parkering og gangbarhet er ikke kontrollert.

Claudes nye ruteanalyse 00.48Z bruker den kortere adkomsten til L07 og finner bekk. Den alternative veien på samme side av bekken er derfor konkret ny informasjon. Kartet og rågeometrien i denne pakken gjør den etterprøvbar. En tom krysningsliste betyr ingen kryssing av **de kartlagte vannløpslinjene**; små grøfter, myr og manglende OSM-objekter kan finnes.

## Seks nye Solør-punkter: faktisk bildekontroll

De seks koordinatene kom fra Claudes kommentar 00.31Z. S01–S06 er filnavn i denne pakken, ikke tidligere S1/S2 ved Messelt.

| Fil-ID | WGS84 | Esri-bildets dato ved punktet | Visuell vurdering av Norge i Bilder, valgt prosjekt Innlandet SØ 2025 |
|---|---|---|---|
| S01 | 60.94645, 11.84006 | 14.05.2024 | Kant av et bredt åpent felt mot sør/sørvest. Svakere eksakt markør for en liten skoglysning. |
| S02 | 60.80277, 12.12363 | 26.08.2017 | Skogkant med åpent område og små bygninger mot øst. Skog mot sørvest. Ingen identifisert detaljmatch. |
| S03 | 60.53938, 12.18334 | 26.08.2017 | Sammensatt skog og smale åpninger. Beholdes til konkret bildesammenligning; ingen unik match. |
| S04 | 60.91635, 12.26619 | 26.08.2017 | Skogmosaikk med smal åpen stripe. Den eldre bildekilden kan ikke beskrive dagens detaljer alene. |
| S05 | 60.86382, 12.28116 | 26.08.2017 | Skogparti omgitt av større åpninger; tydelig vannflate øst/sørøst i bildet. Ikke en påvist konflikt med synsfeltet. |
| S06 | 60.61433, 12.32469 | 26.08.2017 | Markøren ligger ved kanten av en stor hogstflate. Svakere eksakt markør; nærliggende skog er ikke utelukket. |

**S06 er nr. 1 og S03 nr. 2 i Claudes senere værutvalg.** Bildene gir ingen grunn til å sette S06 først; S03 er mindre åpenbart i konflikt med skogscenen og beholdes. Dette er en kvalitativ vurdering, ikke et nytt hardt filter. Kroner kan skjule bakkeåpninger, og avstanden til de synlige stammene er ikke kjent.

Norge i Bilder viser prosjektet «Innlandet SØ 2025» som valgt (prosjekt-ID 4916, valgt prosjekt dokumentert i S01/S02-skjermbildene). Eksakt opptaksdag i prosjektet er ikke hentet. Fullskjermbilder er lagret uendret. Den sentrale koordinaten ligger ved bildesenteret; oversiktsfiguren legger til kandidatmarkør og kamerastråler. Originalene inneholder også grensesnitt og kildeangivelse. Esri-datoene er fra metadata ved hvert punkt, ikke tjenestens publiseringsdato.

**Vi leter ikke etter en kasse, et HORDE-skilt eller andre midlertidige 2026-objekter i 2025-bilder som om de måtte være der.** Bare varig terreng, vegetasjon og adkomst kan kontrolleres slik. Ingen av de undersøkte bildene dokumenterer en stamme-, stein- eller utstyrsmatch.

## Det vi nå er enige om med Claude

- Solobservasjonene 23.09 kl. 16.45/16.50 er nå inkludert i hans værtest.
- Han har rettet fjernrasterets oppløsning og kjørt alle sine 119 kandidater om igjen. Dette er hans nye kjøring; denne pakken gjenskaper ikke alle 119.
- Han har trukket tilbake den kategoriske regionutelukkelsen av Engerdal/Femund. Ingen rutenettreff med et bestemt sett terskler er ikke en total regionutelukkelse.
- A01 og L07 beholdes som undersøkelsespunkter, uten bekreftet stedsrangering.

Claudes 39 «robuste» punkter betyr robuste mot hans fire valgte varianter av satellitttesten, ikke 39 dokumenterte mulige steder eller en statistisk konfidensliste. Den rapporterte store følsomheten for ±10 minutter må følge resultatet. At en gammel kandidat får én modellkonflikt i en variant, er fortsatt ikke en selvstendig feltutelukkelse.

## Metode og reproduksjon

- `adkomst_ny.py` henter offentlige OSM-linjer innen 1200 m og Kartverkets DTM i 2 m eksportoppløsning over 2 × 2 km. Veilinjenes nærmeste punkt beregnes i EPSG:25833; avstand og retning rapporteres geodetisk. Terrengprøver langs luftlinjer omtrent hver 5 m.
- `adkomst_kontroll.py` prøver **hele** veigeometrien med maksimalt 2 m mellom prøvene for å finne veipunkter i den brede tolkingssektoren 90–170°. Det sjekker også linjekryssing mot kartlagte vannløp. Ingen ruting eller påstand om fri ferdsel.
- DTM-filer: de første 4 000 000 byte i hver `.bsq` er 1000 × 1000 float32, little-endian, rad 0 i nord. Deretter følger tjenestens maske. Georeferanse og URL står i `*_adkomst.json`. De brukte høydene er plausible, men dette er ikke en DTM-usikkerhetsanalyse.
- `hent_solor_bilder.py` henter Esri-bilder og pikselmetadata. Browser-skjermbildene er separat dokumentasjon fra Norge i Bilder.
- Python-avhengigheter: numpy, pyproj, shapely, matplotlib, Pillow. Ingen tredjepartsskript fra Claude er kjørt i denne pakken.
- Tobler-tid finnes i råresultatet, men er ikke målt gangtid. Den er ikke brukt til hard forkasting; utenfor-sti-faktor og bærehypotese er ikke validert.

## Kilder

- [Claudes oppdaterte vær- og solkontroll, 00.40Z](https://github.com/mkekeoooo/hordejakten-2026/issues/12#issuecomment-5841605241)
- [Claudes adkomst- og terrengvurdering, 00.48Z](https://github.com/mkekeoooo/hordejakten-2026/issues/12#issuecomment-5841673693)
- [Vår forrige pakke og svar](https://github.com/mkekeoooo/hordejakten-2026/issues/12#issuecomment-5841502760)
- [Norge i Bilder](https://norgeibilder.no/) — Kartverket/Geovekst, prosjekt 4916. Punktlenker i `nib_manifest.json`.
- [Kartverkets DTM-tjeneste](https://hoydedata.no/arcgis/rest/services/NHM_DTM_25833/ImageServer) — eksakte uttrekks-URL-er i JSON-filene.
- [OpenStreetMap](https://www.openstreetmap.org/copyright) — © OpenStreetMap-bidragsyterne, ODbL. Spørringer i JSON-filene, hentet 26.09.2026.
- [Esri World Imagery](https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer) — kilde-/opptaksmetadata og URL i manifestet. Bevar dataeiernes rettigheter ved videre bruk.

## Beslutning for neste konkrete kontroll

Behold A01 og L07; bruk L07s østlige vei i sammenligningen, ikke bare bekkealternativet. Behold S03 som et nytt Solør-alternativ. Nedprioriter de eksakte S01- og S06-markørene i den visuelle gjennomgangen. Et bilde fra selve kandidatstedet med flere samsvarende stammer/steiner vil være langt mer avgjørende enn en ny totalscore fra de samme historiske rasterne.
