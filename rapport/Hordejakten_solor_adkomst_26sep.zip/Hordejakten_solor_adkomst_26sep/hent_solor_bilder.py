from pathlib import Path
import json,hashlib,urllib.request,urllib.parse,math
from concurrent.futures import ThreadPoolExecutor
from pyproj import Transformer,Geod
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).parent
BASE='https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer'
sites=[('S01', 60.94645, 11.84006), ('S02', 60.80277, 12.12363), ('S03', 60.53938, 12.18334), ('S04', 60.91635, 12.26619), ('S05', 60.86382, 12.28116), ('S06', 60.61433, 12.32469)]
T=Transformer.from_crs(4326,3857,always_xy=True);G=Geod(ellps='WGS84')
def get(site):
 name,lat,lon=site;e,n=T.transform(lon,lat);half=200/math.cos(math.radians(lat));box=[e-half,n-half,e+half,n+half]
 args=dict(f='json',bbox=','.join(map(str,box)),bboxSR=3857,imageSR=3857,size='1200,1200',format='jpg',dpi=96)
 url=BASE+'/export?'+urllib.parse.urlencode(args);p=P/(name+'_ortofoto.jpg')
 if not p.exists():
  with urllib.request.urlopen(url,timeout=40) as r:export=json.load(r)
  (P/(name+'_export.json')).write_text(json.dumps(export,indent=2))
  with urllib.request.urlopen(export['href'],timeout=40) as r:b=r.read()
  p.write_bytes(b)
 im=Image.open(p);assert im.size==(1200,1200)
 q=dict(f='json',geometry=f'{lon},{lat}',geometryType='esriGeometryPoint',inSR=4326,spatialRel='esriSpatialRelIntersects',outFields='*',returnGeometry='false')
 mu=BASE+'/10/query?'+urllib.parse.urlencode(q)
 with urllib.request.urlopen(mu,timeout=40) as r:meta=json.load(r)
 (P/(name+'_metadata.json')).write_text(json.dumps(meta,indent=2,ensure_ascii=False))
 return dict(id=name,lat=lat,lon=lon,bbox3857=box,url=url,metadata_url=mu,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),metadata=meta)
with ThreadPoolExecutor(max_workers=3) as ex:results=list(ex.map(get,sites))
(P/'ortofoto_manifest.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',19)
for group in ['S']:
 group_results=[r for r in results if r['id'].startswith(group)]
 for page in range(math.ceil(len(group_results)/4)):
  selected=group_results[page*4:(page+1)*4]
  # Each contact sheet contains at most four full-resolution inspection panels.
  sheet=Image.new('RGB',(1240,1370),'white');d=ImageDraw.Draw(sheet)
  d.text((15,8),'Ortofoto: Esri World Imagery • ca. 400 × 400 m • nord opp',font=font,fill='black')
  d.text((15,36),'Rødt: modellpunkt og synsfelt 188,7–250,5°. Ikke bekreftede bokssteder.',font=font,fill='black')
  for j,r in enumerate(selected):
   im=Image.open(P/(r['id']+'_ortofoto.jpg')).resize((600,600));dd=ImageDraw.Draw(im);e,n=T.transform(r['lon'],r['lat'])
   for az in [188.7,219.6,250.5]:
    lo,la,_=G.fwd(r['lon'],r['lat'],az,75);x,y=T.transform(lo,la);s=1.5*math.cos(math.radians(r['lat']));dd.line((300,300,300+(x-e)*s,300-(y-n)*s),fill='#ff3333',width=2)
   dd.ellipse((295,295,305,305),outline='red',width=2);dd.line((30,560,105,560),fill='white',width=4);dd.text((30,530),'50 m',font=font,fill='white')
   x=20+(j%2)*610;y=108+(j//2)*630;sheet.paste(im,(x,y));d.text((x,y-28),f"{r['id']} {r['lat']:.5f}, {r['lon']:.5f}",font=font,fill='black')
  d.text((15,1340),'Kilde: Esri / Vantor / Earthstar Geographics / GIS User Community. Metadata i vedlegget.',font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',16),fill='black');sheet.save(P/(group+str(page+1)+'_oversikt.jpg'),quality=94)
for r in results:print(r['id'],json.dumps([f['attributes'] for f in r['metadata'].get('features',[])],ensure_ascii=False))
