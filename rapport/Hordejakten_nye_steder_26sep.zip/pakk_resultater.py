from pathlib import Path
import json, zipfile, hashlib, ast

P = Path(__file__).parent
notes = {
'E1':'Skog med sterke skygger og uregelmessige kronehull. Åpnere parti mot nordøst. En sørvestvendt åpning på bakken er ikke påvist.',
'E2':'Skog og mørkere felt mot nord/nordøst. Sterk skygge gjør bakken usikker; ingen særpreget åpning identifisert.',
'E3':'Stor åpen flate ved markøren, skog langs kanten. Også kontrollert i Innlandet NØ 2025: fortsatt bred åpen flate. Svekket som eksakt markør; nærliggende skog ikke utelukket.',
'E4':'Tette trekroner ved punktet og en større åpen flate mot øst/sørøst. Ingen identifisert liten åpning mot sørvest.',
'O1':'Skogmosaikk, mer spredt mot vest og tettere rundt markøren. Ingen unik overensstemmelse.',
'O2':'Skogmosaikk med større åpninger lenger mot sørvest og nordøst. Ingen unik overensstemmelse. Forekommer også i den nyere adkomstlisten.',
'O3':'Skogkant med større åpent areal mot øst. Selve åpningen i videoen er ikke identifisert.',
'O4':'Skogkant, stor åpen flate mot nordvest og tettere skog mot sørøst. Ikke blant de nyere strenge adkomsttreffene.',
'A01':'Uensartet skog med mindre kronehull. Også kontrollert i Innlandet SØ 2025: skog og små åpninger. Konkret punkt for videre sammenligning, uten unik bildematch.',
'A02':'Skog like sør for et åpent, treløst eller vått utseende parti. Dype skygger. Ingen sikker lysning identifisert.',
'A03':'Skog med smal, uregelmessig åpen korridor. Bakke og fuktighetsforhold er usikre.',
'A04':'For det meste sammenhengende trekroner med små åpninger. Ingen særpreget lysning identifisert.',
'A05':'Skog, åpnere parti mot nordøst. Ingen særpreget liten åpning identifisert.',
'A06':'Skog sør for en større åpen flate. Skygge rundt markøren begrenser bakketolkningen.',
'L01':'Lysere og mer glissen bestand omgitt av tettere skog. Ingen sikkert identifisert liten lysning.',
'L02':'Stort åpent eller hogd parti mot nordvest. Trebelte ved punktet, mer oppdelt skog mot sør/øst.',
'L03':'Sørkant av et bredt åpent belte med skog mot sørvest. Skogkant kan sammenlignes videre, men ingen særpreget match.',
'L04':'Skog vest for en åpen nord–sør-stripe. Snørester andre steder i bildet. Ikke en aktuell septemberobservasjon.',
'L05':'Smal åpning eller stripe mellom bestand; større åpne flater lenger til sidene.',
'L06':'For det meste tette, sammenhengende trekroner. Ingen lysning på bakken kan fastslås.',
'L07':'Uregelmessig åpen stripe og skogkant med tregrupper og tette sider. Også kontrollert i Innlandet SØ 2025. Beholdes for konkret bildesammenligning, uten unik match.',
'L08':'Grense mellom skog og åpen stripe. Nær L07; ikke en uavhengig regional bekreftelse.',
'L09':'Smal, omtrent nord–sørvendt åpen stripe ved punktet, med skog på sidene. Større åpent areal mot sør/vest.',
'L10':'Kant av et bredt åpent område med spredte trær mot sørvest. Omsluttende moden skog er mindre tydelig her.',
'L11':'Glissent eller åpent mot nord, mindre trekroner sørvest, skog mot sør/øst.',
'L12':'Smal, tilnærmet øst–vestvendt linje eller åpning gjennom skogen nær markøren. Skygger; ingen rute eller kjørbarhet verifisert.',
'L13':'Skog med uregelmessige kronehull. Også kontrollert i Innlandet SØ 2025. Veilinje øst/sørøst må skilles fra dokumentert biladkomst. Ingen unik match.'
}
manifest = json.loads((P/'ortofoto_manifest.json').read_text(encoding='utf-8'))
lines = ['# Visuelle observasjoner per punkt', '',
'Dato er Esri SRC_DATE ved markøren, ikke produktets utgivelsesår. Kvalitative observasjoner; ingen av punktene er bekreftet. Se LES_MEG.md for kilder og begrensninger. A01 er ikke det gamle A1 ved Evenstad.', '',
'| ID | Breddegrad, lengdegrad | Esri opptaksdato | Observasjon |',
'|---|---|---|---|']
for r in manifest:
    dates = sorted({str(f['attributes']['SRC_DATE']) for f in r['metadata']['features']})
    dates = ', '.join(d[:4]+'-'+d[4:6]+'-'+d[6:] for d in dates)
    lines.append(f"| {r['id']} | {r['lat']:.5f}, {r['lon']:.5f} | {dates} | {notes[r['id']]} |")
(P/'BILDEOBSERVASJONER.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
# Remove an obsolete, unused contact-sheet block from our own script.
script = P/'hent_ortofoto.py'
src = script.read_text(encoding='utf-8').split('\n"""')[0]+'\n'
ast.parse(src)
script.write_text(src,encoding='utf-8')
out = P.parent/'Hordejakten_nye_steder_26sep.zip'
files = [p for p in P.rglob('*') if p.is_file() and '_sol_' not in p.name
         and p.name not in {'E_oversikt.jpg','O_oversikt.jpg','ARBEIDSSTATUS.md'}
         and '__pycache__' not in p.parts]
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):
        z.write(p, p.relative_to(P))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
print(json.dumps({'path':str(out),'files':len(files),'bytes':out.stat().st_size,
                  'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
