# Visuelle observasjoner per punkt

Dato er Esri SRC_DATE ved markøren, ikke produktets utgivelsesår. Kvalitative observasjoner; ingen av punktene er bekreftet. Se LES_MEG.md for kilder og begrensninger. A01 er ikke det gamle A1 ved Evenstad.

| ID | Breddegrad, lengdegrad | Esri opptaksdato | Observasjon |
|---|---|---|---|
| E1 | 61.78589, 11.91410 | 2014-10-29 | Skog med sterke skygger og uregelmessige kronehull. Åpnere parti mot nordøst. En sørvestvendt åpning på bakken er ikke påvist. |
| E2 | 61.76689, 11.93231 | 2014-10-29 | Skog og mørkere felt mot nord/nordøst. Sterk skygge gjør bakken usikker; ingen særpreget åpning identifisert. |
| E3 | 61.74803, 11.95753 | 2019-07-12 | Stor åpen flate ved markøren, skog langs kanten. Også kontrollert i Innlandet NØ 2025: fortsatt bred åpen flate. Svekket som eksakt markør; nærliggende skog ikke utelukket. |
| E4 | 61.73449, 11.96226 | 2019-07-12 | Tette trekroner ved punktet og en større åpen flate mot øst/sørøst. Ingen identifisert liten åpning mot sørvest. |
| O1 | 61.23194, 12.15308 | 2018-07-01 | Skogmosaikk, mer spredt mot vest og tettere rundt markøren. Ingen unik overensstemmelse. |
| O2 | 61.22013, 12.16459 | 2018-07-01 | Skogmosaikk med større åpninger lenger mot sørvest og nordøst. Ingen unik overensstemmelse. Forekommer også i den nyere adkomstlisten. |
| O3 | 61.21813, 12.17576 | 2018-07-01 | Skogkant med større åpent areal mot øst. Selve åpningen i videoen er ikke identifisert. |
| O4 | 61.25065, 12.16743 | 2018-07-01 | Skogkant, stor åpen flate mot nordvest og tettere skog mot sørøst. Ikke blant de nyere strenge adkomsttreffene. |
| A01 | 61.23076, 11.72394 | 2017-08-13 | Uensartet skog med mindre kronehull. Også kontrollert i Innlandet SØ 2025: skog og små åpninger. Konkret punkt for videre sammenligning, uten unik bildematch. |
| A02 | 61.18428, 11.91789 | 2014-10-29 | Skog like sør for et åpent, treløst eller vått utseende parti. Dype skygger. Ingen sikker lysning identifisert. |
| A03 | 61.30499, 12.00000 | 2014-10-29 | Skog med smal, uregelmessig åpen korridor. Bakke og fuktighetsforhold er usikre. |
| A04 | 61.33185, 12.00452 | 2014-10-29 | For det meste sammenhengende trekroner med små åpninger. Ingen særpreget lysning identifisert. |
| A05 | 61.16172, 12.06662 | 2014-10-29 | Skog, åpnere parti mot nordøst. Ingen særpreget liten åpning identifisert. |
| A06 | 61.29913, 12.10254 | 2014-10-29 | Skog sør for en større åpen flate. Skygge rundt markøren begrenser bakketolkningen. |
| L01 | 60.81542, 11.45721 | 2023-05-31 | Lysere og mer glissen bestand omgitt av tettere skog. Ingen sikkert identifisert liten lysning. |
| L02 | 60.84087, 11.46802 | 2023-05-31 | Stort åpent eller hogd parti mot nordvest. Trebelte ved punktet, mer oppdelt skog mot sør/øst. |
| L03 | 60.86406, 11.50639 | 2022-05-09 | Sørkant av et bredt åpent belte med skog mot sørvest. Skogkant kan sammenlignes videre, men ingen særpreget match. |
| L04 | 60.74718, 11.52150 | 2020-04-22 | Skog vest for en åpen nord–sør-stripe. Snørester andre steder i bildet. Ikke en aktuell septemberobservasjon. |
| L05 | 60.74692, 11.52521 | 2020-04-22 | Smal åpning eller stripe mellom bestand; større åpne flater lenger til sidene. |
| L06 | 60.86011, 11.53040 | 2022-05-09 | For det meste tette, sammenhengende trekroner. Ingen lysning på bakken kan fastslås. |
| L07 | 60.82353, 11.53750 | 2022-05-09 | Uregelmessig åpen stripe og skogkant med tregrupper og tette sider. Også kontrollert i Innlandet SØ 2025. Beholdes for konkret bildesammenligning, uten unik match. |
| L08 | 60.82483, 11.53901 | 2022-05-09 | Grense mellom skog og åpen stripe. Nær L07; ikke en uavhengig regional bekreftelse. |
| L09 | 60.79961, 11.54360 | 2020-04-22 | Smal, omtrent nord–sørvendt åpen stripe ved punktet, med skog på sidene. Større åpent areal mot sør/vest. |
| L10 | 60.76032, 11.63139 | 2020-04-22 | Kant av et bredt åpent område med spredte trær mot sørvest. Omsluttende moden skog er mindre tydelig her. |
| L11 | 60.74823, 11.64717 | 2017-05-26 | Glissent eller åpent mot nord, mindre trekroner sørvest, skog mot sør/øst. |
| L12 | 60.75598, 11.69941 | 2021-09-04 | Smal, tilnærmet øst–vestvendt linje eller åpning gjennom skogen nær markøren. Skygger; ingen rute eller kjørbarhet verifisert. |
| L13 | 60.84006, 11.72685 | 2024-05-14 | Skog med uregelmessige kronehull. Også kontrollert i Innlandet SØ 2025. Veilinje øst/sørøst må skilles fra dokumentert biladkomst. Ingen unik match. |
