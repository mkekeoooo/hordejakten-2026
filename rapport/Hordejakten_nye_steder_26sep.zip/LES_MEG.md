# Hordejakten – kontroll av nye modellpunkter, 26. september 2026

Utført av Codex. Ingen plassering er bekreftet. Dette er en konkret bildekontroll av punkter publisert av Claude i GitHub-sak #12, ikke en ny landsdekkende sannsynlighetsmodell.

## Resultat

- 27 forskjellige koordinater kontrollert i Esri World Imagery: fire Engerdal-punkter, fire opprinnelige Osen-punkter og de 20 punktene i den nyere adkomstlisten. Ett Osen-punkt forekommer i begge listene.
- Fire punkter kontrollert videre i Norge i Bilder med eksplisitt valgt **2025-prosjekt**: E3, A01, L07 og L13. Skjermbildene ligger ved. Prosjektår er verifisert i grensesnittet; eksakt fotograferingsdato er ikke hentet.
- E3 (61.74803, 11.95753) ligger på en stor åpen flate i både Esri-bildet fra 2019 og prosjektet Innlandet NØ 2025. Det er en konkret innvending mot den publiserte markøren som en liten åpning inne i skogen. Nærliggende skog er ikke utelukket.
- A01 og L07 beholdes som konkrete punkter for videre sammenligning; ingen unik overensstemmelse med videostedet er identifisert. Dette er ikke en ny rangering av hele Norge.
- Et faktisk problem i morgensolkoden er kontrollert og delvis rettet uavhengig: 20 m-rasteret ble indeksert som 1 m. På de åtte kontrollpunktene ga rettelsen **ingen endring i det rapporterte minimumet 0 m**, selv om alle fjernterrengprøvene før rettelsen manglet. Ikke påstå at feilen i seg selv har endret rangeringen.

## Les bildefilene riktig

E = Engerdal, O = første Osen-klynge, A01–A06 = seks andre Osen-punkter fra adkomstlisten, L01–L13 = Elverum/Løten-listen. **A01 her er ikke det gamle A1 ved Evenstad.** O2 er den sjuende posisjonen i den nye Osen-adkomstlisten.

Oversiktene viser ca. 400 × 400 m, nord opp, og tre røde stråler mot 188,7°, 219,6° og 250,5°. Strålene er beregnet geodetisk. Esri-eksporten bruker Web Mercator, med bredde korrigert for breddegrad; metrisk skala er omtrentlig. Råbilder er 1200 × 1200 px, men dette er eksportoppløsning, ikke en påstand om originalens detaljoppløsning.

`ortofoto_manifest.json` inneholder koordinater, forespørsler, kildeattributter og SHA-256 for råbildene. `SRC_DATE` er opptaksdato, mens `ReleaseName` er kartproduktets publiseringsversjon. En «2026.R01»-utgivelse kan inneholde bilder fra 2014. Dette skillet er avgjørende her.

Smal åpning under trekroner kan være usynlig ovenfra. Skogbunn, lyng, stammeplassering og høyde kan ikke fastslås sikkert fra disse oversiktene. Mørke felt kan være skygge. Ingen prosent- eller samsvarsscore er tildelt bildene.

## Kilder og kontroller

- Claude: https://github.com/mkekeoooo/hordejakten-2026/issues/12
- Ny adkomstliste: https://github.com/mkekeoooo/hordejakten-2026/issues/12#issuecomment-5841241401
- Esri World Imagery: https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer
- Esri opptaksmetadata, lag 10: https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/10
- Norge i Bilder: https://norgeibilder.no/
- DTM/DOM: https://hoydedata.no/arcgis/rest/services/NHM_DTM_25833/ImageServer og https://hoydedata.no/arcgis/rest/services/NHM_DOM_25833/ImageServer

Norge i Bilder, E3, valgt Innlandet NØ 2025 (prosjekt 4918):
https://norgeibilder.no/?wkid=25833&is3d=false&xmin=338693&xmax=340047&ymin=6849531.4833984375&ymax=6850204.5166015625&id=4918

A01, valgt Innlandet SØ 2025 (4916):
https://norgeibilder.no/?wkid=25833&is3d=false&xmin=323810.5&xmax=324487.5&ymin=6792730.741699219&ymax=6793067.258300781&id=4916

L07, samme prosjekt:
https://norgeibilder.no/?wkid=25833&is3d=false&xmin=311410.5&xmax=312087.5&ymin=6747931.741699219&ymax=6748268.258300781&id=4916

L13, samme prosjekt:
https://norgeibilder.no/?wkid=25833&is3d=false&xmin=321791.5&xmax=322468.5&ymin=6749242.741699219&ymax=6749579.258300781&id=4916

## Morgensol: reproduksjon og begrensning

I både `trinnB.mjs` og `trinnB2.mjs` står samplerens indeks som `floor(x-t.x0)` og `floor(t.y1-y)`. Dette er bare riktig ved 1 m-oppløsning. Fjernrasteret har 20 m-oppløsning. Riktig er henholdsvis `floor((x-t.x0)/t.res)` og `floor((t.y1-y)/t.res)`.

`kontroll_morgensol.py` viser feilen på ferske Kartverket-uttrekk ved E1–E4, A01, L07, L13 og O2. Før retting: 0 gyldige fjernprøver per punkt. Etter: 366 600 gyldige fjernprøver per punkt (390 mulige belyste flater × 940 avstander). De åtte minimumsresultatene for nødvendig flatehøyde forblir 0,0 m. Stråledekning ved den valgte flaten øker fra 56,0 % til 100 %.

Dette er en isolert kontroll med Claudes faste solretning 97,9° og høyde 5,65°. Den validerer ikke at den valgte flaten i modellen er flaten som faktisk er belyst i filmen, og den er ikke en full kjøring av alle kandidatene. Flatevalg, soltid og geografisk solposisjon er fortsatt premisser.

Store solrastere er utelatt fra ZIP-en for å holde den håndterlig; de nøyaktige URL-ene og boksene står i `morgensol_kontroll.json`, og skriptet henter dem igjen. Små DOM/DTM-uttrekk til kronekontrollen er inkludert. BSQ-filene inneholder F32-rasterdata først og et ekstra maskelag etterpå; skriptene bruker de første W×H×4 bytene. Kontrollen er begrenset til gyldige høydeverdier i disse utsnittene.

## Kronekontroll

`kontroll_krone.py` bruker PROJ/pyproj uavhengig av Claudes UTM-kode og laster nye 1 m-uttrekk. Ved de publiserte, avrundede koordinatene får jeg:

| Punkt | K0 | K1 | K2 | K3 | K4 |
|---|---:|---:|---:|---:|---:|
| E3 | 0,05 | 2,34 | 10,47 | 17,30 | 17,46 |
| A01 | 0,01 | 0,04 | 13,43 | 15,78 | 14,50 |
| L07 | 0,25 | 0,69 | 15,49 | 13,95 | 17,37 |
| L13 | 2,05 | 2,69 | 16,33 | 10,62 | 12,70 |

Alle fire består de valgte K-tersklene. Avrunding og celler på sektorgrensen kan gi små forskjeller fra Claudes tall. At E3 består samtidig som nyere fotografi viser en stor åpen flate, må avklares med DOM-årgang og visuell plassering av sektorene; det er ikke grunnlag for å erklære fotografiet feil.

DOMs metadata-identifikasjon ved E3 gir rastertile 33-129-128, men ingen opptaksdato. DOM-årgangen er derfor fortsatt ikke fastslått.

## Værtesten og videre beslutning

De sikre bildene 23.09 ca. 16.45/16.50 er et bedre premiss enn tavleteksten SOL kl. 17.49. Originaler: https://default.no/clips/min/2026-09-23/16-45-13.mp4 og https://default.no/clips/min/2026-09-23/16-50-13.mp4 . Tidene er nominell lokal klipptid, ikke en ny kalibrering av sendeforsinkelsen.

Flerdagsskriptets WMS-tider ligger 10 minutter før soltidene; en slik forskyvning må dokumenteres mot satellittens tidskonvensjon eller behandles som følsomhet. Referanseminimumet bør ikke inkludere observasjonsdagen når resultatet sammenlignes med den forrige kontrollen. Null differanse i en referanse som inkluderer observasjonen betyr ikke målt skyfri himmel.

Grovgrid på 50 m, valgte K-terskler og én rett linje til nærmeste kartlagte vei kan prioritere videre arbeid. De kan ikke alene utelukke hele Engerdal eller Femund. En DOM-overflate er heller ikke en ugjennomsiktig vegg ned til bakken; passasjer under greinene må ikke hardt filtreres bort.

Alle tolkninger over er skrivebordsundersøkelse. Ingen rute er befart, ingen boks er identifisert og ingen nye punkter er godkjent som samlet førstevalg.
