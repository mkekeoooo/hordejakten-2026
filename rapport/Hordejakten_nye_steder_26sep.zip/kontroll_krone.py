from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,urllib.request,urllib.parse,math
import numpy as np
from pyproj import Transformer
P=Path(__file__).parent
T=Transformer.from_crs(4326,25833,always_xy=True)
K=[('K0',212,226,3,7,.5),('K1',213,226,8,17,.5),('K2',190,207,3,20,.9),('K3',232,250,5,25,.9),('K4',213,226,25,70,.9)]
sites=[('E3',61.74803,11.95753),('A01',61.23076,11.72394),('L07',60.82353,11.53750),('L13',60.84006,11.72685)]
def check(s):
 name,lat,lon=s;x,y=T.transform(lon,lat);x0=math.floor(x)-100;y0=math.floor(y)-100;W=H=200
 rasters={};urls={}
 for kind in ['DOM','DTM']:
  q=dict(bbox=f'{x0},{y0},{x0+W},{y0+H}',bboxSR=25833,imageSR=25833,size=f'{W},{H}',format='bsq',pixelType='F32',interpolation='RSP_NearestNeighbor',f='image')
  u='https://hoydedata.no/arcgis/rest/services/NHM_'+kind+'_25833/ImageServer/exportImage?'+urllib.parse.urlencode(q);urls[kind]=u
  with urllib.request.urlopen(u,timeout=40) as r:b=r.read()
  assert len(b)>=W*H*4
  (P/(name+'_'+kind+'.bsq')).write_bytes(b)
  rasters[kind]=np.frombuffer(b[:W*H*4],dtype='<f4').reshape(H,W)
 chm=np.maximum(0,rasters['DOM']-rasters['DTM']);out={}
 # Same sector sampling and unique 1 m cells as Claude, with independent PROJ coordinates.
 for kn,a0,a1,r0,r1,q in K:
  cells=set()
  for az in np.arange(a0,a1+.001,.25):
   dl=100*math.cos(math.radians(az))/6371000*180/math.pi
   dn=100*math.sin(math.radians(az))/(6371000*math.cos(math.radians(lat)))*180/math.pi
   xx,yy=T.transform(lon+dn,lat+dl);dx=(xx-x)/100;dy=(yy-y)/100
   for d in np.arange(r0,r1+.001,.25):cells.add((math.floor(x+dx*d),math.floor(y+dy*d)))
  vals=np.array([chm[H-1-(iy-y0),ix-x0] for ix,iy in cells]);valid=vals[np.isfinite(vals)&(vals>=0)&(vals<100)]
  out[kn]=dict(value=float(np.sort(valid)[math.floor(q*(len(valid)-1))]),n=len(cells),valid_n=len(valid))
 return dict(id=name,lat=lat,lon=lon,utm=[x,y],bbox25833=[x0,y0,x0+W,y0+H],urls=urls,K=out)
with ThreadPoolExecutor(max_workers=2) as ex:out=list(ex.map(check,sites))
(P/'uavhengig_kronekontroll.json').write_text(json.dumps(out,indent=2))
for r in out:print(r['id'],{k:round(v['value'],2) for k,v in r['K'].items()})
