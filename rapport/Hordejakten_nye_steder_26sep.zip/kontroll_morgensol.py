"""Independent limited rerun: isolate missing raster resolution in trinnB/B2.
Keeps Claude's 97.9 degree azimuth / 5.65 degree elevation and target sector.
These values are a scenario, not a calibrated scene reconstruction.
"""
from pathlib import Path
import json,math,urllib.request,urllib.parse
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from pyproj import Transformer
P=Path(__file__).parent;T=Transformer.from_crs(4326,25833,always_xy=True)
sites=[('E1',61.78589,11.91410),('E2',61.76689,11.93231),('E3',61.74803,11.95753),('E4',61.73449,11.96226),('A01',61.23076,11.72394),('L07',60.82353,11.53750),('L13',60.84006,11.72685),('O2',61.22013,12.16459)]
def raster(name,box,res):
 x0,y0,x1,y1=box;w=round((x1-x0)/res);h=round((y1-y0)/res)
 q=dict(bbox=','.join(map(str,box)),bboxSR=25833,imageSR=25833,size=f'{w},{h}',format='bsq',pixelType='F32',interpolation='RSP_NearestNeighbor',f='image')
 u='https://hoydedata.no/arcgis/rest/services/NHM_DTM_25833/ImageServer/exportImage?'+urllib.parse.urlencode(q)
 p=P/(name+'.bsq')
 if p.exists():b=p.read_bytes()
 else:
  with urllib.request.urlopen(u,timeout=50) as r:b=r.read()
  p.write_bytes(b)
 assert len(b)>=w*h*4
 return dict(a=np.frombuffer(b[:w*h*4],dtype='<f4').reshape(h,w),box=box,res=res,url=u)
def sample(t,x,y,broken=False):
 x0,y0,x1,y1=t['box'];h,w=t['a'].shape;s=1 if broken else t['res']
 c=np.floor((x-x0)/s).astype(int);r=np.floor((y1-y)/s).astype(int);ok=(c>=0)&(c<w)&(r>=0)&(r<h)
 out=np.full(np.shape(c),np.nan);out[ok]=t['a'][r[ok],c[ok]]
 out[(out < -100)|(out>3000)]=np.nan
 return out
def check(site):
 name,lat,lon=site;cx,cy=T.transform(lon,lat);ix,iy=math.floor(cx),math.floor(cy)
 near=raster(name+'_sol_near',[ix-250,iy-450,ix+1250,iy+250],1)
 far=raster(name+'_sol_far',[ix-400,iy-6000,ix+20000,iy+2000],20)
 def direction(a):
  xx,yy=T.transform(lon+100*math.sin(math.radians(a))/(6371000*math.cos(math.radians(lat)))*180/math.pi,lat+100*math.cos(math.radians(a))/6371000*180/math.pi)
  return (xx-cx)/100,(yy-cy)/100
 sources=np.array([(cx+direction(az)[0]*d,cy+direction(az)[1]*d) for az in range(238,251) for d in range(5,151,5)])
 x=sources[:,0,None];y=sources[:,1,None];g=sample(near,x,y)
 d=np.r_[np.arange(2,1200,1),np.arange(1200,20000,20)][None,:];vx,vy=direction(97.9)
 xx=x+vx*d;yy=y+vy*d
 n=sample(near,xx,yy);f=sample(far,xx,yy);broken=sample(far,xx,yy,True)
 out={}
 for tag,fa in [('broken',broken),('fixed',f)]:
  z=np.where(d<1200,n,fa);v=z-d*d*(1-.13)/(2*6371000)-(g+d*math.tan(math.radians(5.65)))
  need=np.maximum(0,np.nanmax(v,axis=1));j=int(np.nanargmin(need));coverage=np.isfinite(z).sum(axis=1)/z.shape[1]
  out[tag]=dict(required_surface_height_m=float(need[j]),chosen_source_utm=sources[j].tolist(),finite_ray_fraction=float(coverage[j]),far_finite_samples=int(np.isfinite(fa[:,d[0]>=1200]).sum()))
 return dict(id=name,lat=lat,lon=lon,near_url=near['url'],far_url=far['url'],near_bbox=near['box'],far_bbox=far['box'],result=out)
with ThreadPoolExecutor(max_workers=2) as ex:out=list(ex.map(check,sites))
(P/'morgensol_kontroll.json').write_text(json.dumps(out,indent=2))
for r in out:print(r['id'],r['result'])
